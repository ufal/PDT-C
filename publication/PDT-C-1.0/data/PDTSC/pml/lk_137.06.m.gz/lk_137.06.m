<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_137.06.w.gz" />
  </references>
 </head>
 <s id="m137-669">
  <m id="m137-d1t1505-14">
   <w.rf>
    <LM>w#w-d1t1505-14</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1505-15">
   <w.rf>
    <LM>w#w-d1t1505-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1505-16">
   <w.rf>
    <LM>w#w-d1t1505-16</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m137-d1t1505-13">
   <w.rf>
    <LM>w#w-d1t1505-13</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m137-d1t1505-17">
   <w.rf>
    <LM>w#w-d1t1505-17</LM>
   </w.rf>
   <form>odjela</form>
   <lemma>odjet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m137-d1t1505-18">
   <w.rf>
    <LM>w#w-d1t1505-18</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m137-d1t1505-19">
   <w.rf>
    <LM>w#w-d1t1505-19</LM>
   </w.rf>
   <form>dětmi</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m137-d1t1505-20">
   <w.rf>
    <LM>w#w-d1t1505-20</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1505-22">
   <w.rf>
    <LM>w#w-d1t1505-22</LM>
   </w.rf>
   <form>Chodova</form>
   <lemma>Chodov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m137-d-id118677-punct">
   <w.rf>
    <LM>w#w-d-id118677-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-669-670">
   <w.rf>
    <LM>w#w-669-670</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1510-2">
   <w.rf>
    <LM>w#w-d1t1510-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1510-4">
   <w.rf>
    <LM>w#w-d1t1510-4</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1510-5">
   <w.rf>
    <LM>w#w-d1t1510-5</LM>
   </w.rf>
   <form>trávila</form>
   <lemma>trávit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1510-6">
   <w.rf>
    <LM>w#w-d1t1510-6</LM>
   </w.rf>
   <form>víkendy</form>
   <lemma>víkend</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m137-669-671">
   <w.rf>
    <LM>w#w-669-671</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1510-10">
   <w.rf>
    <LM>w#w-d1t1510-10</LM>
   </w.rf>
   <form>soboty</form>
   <lemma>sobota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m137-669-672">
   <w.rf>
    <LM>w#w-669-672</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1510-11">
   <w.rf>
    <LM>w#w-d1t1510-11</LM>
   </w.rf>
   <form>neděle</form>
   <lemma>neděle</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m137-669-1115">
   <w.rf>
    <LM>w#w-669-1115</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1510-12">
   <w.rf>
    <LM>w#w-d1t1510-12</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1510-13">
   <w.rf>
    <LM>w#w-d1t1510-13</LM>
   </w.rf>
   <form>všední</form>
   <lemma>všední</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m137-d1t1510-14">
   <w.rf>
    <LM>w#w-d1t1510-14</LM>
   </w.rf>
   <form>dny</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m137-d-id118920-punct">
   <w.rf>
    <LM>w#w-d-id118920-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1512-2">
   <w.rf>
    <LM>w#w-d1t1512-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m137-d1t1512-3">
   <w.rf>
    <LM>w#w-d1t1512-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1512-4">
   <w.rf>
    <LM>w#w-d1t1512-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m137-d1t1512-5">
   <w.rf>
    <LM>w#w-d1t1512-5</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m137-d1t1512-6">
   <w.rf>
    <LM>w#w-d1t1512-6</LM>
   </w.rf>
   <form>tchýně</form>
   <lemma>tchýně_,s_^(^DD**tchyně)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d1t1512-7">
   <w.rf>
    <LM>w#w-d1t1512-7</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m137-669-1116">
   <w.rf>
    <LM>w#w-669-1116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-1117">
  <m id="m137-d1t1512-9">
   <w.rf>
    <LM>w#w-d1t1512-9</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1512-10">
   <w.rf>
    <LM>w#w-d1t1512-10</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m137-d1t1512-11">
   <w.rf>
    <LM>w#w-d1t1512-11</LM>
   </w.rf>
   <form>pomáhala</form>
   <lemma>pomáhat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1512-12">
   <w.rf>
    <LM>w#w-d1t1512-12</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m137-d1t1512-13">
   <w.rf>
    <LM>w#w-d1t1512-13</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-669-673">
   <w.rf>
    <LM>w#w-669-673</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-674">
  <m id="m137-d1t1512-17">
   <w.rf>
    <LM>w#w-d1t1512-17</LM>
   </w.rf>
   <form>Chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1512-15">
   <w.rf>
    <LM>w#w-d1t1512-15</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1512-18">
   <w.rf>
    <LM>w#w-d1t1512-18</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1512-19">
   <w.rf>
    <LM>w#w-d1t1512-19</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-d-m-d1e1483-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1483-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1514-x2">
  <m id="m137-d1t1517-1">
   <w.rf>
    <LM>w#w-d1t1517-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1517-2">
   <w.rf>
    <LM>w#w-d1t1517-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m137-d1t1517-3">
   <w.rf>
    <LM>w#w-d1t1517-3</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1517-4">
   <w.rf>
    <LM>w#w-d1t1517-4</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m137-d-id119349-punct">
   <w.rf>
    <LM>w#w-d-id119349-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1518-x2">
  <m id="m137-d1t1525-3">
   <w.rf>
    <LM>w#w-d1t1525-3</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1525-2">
   <w.rf>
    <LM>w#w-d1t1525-2</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1e1518-x2-703">
   <w.rf>
    <LM>w#w-d1e1518-x2-703</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1525-4">
   <w.rf>
    <LM>w#w-d1t1525-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1525-5">
   <w.rf>
    <LM>w#w-d1t1525-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1525-8">
   <w.rf>
    <LM>w#w-d1t1525-8</LM>
   </w.rf>
   <form>narodila</form>
   <lemma>narodit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m137-d1t1525-6">
   <w.rf>
    <LM>w#w-d1t1525-6</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m137-d1t1525-7">
   <w.rf>
    <LM>w#w-d1t1525-7</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d-id119552-punct">
   <w.rf>
    <LM>w#w-d-id119552-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1527-7">
   <w.rf>
    <LM>w#w-d1t1527-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1527-8">
   <w.rf>
    <LM>w#w-d1t1527-8</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m137-d1t1527-9">
   <w.rf>
    <LM>w#w-d1t1527-9</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m137-d1t1529-1">
   <w.rf>
    <LM>w#w-d1t1529-1</LM>
   </w.rf>
   <form>nejobyčejnější</form>
   <lemma>obyčejný</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m137-d1t1529-2">
   <w.rf>
    <LM>w#w-d1t1529-2</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m137-d1e1518-x2-704">
   <w.rf>
    <LM>w#w-d1e1518-x2-704</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-705">
  <m id="m137-d1t1529-4">
   <w.rf>
    <LM>w#w-d1t1529-4</LM>
   </w.rf>
   <form>Bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m137-d1t1529-5">
   <w.rf>
    <LM>w#w-d1t1529-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1529-7">
   <w.rf>
    <LM>w#w-d1t1529-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1529-9">
   <w.rf>
    <LM>w#w-d1t1529-9</LM>
   </w.rf>
   <form>Holešovicích</form>
   <lemma>Holešovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m137-705-706">
   <w.rf>
    <LM>w#w-705-706</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-707">
  <m id="m137-d1t1536-4">
   <w.rf>
    <LM>w#w-d1t1536-4</LM>
   </w.rf>
   <form>Byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m137-d1t1536-5">
   <w.rf>
    <LM>w#w-d1t1536-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1536-7">
   <w.rf>
    <LM>w#w-d1t1536-7</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m137-d1t1536-8">
   <w.rf>
    <LM>w#w-d1t1536-8</LM>
   </w.rf>
   <form>místnost</form>
   <lemma>místnost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d1t1536-9">
   <w.rf>
    <LM>w#w-d1t1536-9</LM>
   </w.rf>
   <form>čtvrté</form>
   <lemma>čtvrtý</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m137-d1t1536-10">
   <w.rf>
    <LM>w#w-d1t1536-10</LM>
   </w.rf>
   <form>kategorie</form>
   <lemma>kategorie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-d1t1536-11">
   <w.rf>
    <LM>w#w-d1t1536-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1536-12">
   <w.rf>
    <LM>w#w-d1t1536-12</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m137-d1t1536-13">
   <w.rf>
    <LM>w#w-d1t1536-13</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m137-d1t1536-14">
   <w.rf>
    <LM>w#w-d1t1536-14</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1536-16">
   <w.rf>
    <LM>w#w-d1t1536-16</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m137-d1t1536-17">
   <w.rf>
    <LM>w#w-d1t1536-17</LM>
   </w.rf>
   <form>menší</form>
   <lemma>malý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m137-d1t1536-18">
   <w.rf>
    <LM>w#w-d1t1536-18</LM>
   </w.rf>
   <form>místnost</form>
   <lemma>místnost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d-id120177-punct">
   <w.rf>
    <LM>w#w-d-id120177-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1536-20">
   <w.rf>
    <LM>w#w-d1t1536-20</LM>
   </w.rf>
   <form>jakoby</form>
   <lemma>jakoby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1536-21">
   <w.rf>
    <LM>w#w-d1t1536-21</LM>
   </w.rf>
   <form>kuchyňka</form>
   <lemma>kuchyňka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-707-708">
   <w.rf>
    <LM>w#w-707-708</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-709">
  <m id="m137-d1t1540-2">
   <w.rf>
    <LM>w#w-d1t1540-2</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1540-3">
   <w.rf>
    <LM>w#w-d1t1540-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m137-d1t1540-5">
   <w.rf>
    <LM>w#w-d1t1540-5</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m137-d1t1540-4">
   <w.rf>
    <LM>w#w-d1t1540-4</LM>
   </w.rf>
   <form>kuchyňky</form>
   <lemma>kuchyňka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-709-752">
   <w.rf>
    <LM>w#w-709-752</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-709-743">
   <w.rf>
    <LM>w#w-709-743</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-709-745">
   <w.rf>
    <LM>w#w-709-745</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-709-746">
   <w.rf>
    <LM>w#w-709-746</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m137-709-747">
   <w.rf>
    <LM>w#w-709-747</LM>
   </w.rf>
   <form>okno</form>
   <lemma>okno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m137-709-753">
   <w.rf>
    <LM>w#w-709-753</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-709-738">
   <w.rf>
    <LM>w#w-709-738</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-709-739">
   <w.rf>
    <LM>w#w-709-739</LM>
   </w.rf>
   <form>zařídil</form>
   <lemma>zařídit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m137-709-740">
   <w.rf>
    <LM>w#w-709-740</LM>
   </w.rf>
   <form>pokoj</form>
   <lemma>pokoj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m137-709-741">
   <w.rf>
    <LM>w#w-709-741</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m137-709-742">
   <w.rf>
    <LM>w#w-709-742</LM>
   </w.rf>
   <form>dětičky</form>
   <lemma>dětičky</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m137-709-754">
   <w.rf>
    <LM>w#w-709-754</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-755">
  <m id="m137-709-749">
   <w.rf>
    <LM>w#w-709-749</LM>
   </w.rf>
   <form>Měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m137-709-748">
   <w.rf>
    <LM>w#w-709-748</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-709-750">
   <w.rf>
    <LM>w#w-709-750</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m137-709-751">
   <w.rf>
    <LM>w#w-709-751</LM>
   </w.rf>
   <form>postýlky</form>
   <lemma>postýlka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m137-755-756">
   <w.rf>
    <LM>w#w-755-756</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1518-x3">
  <m id="m137-d1t1545-2">
   <w.rf>
    <LM>w#w-d1t1545-2</LM>
   </w.rf>
   <form>Vedle</form>
   <lemma>vedle-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1545-3">
   <w.rf>
    <LM>w#w-d1t1545-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1545-4">
   <w.rf>
    <LM>w#w-d1t1545-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m137-d1t1545-5">
   <w.rf>
    <LM>w#w-d1t1545-5</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m137-d1t1545-6">
   <w.rf>
    <LM>w#w-d1t1545-6</LM>
   </w.rf>
   <form>místnosti</form>
   <lemma>místnost</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-d1t1549-2">
   <w.rf>
    <LM>w#w-d1t1549-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1549-3">
   <w.rf>
    <LM>w#w-d1t1549-3</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m137-d1e1518-x3-757">
   <w.rf>
    <LM>w#w-d1e1518-x3-757</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1549-10">
   <w.rf>
    <LM>w#w-d1t1549-10</LM>
   </w.rf>
   <form>kuchyň</form>
   <lemma>kuchyň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d-id120739-punct">
   <w.rf>
    <LM>w#w-d-id120739-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1549-12">
   <w.rf>
    <LM>w#w-d1t1549-12</LM>
   </w.rf>
   <form>ložnice</form>
   <lemma>ložnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d-id120763-punct">
   <w.rf>
    <LM>w#w-d-id120763-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1551-1">
   <w.rf>
    <LM>w#w-d1t1551-1</LM>
   </w.rf>
   <form>obývák</form>
   <lemma>obývák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m137-d1e1518-x3-758">
   <w.rf>
    <LM>w#w-d1e1518-x3-758</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-759">
  <m id="m137-d1t1551-5">
   <w.rf>
    <LM>w#w-d1t1551-5</LM>
   </w.rf>
   <form>Televize</form>
   <lemma>televize</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d1t1551-6">
   <w.rf>
    <LM>w#w-d1t1551-6</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m137-d-id120867-punct">
   <w.rf>
    <LM>w#w-d-id120867-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1551-8">
   <w.rf>
    <LM>w#w-d1t1551-8</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1553-1">
   <w.rf>
    <LM>w#w-d1t1553-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1553-2">
   <w.rf>
    <LM>w#w-d1t1553-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m137-d1t1553-3">
   <w.rf>
    <LM>w#w-d1t1553-3</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m137-d1t1553-4">
   <w.rf>
    <LM>w#w-d1t1553-4</LM>
   </w.rf>
   <form>skříně</form>
   <lemma>skříň</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m137-d-id120962-punct">
   <w.rf>
    <LM>w#w-d-id120962-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1553-7">
   <w.rf>
    <LM>w#w-d1t1553-7</LM>
   </w.rf>
   <form>gauč</form>
   <lemma>gauč</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m137-d-id121002-punct">
   <w.rf>
    <LM>w#w-d-id121002-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1553-9">
   <w.rf>
    <LM>w#w-d1t1553-9</LM>
   </w.rf>
   <form>stůl</form>
   <lemma>stůl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m137-d-id121026-punct">
   <w.rf>
    <LM>w#w-d-id121026-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1553-11">
   <w.rf>
    <LM>w#w-d1t1553-11</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1553-12">
   <w.rf>
    <LM>w#w-d1t1553-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1553-13">
   <w.rf>
    <LM>w#w-d1t1553-13</LM>
   </w.rf>
   <form>jedlo</form>
   <lemma>jíst</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-759-241">
   <w.rf>
    <LM>w#w-759-241</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1553-15">
   <w.rf>
    <LM>w#w-d1t1553-15</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1553-16">
   <w.rf>
    <LM>w#w-d1t1553-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m137-d1t1553-17">
   <w.rf>
    <LM>w#w-d1t1553-17</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1553-18">
   <w.rf>
    <LM>w#w-d1t1553-18</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m137-759-760">
   <w.rf>
    <LM>w#w-759-760</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-761">
  <m id="m137-d1t1558-2">
   <w.rf>
    <LM>w#w-d1t1558-2</LM>
   </w.rf>
   <form>Vchod</form>
   <lemma>vchod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m137-d1t1558-3">
   <w.rf>
    <LM>w#w-d1t1558-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1558-4">
   <w.rf>
    <LM>w#w-d1t1558-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1558-5">
   <w.rf>
    <LM>w#w-d1t1558-5</LM>
   </w.rf>
   <form>chodby</form>
   <lemma>chodba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-d-id121253-punct">
   <w.rf>
    <LM>w#w-d-id121253-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1560-3">
   <w.rf>
    <LM>w#w-d1t1560-3</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP1----------</tag>
  </m>
  <m id="m137-d1t1560-4">
   <w.rf>
    <LM>w#w-d1t1560-4</LM>
   </w.rf>
   <form>topení</form>
   <lemma>topení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m137-d-id121333-punct">
   <w.rf>
    <LM>w#w-d-id121333-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1560-6">
   <w.rf>
    <LM>w#w-d1t1560-6</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1560-7">
   <w.rf>
    <LM>w#w-d1t1560-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m137-d1t1560-8">
   <w.rf>
    <LM>w#w-d1t1560-8</LM>
   </w.rf>
   <form>uhlí</form>
   <lemma>uhlí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m137-761-1179">
   <w.rf>
    <LM>w#w-761-1179</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-1180">
  <m id="m137-d1t1560-14">
   <w.rf>
    <LM>w#w-d1t1560-14</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1560-15">
   <w.rf>
    <LM>w#w-d1t1560-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1560-16">
   <w.rf>
    <LM>w#w-d1t1560-16</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d-id121499-punct">
   <w.rf>
    <LM>w#w-d-id121499-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1560-20">
   <w.rf>
    <LM>w#w-d1t1560-20</LM>
   </w.rf>
   <form>vypadla</form>
   <lemma>vypadnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m137-d1t1560-19">
   <w.rf>
    <LM>w#w-d1t1560-19</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1562-1">
   <w.rf>
    <LM>w#w-d1t1562-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1562-3">
   <w.rf>
    <LM>w#w-d1t1562-3</LM>
   </w.rf>
   <form>Chodova</form>
   <lemma>Chodov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m137-d1t1564-1">
   <w.rf>
    <LM>w#w-d1t1564-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m137-d1t1564-2">
   <w.rf>
    <LM>w#w-d1t1564-2</LM>
   </w.rf>
   <form>mamince</form>
   <lemma>maminka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m137-d-id121612-punct">
   <w.rf>
    <LM>w#w-d-id121612-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1562-6">
   <w.rf>
    <LM>w#w-d1t1562-6</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1562-10">
   <w.rf>
    <LM>w#w-d1t1562-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1562-9">
   <w.rf>
    <LM>w#w-d1t1562-9</LM>
   </w.rf>
   <form>prostor</form>
   <lemma>prostor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m137-d1t1562-11">
   <w.rf>
    <LM>w#w-d1t1562-11</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m137-d1t1562-12">
   <w.rf>
    <LM>w#w-d1t1562-12</LM>
   </w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAIS1----2A----</tag>
  </m>
  <m id="m137-761-804">
   <w.rf>
    <LM>w#w-761-804</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-803">
  <m id="m137-d1t1566-1">
   <w.rf>
    <LM>w#w-d1t1566-1</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Obzvláště</form>
   <lemma>obzvláště-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1566-2">
   <w.rf>
    <LM>w#w-d1t1566-2</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m137-d1t1566-3">
   <w.rf>
    <LM>w#w-d1t1566-3</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m137-d1t1566-4">
   <w.rf>
    <LM>w#w-d1t1566-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m137-d1t1566-5">
   <w.rf>
    <LM>w#w-d1t1566-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1566-6">
   <w.rf>
    <LM>w#w-d1t1566-6</LM>
   </w.rf>
   <form>fajn</form>
   <lemma>fajn-1</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m137-803-814">
   <w.rf>
    <LM>w#w-803-814</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-815">
  <m id="m137-d1t1566-8">
   <w.rf>
    <LM>w#w-d1t1566-8</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1566-9">
   <w.rf>
    <LM>w#w-d1t1566-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1566-10">
   <w.rf>
    <LM>w#w-d1t1566-10</LM>
   </w.rf>
   <form>zahrada</form>
   <lemma>zahrada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d-id121950-punct">
   <w.rf>
    <LM>w#w-d-id121950-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1566-12">
   <w.rf>
    <LM>w#w-d1t1566-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1566-13">
   <w.rf>
    <LM>w#w-d1t1566-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1566-14">
   <w.rf>
    <LM>w#w-d1t1566-14</LM>
   </w.rf>
   <form>slunce</form>
   <lemma>slunce</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m137-815-816">
   <w.rf>
    <LM>w#w-815-816</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-817">
  <m id="m137-d1t1568-3">
   <w.rf>
    <LM>w#w-d1t1568-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1568-2">
   <w.rf>
    <LM>w#w-d1t1568-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m137-d1t1568-4">
   <w.rf>
    <LM>w#w-d1t1568-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m137-d1t1568-5">
   <w.rf>
    <LM>w#w-d1t1568-5</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AANS1----3A----</tag>
  </m>
  <m id="m137-d-id122100-punct">
   <w.rf>
    <LM>w#w-d-id122100-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1568-7">
   <w.rf>
    <LM>w#w-d1t1568-7</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m137-d1t1568-8">
   <w.rf>
    <LM>w#w-d1t1568-8</LM>
   </w.rf>
   <form>mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1568-9">
   <w.rf>
    <LM>w#w-d1t1568-9</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m137-817-818">
   <w.rf>
    <LM>w#w-817-818</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-819">
  <m id="m137-d1t1571-1">
   <w.rf>
    <LM>w#w-d1t1571-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1571-3">
   <w.rf>
    <LM>w#w-d1t1571-3</LM>
   </w.rf>
   <form>Holešovicích</form>
   <lemma>Holešovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m137-d1t1571-5">
   <w.rf>
    <LM>w#w-d1t1571-5</LM>
   </w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWYS1----------</tag>
  </m>
  <m id="m137-d1t1571-6">
   <w.rf>
    <LM>w#w-d1t1571-6</LM>
   </w.rf>
   <form>dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m137-d1t1571-7">
   <w.rf>
    <LM>w#w-d1t1571-7</LM>
   </w.rf>
   <form>vzduch</form>
   <lemma>vzduch</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m137-d1t1571-8">
   <w.rf>
    <LM>w#w-d1t1571-8</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m137-819-820">
   <w.rf>
    <LM>w#w-819-820</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-821">
  <m id="m137-d1t1573-3">
   <w.rf>
    <LM>w#w-d1t1573-3</LM>
   </w.rf>
   <form>Muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1573-2">
   <w.rf>
    <LM>w#w-d1t1573-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1573-1">
   <w.rf>
    <LM>w#w-d1t1573-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1573-6">
   <w.rf>
    <LM>w#w-d1t1573-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m137-d1t1573-7">
   <w.rf>
    <LM>w#w-d1t1573-7</LM>
   </w.rf>
   <form>kočárkem</form>
   <lemma>kočárek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m137-d1t1573-8">
   <w.rf>
    <LM>w#w-d1t1573-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1573-9">
   <w.rf>
    <LM>w#w-d1t1573-9</LM>
   </w.rf>
   <form>parku</form>
   <lemma>park</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m137-821-822">
   <w.rf>
    <LM>w#w-821-822</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-823">
  <m id="m137-d1t1577-2">
   <w.rf>
    <LM>w#w-d1t1577-2</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m137-d1t1577-3">
   <w.rf>
    <LM>w#w-d1t1577-3</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m137-d1t1577-4">
   <w.rf>
    <LM>w#w-d1t1577-4</LM>
   </w.rf>
   <form>začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m137-d1t1577-5">
   <w.rf>
    <LM>w#w-d1t1577-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m137-d1t1577-6">
   <w.rf>
    <LM>w#w-d1t1577-6</LM>
   </w.rf>
   <form>zlobit</form>
   <lemma>zlobit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m137-823-10">
   <w.rf>
    <LM>w#w-823-10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-11">
  <m id="m137-d1t1577-8">
   <w.rf>
    <LM>w#w-d1t1577-8</LM>
   </w.rf>
   <form>Odvedli</form>
   <lemma>odvést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m137-d1t1577-9">
   <w.rf>
    <LM>w#w-d1t1577-9</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m137-d1t1577-10">
   <w.rf>
    <LM>w#w-d1t1577-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m137-d1t1577-11">
   <w.rf>
    <LM>w#w-d1t1577-11</LM>
   </w.rf>
   <form>vojnu</form>
   <lemma>vojna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m137-d1t1577-12">
   <w.rf>
    <LM>w#w-d1t1577-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1577-13">
   <w.rf>
    <LM>w#w-d1t1577-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1577-14">
   <w.rf>
    <LM>w#w-d1t1577-14</LM>
   </w.rf>
   <form>začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m137-d1t1577-15">
   <w.rf>
    <LM>w#w-d1t1577-15</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1577-16">
   <w.rf>
    <LM>w#w-d1t1577-16</LM>
   </w.rf>
   <form>zlobit</form>
   <lemma>zlobit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m137-11-12">
   <w.rf>
    <LM>w#w-11-12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-13">
  <m id="m137-d1t1581-1">
   <w.rf>
    <LM>w#w-d1t1581-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1584-4">
   <w.rf>
    <LM>w#w-d1t1584-4</LM>
   </w.rf>
   <form>zběhnul</form>
   <lemma>zběhnout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m137-d1t1584-2">
   <w.rf>
    <LM>w#w-d1t1584-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1584-3">
   <w.rf>
    <LM>w#w-d1t1584-3</LM>
   </w.rf>
   <form>vojny</form>
   <lemma>vojna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-d1t1584-5">
   <w.rf>
    <LM>w#w-d1t1584-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1584-6">
   <w.rf>
    <LM>w#w-d1t1584-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1584-7">
   <w.rf>
    <LM>w#w-d1t1584-7</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m137-d1t1584-8">
   <w.rf>
    <LM>w#w-d1t1584-8</LM>
   </w.rf>
   <form>chytli</form>
   <lemma>chytnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m137-13-14">
   <w.rf>
    <LM>w#w-13-14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1584-9">
   <w.rf>
    <LM>w#w-d1t1584-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m137-d1t1584-10">
   <w.rf>
    <LM>w#w-d1t1584-10</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m137-d1t1584-11">
   <w.rf>
    <LM>w#w-d1t1584-11</LM>
   </w.rf>
   <form>zavřeli</form>
   <lemma>zavřít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m137-13-15">
   <w.rf>
    <LM>w#w-13-15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-16">
  <m id="m137-d1t1586-4">
   <w.rf>
    <LM>w#w-d1t1586-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1586-2">
   <w.rf>
    <LM>w#w-d1t1586-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1586-5">
   <w.rf>
    <LM>w#w-d1t1586-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m137-d1t1586-6">
   <w.rf>
    <LM>w#w-d1t1586-6</LM>
   </w.rf>
   <form>dětmi</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m137-d1t1586-7">
   <w.rf>
    <LM>w#w-d1t1586-7</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1586-8">
   <w.rf>
    <LM>w#w-d1t1586-8</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m137-16-17">
   <w.rf>
    <LM>w#w-16-17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-18">
  <m id="m137-d1t1597-1">
   <w.rf>
    <LM>w#w-d1t1597-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1597-3">
   <w.rf>
    <LM>w#w-d1t1597-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m137-d1t1590-3">
   <w.rf>
    <LM>w#w-d1t1590-3</LM>
   </w.rf>
   <form>holce</form>
   <lemma>holka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m137-d1t1597-4">
   <w.rf>
    <LM>w#w-d1t1597-4</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m137-d1t1597-5">
   <w.rf>
    <LM>w#w-d1t1597-5</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m137-18-50">
   <w.rf>
    <LM>w#w-18-50</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1607-3">
   <w.rf>
    <LM>w#w-d1t1607-3</LM>
   </w.rf>
   <form>šly</form>
   <lemma>jít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m137-d1t1607-5">
   <w.rf>
    <LM>w#w-d1t1607-5</LM>
   </w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m137-d1t1607-4">
   <w.rf>
    <LM>w#w-d1t1607-4</LM>
   </w.rf>
   <form>děcka</form>
   <lemma>děcko</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m137-d1t1607-6">
   <w.rf>
    <LM>w#w-d1t1607-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1607-7">
   <w.rf>
    <LM>w#w-d1t1607-7</LM>
   </w.rf>
   <form>jeslí</form>
   <lemma>jesle</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m137-18-1233">
   <w.rf>
    <LM>w#w-18-1233</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-1234">
  <m id="m137-18-19">
   <w.rf>
    <LM>w#w-18-19</LM>
   </w.rf>
   <form>Tchýně</form>
   <lemma>tchýně_,s_^(^DD**tchyně)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-18-20">
   <w.rf>
    <LM>w#w-18-20</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-52-53">
   <w.rf>
    <LM>w#w-52-53</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-18-21">
   <w.rf>
    <LM>w#w-18-21</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-18-25">
   <w.rf>
    <LM>w#w-18-25</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-18-26">
   <w.rf>
    <LM>w#w-18-26</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m137-18-27">
   <w.rf>
    <LM>w#w-18-27</LM>
   </w.rf>
   <form>postarat</form>
   <lemma>postarat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m137-18-28">
   <w.rf>
    <LM>w#w-18-28</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-18-29">
   <w.rf>
    <LM>w#w-18-29</LM>
   </w.rf>
   <form>pomoci</form>
   <lemma>pomoci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m137-18-30">
   <w.rf>
    <LM>w#w-18-30</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m137-18-31">
   <w.rf>
    <LM>w#w-18-31</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m137-18-32">
   <w.rf>
    <LM>w#w-18-32</LM>
   </w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS7----------</tag>
  </m>
  <m id="m137-18-33">
   <w.rf>
    <LM>w#w-18-33</LM>
   </w.rf>
   <form>dítětem</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m137-52-55">
   <w.rf>
    <LM>w#w-52-55</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-52-54">
   <w.rf>
    <LM>w#w-52-54</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1603-1">
   <w.rf>
    <LM>w#w-d1t1603-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m137-d1t1603-2">
   <w.rf>
    <LM>w#w-d1t1603-2</LM>
   </w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>CnXP7----------</tag>
  </m>
  <m id="m137-d1t1603-3">
   <w.rf>
    <LM>w#w-d1t1603-3</LM>
   </w.rf>
   <form>dětmi</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m137-d-id123632-punct">
   <w.rf>
    <LM>w#w-d-id123632-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1603-5">
   <w.rf>
    <LM>w#w-d1t1603-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1603-6">
   <w.rf>
    <LM>w#w-d1t1603-6</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m137-52-56">
   <w.rf>
    <LM>w#w-52-56</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1518-x6">
  <m id="m137-d1t1612-1">
   <w.rf>
    <LM>w#w-d1t1612-1</LM>
   </w.rf>
   <form>Dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d1t1614-7">
   <w.rf>
    <LM>w#w-d1t1614-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1614-8">
   <w.rf>
    <LM>w#w-d1t1614-8</LM>
   </w.rf>
   <form>malinkatá</form>
   <lemma>malinkatý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m137-d1e1518-x6-58">
   <w.rf>
    <LM>w#w-d1e1518-x6-58</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1e1518-x6-59">
   <w.rf>
    <LM>w#w-d1e1518-x6-59</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1612-2">
   <w.rf>
    <LM>w#w-d1t1612-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1614-1">
   <w.rf>
    <LM>w#w-d1t1614-1</LM>
   </w.rf>
   <form>jeslí</form>
   <lemma>jesle</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m137-d1t1614-2">
   <w.rf>
    <LM>w#w-d1t1614-2</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1614-3">
   <w.rf>
    <LM>w#w-d1t1614-3</LM>
   </w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m137-d1t1614-4">
   <w.rf>
    <LM>w#w-d1t1614-4</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m137-d1t1614-10">
   <w.rf>
    <LM>w#w-d1t1614-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1618-1">
   <w.rf>
    <LM>w#w-d1t1618-1</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m137-d1t1618-8">
   <w.rf>
    <LM>w#w-d1t1618-8</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1618-10">
   <w.rf>
    <LM>w#w-d1t1618-10</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m137-d1t1618-11">
   <w.rf>
    <LM>w#w-d1t1618-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1618-12">
   <w.rf>
    <LM>w#w-d1t1618-12</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m137-d1e1518-x6-60">
   <w.rf>
    <LM>w#w-d1e1518-x6-60</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-69">
  <m id="m137-d1t1618-15">
   <w.rf>
    <LM>w#w-d1t1618-15</LM>
   </w.rf>
   <form>Šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-69-1238">
   <w.rf>
    <LM>w#w-69-1238</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1618-16">
   <w.rf>
    <LM>w#w-d1t1618-16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1618-17">
   <w.rf>
    <LM>w#w-d1t1618-17</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-69-70">
   <w.rf>
    <LM>w#w-69-70</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-71">
  <m id="m137-d1t1629-1">
   <w.rf>
    <LM>w#w-d1t1629-1</LM>
   </w.rf>
   <form>Tchýně</form>
   <lemma>tchýně_,s_^(^DD**tchyně)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d1t1629-2">
   <w.rf>
    <LM>w#w-d1t1629-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m137-d1t1629-3">
   <w.rf>
    <LM>w#w-d1t1629-3</LM>
   </w.rf>
   <form>pomáhala</form>
   <lemma>pomáhat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1629-4">
   <w.rf>
    <LM>w#w-d1t1629-4</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m137-d1t1629-5">
   <w.rf>
    <LM>w#w-d1t1629-5</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1629-6">
   <w.rf>
    <LM>w#w-d1t1629-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1629-7">
   <w.rf>
    <LM>w#w-d1t1629-7</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m137-d-id124452-punct">
   <w.rf>
    <LM>w#w-d-id124452-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1629-9">
   <w.rf>
    <LM>w#w-d1t1629-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1629-10">
   <w.rf>
    <LM>w#w-d1t1629-10</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1629-11">
   <w.rf>
    <LM>w#w-d1t1629-11</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m137-d1t1631-2">
   <w.rf>
    <LM>w#w-d1t1631-2</LM>
   </w.rf>
   <form>odvážela</form>
   <lemma>odvážet_^(něco_někam_např._autem)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1629-13">
   <w.rf>
    <LM>w#w-d1t1629-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1631-1">
   <w.rf>
    <LM>w#w-d1t1631-1</LM>
   </w.rf>
   <form>jeslí</form>
   <lemma>jesle</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m137-71-72">
   <w.rf>
    <LM>w#w-71-72</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-73">
  <m id="m137-d1t1636-5">
   <w.rf>
    <LM>w#w-d1t1636-5</LM>
   </w.rf>
   <form>Dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1636-4">
   <w.rf>
    <LM>w#w-d1t1636-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1636-6">
   <w.rf>
    <LM>w#w-d1t1636-6</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1636-7">
   <w.rf>
    <LM>w#w-d1t1636-7</LM>
   </w.rf>
   <form>šesti</form>
   <lemma>šest`6</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m137-d1t1636-8">
   <w.rf>
    <LM>w#w-d1t1636-8</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-73-91">
   <w.rf>
    <LM>w#w-73-91</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-92">
  <m id="m137-d1t1638-6">
   <w.rf>
    <LM>w#w-d1t1638-6</LM>
   </w.rf>
   <form>Vstala</form>
   <lemma>vstát</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m137-d1t1638-2">
   <w.rf>
    <LM>w#w-d1t1638-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1638-4">
   <w.rf>
    <LM>w#w-d1t1638-4</LM>
   </w.rf>
   <form>brzy</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m137-d1t1638-5">
   <w.rf>
    <LM>w#w-d1t1638-5</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-92-93">
   <w.rf>
    <LM>w#w-92-93</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1638-8">
   <w.rf>
    <LM>w#w-d1t1638-8</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1638-9">
   <w.rf>
    <LM>w#w-d1t1638-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1638-10">
   <w.rf>
    <LM>w#w-d1t1638-10</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-d-id124887-punct">
   <w.rf>
    <LM>w#w-d-id124887-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1642-1">
   <w.rf>
    <LM>w#w-d1t1642-1</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m137-d1t1642-2">
   <w.rf>
    <LM>w#w-d1t1642-2</LM>
   </w.rf>
   <form>uživila</form>
   <lemma>uživit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m137-d1t1642-4">
   <w.rf>
    <LM>w#w-d1t1642-4</LM>
   </w.rf>
   <form>svoji</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4----------</tag>
  </m>
  <m id="m137-d1t1642-5">
   <w.rf>
    <LM>w#w-d1t1642-5</LM>
   </w.rf>
   <form>rodinu</form>
   <lemma>rodina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m137-d-m-d1e1518-x7-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1518-x7-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1657-x2">
  <m id="m137-d1t1662-2">
   <w.rf>
    <LM>w#w-d1t1662-2</LM>
   </w.rf>
   <form>Stačilo</form>
   <lemma>stačit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d-id125222-punct">
   <w.rf>
    <LM>w#w-d-id125222-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1669-x2"></s>
 <s id="m137-102">
  <m id="m137-d1t1672-1">
   <w.rf>
    <LM>w#w-d1t1672-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m137-d-m-d1e1669-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1669-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1673-x2">
  <m id="m137-d1t1676-1">
   <w.rf>
    <LM>w#w-d1t1676-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m137-d1t1676-2">
   <w.rf>
    <LM>w#w-d1t1676-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1676-3">
   <w.rf>
    <LM>w#w-d1t1676-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1676-4">
   <w.rf>
    <LM>w#w-d1t1676-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m137-d1t1676-5">
   <w.rf>
    <LM>w#w-d1t1676-5</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m137-d-id125492-punct">
   <w.rf>
    <LM>w#w-d-id125492-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1677-x2">
  <m id="m137-d1t1684-1">
   <w.rf>
    <LM>w#w-d1t1684-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1684-2">
   <w.rf>
    <LM>w#w-d1t1684-2</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m137-d1t1684-3">
   <w.rf>
    <LM>w#w-d1t1684-3</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m137-d1t1684-4">
   <w.rf>
    <LM>w#w-d1t1684-4</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1688-1">
   <w.rf>
    <LM>w#w-d1t1688-1</LM>
   </w.rf>
   <form>maškarní</form>
   <lemma>maškarní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m137-d1t1688-2">
   <w.rf>
    <LM>w#w-d1t1688-2</LM>
   </w.rf>
   <form>rej</form>
   <lemma>rej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m137-d1t1691-1">
   <w.rf>
    <LM>w#w-d1t1691-1</LM>
   </w.rf>
   <form>nahoře</form>
   <lemma>nahoře</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1691-3">
   <w.rf>
    <LM>w#w-d1t1691-3</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1691-4">
   <w.rf>
    <LM>w#w-d1t1691-4</LM>
   </w.rf>
   <form>Apolináře</form>
   <lemma>Apolinář_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m137-d1e1677-x2-115">
   <w.rf>
    <LM>w#w-d1e1677-x2-115</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-119">
  <m id="m137-d1t1695-1">
   <w.rf>
    <LM>w#w-d1t1695-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1695-2">
   <w.rf>
    <LM>w#w-d1t1695-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m137-d1t1695-3">
   <w.rf>
    <LM>w#w-d1t1695-3</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m137-d1t1695-6">
   <w.rf>
    <LM>w#w-d1t1695-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1695-4">
   <w.rf>
    <LM>w#w-d1t1695-4</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m137-d1t1695-5">
   <w.rf>
    <LM>w#w-d1t1695-5</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m137-119-121">
   <w.rf>
    <LM>w#w-119-121</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1695-9">
   <w.rf>
    <LM>w#w-d1t1695-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1695-10">
   <w.rf>
    <LM>w#w-d1t1695-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1695-11">
   <w.rf>
    <LM>w#w-d1t1695-11</LM>
   </w.rf>
   <form>vrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m137-d1t1695-12">
   <w.rf>
    <LM>w#w-d1t1695-12</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1695-13">
   <w.rf>
    <LM>w#w-d1t1695-13</LM>
   </w.rf>
   <form>vojny</form>
   <lemma>vojna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-119-122">
   <w.rf>
    <LM>w#w-119-122</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-119-120">
   <w.rf>
    <LM>w#w-119-120</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1697-1">
   <w.rf>
    <LM>w#w-d1t1697-1</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1695-7">
   <w.rf>
    <LM>w#w-d1t1695-7</LM>
   </w.rf>
   <form>snažil</form>
   <lemma>snažit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-119-123">
   <w.rf>
    <LM>w#w-119-123</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-127">
  <m id="m137-d1t1699-6">
   <w.rf>
    <LM>w#w-d1t1699-6</LM>
   </w.rf>
   <form>Celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m137-d1t1699-7">
   <w.rf>
    <LM>w#w-d1t1699-7</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m137-d1t1699-11">
   <w.rf>
    <LM>w#w-d1t1699-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1699-9">
   <w.rf>
    <LM>w#w-d1t1699-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m137-d1t1699-10">
   <w.rf>
    <LM>w#w-d1t1699-10</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m137-d1t1699-12">
   <w.rf>
    <LM>w#w-d1t1699-12</LM>
   </w.rf>
   <form>apelovala</form>
   <lemma>apelovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d-id126206-punct">
   <w.rf>
    <LM>w#w-d-id126206-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1699-14">
   <w.rf>
    <LM>w#w-d1t1699-14</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1699-15">
   <w.rf>
    <LM>w#w-d1t1699-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1699-16">
   <w.rf>
    <LM>w#w-d1t1699-16</LM>
   </w.rf>
   <form>léčil</form>
   <lemma>léčit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d-id126261-punct">
   <w.rf>
    <LM>w#w-d-id126261-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1701-1">
   <w.rf>
    <LM>w#w-d1t1701-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1701-2">
   <w.rf>
    <LM>w#w-d1t1701-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1701-3">
   <w.rf>
    <LM>w#w-d1t1701-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1701-4">
   <w.rf>
    <LM>w#w-d1t1701-4</LM>
   </w.rf>
   <form>léčení</form>
   <lemma>léčení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m137-d1t1701-5">
   <w.rf>
    <LM>w#w-d1t1701-5</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1701-7">
   <w.rf>
    <LM>w#w-d1t1701-7</LM>
   </w.rf>
   <form>Apolináře</form>
   <lemma>Apolinář_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m137-127-128">
   <w.rf>
    <LM>w#w-127-128</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-131">
  <m id="m137-d1t1706-5">
   <w.rf>
    <LM>w#w-d1t1706-5</LM>
   </w.rf>
   <form>Pozvali</form>
   <lemma>pozvat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m137-d1t1706-3">
   <w.rf>
    <LM>w#w-d1t1706-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1706-4">
   <w.rf>
    <LM>w#w-d1t1706-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m137-131-25">
   <w.rf>
    <LM>w#w-131-25</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1706-7">
   <w.rf>
    <LM>w#w-d1t1706-7</LM>
   </w.rf>
   <form>manželky</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m137-131-132">
   <w.rf>
    <LM>w#w-131-132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-133">
  <m id="m137-d1t1708-1">
   <w.rf>
    <LM>w#w-d1t1708-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m137-d1t1708-3">
   <w.rf>
    <LM>w#w-d1t1708-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1708-2">
   <w.rf>
    <LM>w#w-d1t1708-2</LM>
   </w.rf>
   <form>ples</form>
   <lemma>ples</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m137-d1t1708-4">
   <w.rf>
    <LM>w#w-d1t1708-4</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m137-d1t1708-5">
   <w.rf>
    <LM>w#w-d1t1708-5</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1708-6">
   <w.rf>
    <LM>w#w-d1t1708-6</LM>
   </w.rf>
   <form>jakéhokoliv</form>
   <lemma>jakýkoliv</lemma>
   <tag>PZZS2----------</tag>
  </m>
  <m id="m137-d1t1708-7">
   <w.rf>
    <LM>w#w-d1t1708-7</LM>
   </w.rf>
   <form>alkoholu</form>
   <lemma>alkohol</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m137-133-158">
   <w.rf>
    <LM>w#w-133-158</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-157">
  <m id="m137-d1t1710-3">
   <w.rf>
    <LM>w#w-d1t1710-3</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1710-5">
   <w.rf>
    <LM>w#w-d1t1710-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1710-6">
   <w.rf>
    <LM>w#w-d1t1710-6</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m137-d1t1710-4">
   <w.rf>
    <LM>w#w-d1t1710-4</LM>
   </w.rf>
   <form>vidíte</form>
   <lemma>vidět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m137-d1t1710-7">
   <w.rf>
    <LM>w#w-d1t1710-7</LM>
   </w.rf>
   <form>pana</form>
   <lemma>pan</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m137-d1t1710-8">
   <w.rf>
    <LM>w#w-d1t1710-8</LM>
   </w.rf>
   <form>doktora</form>
   <lemma>doktor</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m137-d1t1710-10">
   <w.rf>
    <LM>w#w-d1t1710-10</LM>
   </w.rf>
   <form>Skálu</form>
   <lemma>Skála_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m137-d-id126832-punct">
   <w.rf>
    <LM>w#w-d-id126832-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1710-13">
   <w.rf>
    <LM>w#w-d1t1710-13</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m137-d1t1710-14">
   <w.rf>
    <LM>w#w-d1t1710-14</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1710-15">
   <w.rf>
    <LM>w#w-d1t1710-15</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m137-d-id126887-punct">
   <w.rf>
    <LM>w#w-d-id126887-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1710-17">
   <w.rf>
    <LM>w#w-d1t1710-17</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1710-18">
   <w.rf>
    <LM>w#w-d1t1710-18</LM>
   </w.rf>
   <form>založil</form>
   <lemma>založit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m137-d1t1712-1">
   <w.rf>
    <LM>w#w-d1t1712-1</LM>
   </w.rf>
   <form>protialkoholní</form>
   <lemma>protialkoholní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m137-d1t1712-2">
   <w.rf>
    <LM>w#w-d1t1712-2</LM>
   </w.rf>
   <form>léčebnu</form>
   <lemma>léčebna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m137-d1t1712-4">
   <w.rf>
    <LM>w#w-d1t1712-4</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1712-5">
   <w.rf>
    <LM>w#w-d1t1712-5</LM>
   </w.rf>
   <form>Apolináře</form>
   <lemma>Apolinář_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m137-157-171">
   <w.rf>
    <LM>w#w-157-171</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-172">
  <m id="m137-d1t1717-2">
   <w.rf>
    <LM>w#w-d1t1717-2</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1717-3">
   <w.rf>
    <LM>w#w-d1t1717-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1717-4">
   <w.rf>
    <LM>w#w-d1t1717-4</LM>
   </w.rf>
   <form>fotografovaná</form>
   <lemma>fotografovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m137-d1t1717-5">
   <w.rf>
    <LM>w#w-d1t1717-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m137-d1t1717-6">
   <w.rf>
    <LM>w#w-d1t1717-6</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m137-172-173">
   <w.rf>
    <LM>w#w-172-173</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-174">
  <m id="m137-d1t1717-8">
   <w.rf>
    <LM>w#w-d1t1717-8</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1717-9">
   <w.rf>
    <LM>w#w-d1t1717-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1717-10">
   <w.rf>
    <LM>w#w-d1t1717-10</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m137-d1t1717-11">
   <w.rf>
    <LM>w#w-d1t1717-11</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m137-d1t1717-12">
   <w.rf>
    <LM>w#w-d1t1717-12</LM>
   </w.rf>
   <form>nějakého</form>
   <lemma>nějaký</lemma>
   <tag>PZMS4----------</tag>
  </m>
  <m id="m137-d1t1717-13">
   <w.rf>
    <LM>w#w-d1t1717-13</LM>
   </w.rf>
   <form>šaška</form>
   <lemma>šašek</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m137-d1t1719-1">
   <w.rf>
    <LM>w#w-d1t1719-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1719-2">
   <w.rf>
    <LM>w#w-d1t1719-2</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m137-d1t1719-3">
   <w.rf>
    <LM>w#w-d1t1719-3</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-174-189">
   <w.rf>
    <LM>w#w-174-189</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1719-7">
   <w.rf>
    <LM>w#w-d1t1719-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m137-d1t1719-8">
   <w.rf>
    <LM>w#w-d1t1719-8</LM>
   </w.rf>
   <form>pierota</form>
   <lemma>pierot</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m137-174-175">
   <w.rf>
    <LM>w#w-174-175</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-176">
  <m id="m137-d1t1721-2">
   <w.rf>
    <LM>w#w-d1t1721-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1721-3">
   <w.rf>
    <LM>w#w-d1t1721-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m137-d1t1721-4">
   <w.rf>
    <LM>w#w-d1t1721-4</LM>
   </w.rf>
   <form>maškarní</form>
   <lemma>maškarní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m137-d-id127484-punct">
   <w.rf>
    <LM>w#w-d-id127484-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1721-6">
   <w.rf>
    <LM>w#w-d1t1721-6</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1721-7">
   <w.rf>
    <LM>w#w-d1t1721-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1721-8">
   <w.rf>
    <LM>w#w-d1t1721-8</LM>
   </w.rf>
   <form>nenosily</form>
   <lemma>nosit</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m137-d1t1721-9">
   <w.rf>
    <LM>w#w-d1t1721-9</LM>
   </w.rf>
   <form>masky</form>
   <lemma>maska</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m137-176-190">
   <w.rf>
    <LM>w#w-176-190</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-191">
  <m id="m137-d1t1721-12">
   <w.rf>
    <LM>w#w-d1t1721-12</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1721-13">
   <w.rf>
    <LM>w#w-d1t1721-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m137-d1t1721-14">
   <w.rf>
    <LM>w#w-d1t1721-14</LM>
   </w.rf>
   <form>maškarní</form>
   <lemma>maškarní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m137-d1t1721-15">
   <w.rf>
    <LM>w#w-d1t1721-15</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1721-16">
   <w.rf>
    <LM>w#w-d1t1721-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m137-d1t1721-17">
   <w.rf>
    <LM>w#w-d1t1721-17</LM>
   </w.rf>
   <form>převlecích</form>
   <lemma>převlek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m137-191-192">
   <w.rf>
    <LM>w#w-191-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-193">
  <m id="m137-d1t1723-2">
   <w.rf>
    <LM>w#w-d1t1723-2</LM>
   </w.rf>
   <form>Náhodou</form>
   <lemma>náhodou_^(udělat_něco_náhodou,_tj._náhodným_zp.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1723-3">
   <w.rf>
    <LM>w#w-d1t1723-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m137-d1t1723-4">
   <w.rf>
    <LM>w#w-d1t1723-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m137-d1t1723-6">
   <w.rf>
    <LM>w#w-d1t1723-6</LM>
   </w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m137-d1t1723-7">
   <w.rf>
    <LM>w#w-d1t1723-7</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m137-d1t1723-5">
   <w.rf>
    <LM>w#w-d1t1723-5</LM>
   </w.rf>
   <form>vybrali</form>
   <lemma>vybrat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m137-d1t1723-8">
   <w.rf>
    <LM>w#w-d1t1723-8</LM>
   </w.rf>
   <form>stejný</form>
   <lemma>stejný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m137-d1t1723-9">
   <w.rf>
    <LM>w#w-d1t1723-9</LM>
   </w.rf>
   <form>převlek</form>
   <lemma>převlek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m137-d-m-d1e1677-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1677-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1724-x2">
  <m id="m137-d1t1727-1">
   <w.rf>
    <LM>w#w-d1t1727-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1727-2">
   <w.rf>
    <LM>w#w-d1t1727-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m137-d1t1727-3">
   <w.rf>
    <LM>w#w-d1t1727-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1727-4">
   <w.rf>
    <LM>w#w-d1t1727-4</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m137-d1t1727-5">
   <w.rf>
    <LM>w#w-d1t1727-5</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m137-d1t1727-6">
   <w.rf>
    <LM>w#w-d1t1727-6</LM>
   </w.rf>
   <form>léčil</form>
   <lemma>léčit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d-id127976-punct">
   <w.rf>
    <LM>w#w-d-id127976-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-d1e1728-x2">
  <m id="m137-d1t1733-1">
   <w.rf>
    <LM>w#w-d1t1733-1</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m137-d1t1733-2">
   <w.rf>
    <LM>w#w-d1t1733-2</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m137-d1t1733-3">
   <w.rf>
    <LM>w#w-d1t1733-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1733-4">
   <w.rf>
    <LM>w#w-d1t1733-4</LM>
   </w.rf>
   <form>léčil</form>
   <lemma>léčit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d-id128108-punct">
   <w.rf>
    <LM>w#w-d-id128108-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1733-6">
   <w.rf>
    <LM>w#w-d1t1733-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1733-7">
   <w.rf>
    <LM>w#w-d1t1733-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1733-8">
   <w.rf>
    <LM>w#w-d1t1733-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m137-d1t1733-9">
   <w.rf>
    <LM>w#w-d1t1733-9</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m137-d1e1728-x2-209">
   <w.rf>
    <LM>w#w-d1e1728-x2-209</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-210">
  <m id="m137-d1t1733-11">
   <w.rf>
    <LM>w#w-d1t1733-11</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m137-d1t1733-12">
   <w.rf>
    <LM>w#w-d1t1733-12</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m137-d1t1733-13">
   <w.rf>
    <LM>w#w-d1t1733-13</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1733-14">
   <w.rf>
    <LM>w#w-d1t1733-14</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-210-211">
   <w.rf>
    <LM>w#w-210-211</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-212">
  <m id="m137-d1t1739-1">
   <w.rf>
    <LM>w#w-d1t1739-1</LM>
   </w.rf>
   <form>Přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m137-d1t1739-2">
   <w.rf>
    <LM>w#w-d1t1739-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1739-3">
   <w.rf>
    <LM>w#w-d1t1739-3</LM>
   </w.rf>
   <form>vojny</form>
   <lemma>vojna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m137-212-213">
   <w.rf>
    <LM>w#w-212-213</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1739-4">
   <w.rf>
    <LM>w#w-d1t1739-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m137-d1t1739-6">
   <w.rf>
    <LM>w#w-d1t1739-6</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m137-d1t1739-7">
   <w.rf>
    <LM>w#w-d1t1739-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1739-12">
   <w.rf>
    <LM>w#w-d1t1739-12</LM>
   </w.rf>
   <form>malinko</form>
   <lemma>malinko-1_^(málo_peněz)</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m137-d1t1739-10">
   <w.rf>
    <LM>w#w-d1t1739-10</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m137-d1t1739-11">
   <w.rf>
    <LM>w#w-d1t1739-11</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m137-212-69">
   <w.rf>
    <LM>w#w-212-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-75">
  <m id="m137-d1t1744-1">
   <w.rf>
    <LM>w#w-d1t1744-1</LM>
   </w.rf>
   <form>Šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1744-2">
   <w.rf>
    <LM>w#w-d1t1744-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1744-3">
   <w.rf>
    <LM>w#w-d1t1744-3</LM>
   </w.rf>
   <form>dobrovolně</form>
   <lemma>dobrovolně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m137-d1t1744-4">
   <w.rf>
    <LM>w#w-d1t1744-4</LM>
   </w.rf>
   <form>léčit</form>
   <lemma>léčit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m137-d1t1744-5">
   <w.rf>
    <LM>w#w-d1t1744-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m137-d1t1744-7">
   <w.rf>
    <LM>w#w-d1t1744-7</LM>
   </w.rf>
   <form>Apolináři</form>
   <lemma>Apolinář_;Y</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m137-212-214">
   <w.rf>
    <LM>w#w-212-214</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1746-1">
   <w.rf>
    <LM>w#w-d1t1746-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1746-2">
   <w.rf>
    <LM>w#w-d1t1746-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m137-d1t1746-3">
   <w.rf>
    <LM>w#w-d1t1746-3</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m137-d1t1746-5">
   <w.rf>
    <LM>w#w-d1t1746-5</LM>
   </w.rf>
   <form>dobrovolně</form>
   <lemma>dobrovolně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m137-d1t1746-6">
   <w.rf>
    <LM>w#w-d1t1746-6</LM>
   </w.rf>
   <form>léčit</form>
   <lemma>léčit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m137-d1t1746-7">
   <w.rf>
    <LM>w#w-d1t1746-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1746-9">
   <w.rf>
    <LM>w#w-d1t1746-9</LM>
   </w.rf>
   <form>Bohnic</form>
   <lemma>Bohnice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m137-d-id128773-punct">
   <w.rf>
    <LM>w#w-d-id128773-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m137-d1t1748-1">
   <w.rf>
    <LM>w#w-d1t1748-1</LM>
   </w.rf>
   <form>jenomže</form>
   <lemma>jenomže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m137-d1t1748-4">
   <w.rf>
    <LM>w#w-d1t1748-4</LM>
   </w.rf>
   <form>léčbu</form>
   <lemma>léčba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m137-d1t1748-2">
   <w.rf>
    <LM>w#w-d1t1748-2</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1750-1">
   <w.rf>
    <LM>w#w-d1t1750-1</LM>
   </w.rf>
   <form>nějakým</form>
   <lemma>nějaký</lemma>
   <tag>PZZS7----------</tag>
  </m>
  <m id="m137-d1t1750-2">
   <w.rf>
    <LM>w#w-d1t1750-2</LM>
   </w.rf>
   <form>způsobem</form>
   <lemma>způsob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m137-d1t1752-1">
   <w.rf>
    <LM>w#w-d1t1752-1</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m137-d1t1752-2">
   <w.rf>
    <LM>w#w-d1t1752-2</LM>
   </w.rf>
   <form>ukončil</form>
   <lemma>ukončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m137-212-215">
   <w.rf>
    <LM>w#w-212-215</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m137-216">
  <m id="m137-d1t1752-4">
   <w.rf>
    <LM>w#w-d1t1752-4</LM>
   </w.rf>
   <form>Nevydržel</form>
   <lemma>vydržet</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m137-d1t1752-5">
   <w.rf>
    <LM>w#w-d1t1752-5</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m137-d1t1752-6">
   <w.rf>
    <LM>w#w-d1t1752-6</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m137-d1t1752-7">
   <w.rf>
    <LM>w#w-d1t1752-7</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m137-d1t1752-8">
   <w.rf>
    <LM>w#w-d1t1752-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m137-d1t1752-9">
   <w.rf>
    <LM>w#w-d1t1752-9</LM>
   </w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m137-216-217">
   <w.rf>
    <LM>w#w-216-217</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
