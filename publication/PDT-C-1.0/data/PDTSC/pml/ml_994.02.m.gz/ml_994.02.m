<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_994.02.w.gz" />
  </references>
 </head>
 <s id="m994-25819_04-d1e555-x8">
  <m id="m994-d1t627-1">
   <w.rf>
    <LM>w#w-d1t627-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t627-2">
   <w.rf>
    <LM>w#w-d1t627-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d1t627-4">
   <w.rf>
    <LM>w#w-d1t627-4</LM>
   </w.rf>
   <form>nadával</form>
   <lemma>nadávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t627-5">
   <w.rf>
    <LM>w#w-d1t627-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1e555-x8-2101">
   <w.rf>
    <LM>w#w-d1e555-x8-2101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e555-x8-2102">
   <w.rf>
    <LM>w#w-d1e555-x8-2102</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d-id74734">
   <w.rf>
    <LM>w#w-d-id74734</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e628-x2">
  <m id="m994-d1t633-2">
   <w.rf>
    <LM>w#w-d1t633-2</LM>
   </w.rf>
   <form>Oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m994-d1t633-3">
   <w.rf>
    <LM>w#w-d1t633-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t633-4">
   <w.rf>
    <LM>w#w-d1t633-4</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t633-5">
   <w.rf>
    <LM>w#w-d1t633-5</LM>
   </w.rf>
   <form>znali</form>
   <lemma>znát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d-id74952">
   <w.rf>
    <LM>w#w-d-id74952</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e636-x2">
  <m id="m994-d1t639-3">
   <w.rf>
    <LM>w#w-d1t639-3</LM>
   </w.rf>
   <form>Školil</form>
   <lemma>školit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t639-2">
   <w.rf>
    <LM>w#w-d1t639-2</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m994-d-id75081">
   <w.rf>
    <LM>w#w-d-id75081</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e640-x2">
  <m id="m994-d1t643-1">
   <w.rf>
    <LM>w#w-d1t643-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t643-2">
   <w.rf>
    <LM>w#w-d1t643-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t643-3">
   <w.rf>
    <LM>w#w-d1t643-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t643-5">
   <w.rf>
    <LM>w#w-d1t643-5</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m994-d1t643-6">
   <w.rf>
    <LM>w#w-d1t643-6</LM>
   </w.rf>
   <form>žák</form>
   <lemma>žák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d-id75219">
   <w.rf>
    <LM>w#w-d-id75219</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e645-x2">
  <m id="m994-d1t648-1">
   <w.rf>
    <LM>w#w-d1t648-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-d-id75269">
   <w.rf>
    <LM>w#w-d-id75269</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x2">
  <m id="m994-d1t656-5">
   <w.rf>
    <LM>w#w-d1t656-5</LM>
   </w.rf>
   <form>Zařídil</form>
   <lemma>zařídit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t656-3">
   <w.rf>
    <LM>w#w-d1t656-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m994-d-id75505">
   <w.rf>
    <LM>w#w-d-id75505</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t656-7">
   <w.rf>
    <LM>w#w-d1t656-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t656-8">
   <w.rf>
    <LM>w#w-d1t656-8</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m994-d1t656-9">
   <w.rf>
    <LM>w#w-d1t656-9</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1e653-x2-2221">
   <w.rf>
    <LM>w#w-d1e653-x2-2221</LM>
   </w.rf>
   <form>pustili</form>
   <lemma>pustit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1e653-x2-2222">
   <w.rf>
    <LM>w#w-d1e653-x2-2222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-2223">
  <m id="m994-d1t658-4">
   <w.rf>
    <LM>w#w-d1t658-4</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t658-3">
   <w.rf>
    <LM>w#w-d1t658-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t660-3">
   <w.rf>
    <LM>w#w-d1t660-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t660-4">
   <w.rf>
    <LM>w#w-d1t660-4</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m994-d1t660-1">
   <w.rf>
    <LM>w#w-d1t660-1</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m994-d1t660-2">
   <w.rf>
    <LM>w#w-d1t660-2</LM>
   </w.rf>
   <form>zázraky</form>
   <lemma>zázrak</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m994-2223-2235">
   <w.rf>
    <LM>w#w-2223-2235</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t660-5">
   <w.rf>
    <LM>w#w-d1t660-5</LM>
   </w.rf>
   <form>víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m994-d-id75742">
   <w.rf>
    <LM>w#w-d-id75742</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x3">
  <m id="m994-d1t671-1">
   <w.rf>
    <LM>w#w-d1t671-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t671-2">
   <w.rf>
    <LM>w#w-d1t671-2</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m994-d1t671-3">
   <w.rf>
    <LM>w#w-d1t671-3</LM>
   </w.rf>
   <form>psem</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m994-d1t671-4">
   <w.rf>
    <LM>w#w-d1t671-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t671-5">
   <w.rf>
    <LM>w#w-d1t671-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t673-3">
   <w.rf>
    <LM>w#w-d1t673-3</LM>
   </w.rf>
   <form>občankou</form>
   <lemma>občanka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m994-d1t673-4">
   <w.rf>
    <LM>w#w-d1t673-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t673-6">
   <w.rf>
    <LM>w#w-d1t673-6</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t673-7">
   <w.rf>
    <LM>w#w-d1t673-7</LM>
   </w.rf>
   <form>tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d-id76044">
   <w.rf>
    <LM>w#w-d-id76044</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x4">
  <m id="m994-d1t677-2">
   <w.rf>
    <LM>w#w-d1t677-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t677-3">
   <w.rf>
    <LM>w#w-d1t677-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m994-d1t677-4">
   <w.rf>
    <LM>w#w-d1t677-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t677-5">
   <w.rf>
    <LM>w#w-d1t677-5</LM>
   </w.rf>
   <form>třetice</form>
   <lemma>třetice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m994-d-id76154">
   <w.rf>
    <LM>w#w-d-id76154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x5">
  <m id="m994-d1t695-2">
   <w.rf>
    <LM>w#w-d1t695-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t695-3">
   <w.rf>
    <LM>w#w-d1t695-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m994-d1t695-4">
   <w.rf>
    <LM>w#w-d1t695-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m994-d1e653-x5-2413">
   <w.rf>
    <LM>w#w-d1e653-x5-2413</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-2404">
  <m id="m994-2404-1152">
   <w.rf>
    <LM>w#w-2404-1152</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t695-7">
   <w.rf>
    <LM>w#w-d1t695-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t695-6">
   <w.rf>
    <LM>w#w-d1t695-6</LM>
   </w.rf>
   <form>vrátila</form>
   <lemma>vrátit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t695-8">
   <w.rf>
    <LM>w#w-d1t695-8</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m994-d1t695-9">
   <w.rf>
    <LM>w#w-d1t695-9</LM>
   </w.rf>
   <form>přítelkyně</form>
   <lemma>přítelkyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d1t695-10">
   <w.rf>
    <LM>w#w-d1t695-10</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t695-11">
   <w.rf>
    <LM>w#w-d1t695-11</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m994-d1t697-1">
   <w.rf>
    <LM>w#w-d1t697-1</LM>
   </w.rf>
   <form>bratra</form>
   <lemma>bratr</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m994-d1t706-1">
   <w.rf>
    <LM>w#w-d1t706-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t706-4">
   <w.rf>
    <LM>w#w-d1t706-4</LM>
   </w.rf>
   <form>hledala</form>
   <lemma>hledat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t706-5">
   <w.rf>
    <LM>w#w-d1t706-5</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m994-d-id76579">
   <w.rf>
    <LM>w#w-d-id76579</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t706-7">
   <w.rf>
    <LM>w#w-d1t706-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t706-8">
   <w.rf>
    <LM>w#w-d1t706-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t706-9">
   <w.rf>
    <LM>w#w-d1t706-9</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m994-d1t706-10">
   <w.rf>
    <LM>w#w-d1t706-10</LM>
   </w.rf>
   <form>poznala</form>
   <lemma>poznat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-2404-1421">
   <w.rf>
    <LM>w#w-2404-1421</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1422">
  <m id="m994-d1t708-4">
   <w.rf>
    <LM>w#w-d1t708-4</LM>
   </w.rf>
   <form>Dala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t708-3">
   <w.rf>
    <LM>w#w-d1t708-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m994-d1t710-1">
   <w.rf>
    <LM>w#w-d1t710-1</LM>
   </w.rf>
   <form>potravinové</form>
   <lemma>potravinový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m994-d1t710-2">
   <w.rf>
    <LM>w#w-d1t710-2</LM>
   </w.rf>
   <form>lístky</form>
   <lemma>lístek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m994-d1t710-3">
   <w.rf>
    <LM>w#w-d1t710-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t712-3">
   <w.rf>
    <LM>w#w-d1t712-3</LM>
   </w.rf>
   <form>ujala</form>
   <lemma>ujmout</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t710-5">
   <w.rf>
    <LM>w#w-d1t710-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t712-1">
   <w.rf>
    <LM>w#w-d1t712-1</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m994-2404-2424">
   <w.rf>
    <LM>w#w-2404-2424</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t712-4">
   <w.rf>
    <LM>w#w-d1t712-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t712-5">
   <w.rf>
    <LM>w#w-d1t712-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t714-1">
   <w.rf>
    <LM>w#w-d1t714-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t714-2">
   <w.rf>
    <LM>w#w-d1t714-2</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m994-d1t719-1">
   <w.rf>
    <LM>w#w-d1t719-1</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d1t719-2">
   <w.rf>
    <LM>w#w-d1t719-2</LM>
   </w.rf>
   <form>lehčího</form>
   <lemma>lehký</lemma>
   <tag>AAIS2----2A----</tag>
  </m>
  <m id="m994-d1t719-3">
   <w.rf>
    <LM>w#w-d1t719-3</LM>
   </w.rf>
   <form>kalibru</form>
   <lemma>kalibr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m994-2404-2425">
   <w.rf>
    <LM>w#w-2404-2425</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x6">
  <m id="m994-d1t725-1">
   <w.rf>
    <LM>w#w-d1t725-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t725-5">
   <w.rf>
    <LM>w#w-d1t725-5</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t725-3">
   <w.rf>
    <LM>w#w-d1t725-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t725-4">
   <w.rf>
    <LM>w#w-d1t725-4</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m994-d1t725-6">
   <w.rf>
    <LM>w#w-d1t725-6</LM>
   </w.rf>
   <form>důvěřovala</form>
   <lemma>důvěřovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d-id77247">
   <w.rf>
    <LM>w#w-d-id77247</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t725-8">
   <w.rf>
    <LM>w#w-d1t725-8</LM>
   </w.rf>
   <form>poněvadž</form>
   <lemma>poněvadž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t725-10">
   <w.rf>
    <LM>w#w-d1t725-10</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d1t725-11">
   <w.rf>
    <LM>w#w-d1t725-11</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t725-12">
   <w.rf>
    <LM>w#w-d1t725-12</LM>
   </w.rf>
   <form>pomáhala</form>
   <lemma>pomáhat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1e653-x6-2517">
   <w.rf>
    <LM>w#w-d1e653-x6-2517</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-2510">
  <m id="m994-d1t734-1">
   <w.rf>
    <LM>w#w-d1t734-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t734-2">
   <w.rf>
    <LM>w#w-d1t734-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t734-3">
   <w.rf>
    <LM>w#w-d1t734-3</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m994-d1t734-4">
   <w.rf>
    <LM>w#w-d1t734-4</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t734-5">
   <w.rf>
    <LM>w#w-d1t734-5</LM>
   </w.rf>
   <form>povětrná</form>
   <lemma>povětrný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m994-d1t734-6">
   <w.rf>
    <LM>w#w-d1t734-6</LM>
   </w.rf>
   <form>ženská</form>
   <lemma>ženská_^(osoba)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d-id77549">
   <w.rf>
    <LM>w#w-d-id77549</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t734-8">
   <w.rf>
    <LM>w#w-d1t734-8</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t734-9">
   <w.rf>
    <LM>w#w-d1t734-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t734-10">
   <w.rf>
    <LM>w#w-d1t734-10</LM>
   </w.rf>
   <form>Alcronu</form>
   <lemma>Alcron_;m</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m994-2510-2521">
   <w.rf>
    <LM>w#w-2510-2521</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t734-11">
   <w.rf>
    <LM>w#w-d1t734-11</LM>
   </w.rf>
   <form>seznamovala</form>
   <lemma>seznamovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t734-12">
   <w.rf>
    <LM>w#w-d1t734-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t734-13">
   <w.rf>
    <LM>w#w-d1t734-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t734-14">
   <w.rf>
    <LM>w#w-d1t734-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t734-15">
   <w.rf>
    <LM>w#w-d1t734-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-2510-2522">
   <w.rf>
    <LM>w#w-2510-2522</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-2523">
  <m id="m994-d1t734-18">
   <w.rf>
    <LM>w#w-d1t734-18</LM>
   </w.rf>
   <form>Češka</form>
   <lemma>Češka-1_;E</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d1t734-19">
   <w.rf>
    <LM>w#w-d1t734-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t734-20">
   <w.rf>
    <LM>w#w-d1t734-20</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d-id77752">
   <w.rf>
    <LM>w#w-d-id77752</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x7">
  <m id="m994-d1t745-3">
   <w.rf>
    <LM>w#w-d1t745-3</LM>
   </w.rf>
   <form>Naši</form>
   <lemma>naši_,h</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m994-d1t745-4">
   <w.rf>
    <LM>w#w-d1t745-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t745-5">
   <w.rf>
    <LM>w#w-d1t745-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t745-6">
   <w.rf>
    <LM>w#w-d1t745-6</LM>
   </w.rf>
   <form>cizině</form>
   <lemma>cizina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m994-d1e653-x7-2715">
   <w.rf>
    <LM>w#w-d1e653-x7-2715</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t749-1">
   <w.rf>
    <LM>w#w-d1t749-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t749-2">
   <w.rf>
    <LM>w#w-d1t749-2</LM>
   </w.rf>
   <form>Holandsku</form>
   <lemma>Holandsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m994-d1e653-x7-2722">
   <w.rf>
    <LM>w#w-d1e653-x7-2722</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t745-7">
   <w.rf>
    <LM>w#w-d1t745-7</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m994-d1t751-1">
   <w.rf>
    <LM>w#w-d1t751-1</LM>
   </w.rf>
   <form>ulité</form>
   <lemma>ulitý_^(*3ít)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m994-d1t745-8">
   <w.rf>
    <LM>w#w-d1t745-8</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m994-d-id77945">
   <w.rf>
    <LM>w#w-d-id77945</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x10">
  <m id="m994-d1t758-2">
   <w.rf>
    <LM>w#w-d1t758-2</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t758-3">
   <w.rf>
    <LM>w#w-d1t758-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t758-8">
   <w.rf>
    <LM>w#w-d1t758-8</LM>
   </w.rf>
   <form>dobrého</form>
   <lemma>dobrý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m994-d1t758-9">
   <w.rf>
    <LM>w#w-d1t758-9</LM>
   </w.rf>
   <form>známého</form>
   <lemma>známý-1_^(potkat_známého_[člověka])</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m994-d-id78222">
   <w.rf>
    <LM>w#w-d-id78222</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t760-2">
   <w.rf>
    <LM>w#w-d1t760-2</LM>
   </w.rf>
   <form>advokáta</form>
   <lemma>advokát</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m994-d1e653-x10-2788">
   <w.rf>
    <LM>w#w-d1e653-x10-2788</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t768-3">
   <w.rf>
    <LM>w#w-d1t768-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t768-4">
   <w.rf>
    <LM>w#w-d1t768-4</LM>
   </w.rf>
   <form>něho</form>
   <lemma>on-1</lemma>
   <tag>PEZS2--3------1</tag>
  </m>
  <m id="m994-d1t768-1">
   <w.rf>
    <LM>w#w-d1t768-1</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t768-2">
   <w.rf>
    <LM>w#w-d1t768-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t768-5">
   <w.rf>
    <LM>w#w-d1t768-5</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m994-d1t768-6">
   <w.rf>
    <LM>w#w-d1t768-6</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m994-d1t768-7">
   <w.rf>
    <LM>w#w-d1t768-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t768-8">
   <w.rf>
    <LM>w#w-d1t768-8</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m994-d1t768-9">
   <w.rf>
    <LM>w#w-d1t768-9</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m994-d1t768-10">
   <w.rf>
    <LM>w#w-d1t768-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-d1t768-14">
   <w.rf>
    <LM>w#w-d1t768-14</LM>
   </w.rf>
   <form>obhospodařoval</form>
   <lemma>obhospodařovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d-id78693">
   <w.rf>
    <LM>w#w-d-id78693</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x11">
  <m id="m994-d1t773-1">
   <w.rf>
    <LM>w#w-d1t773-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m994-d1t773-2">
   <w.rf>
    <LM>w#w-d1t773-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t773-3">
   <w.rf>
    <LM>w#w-d1t773-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m994-d-id78769">
   <w.rf>
    <LM>w#w-d-id78769</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t773-6">
   <w.rf>
    <LM>w#w-d1t773-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t773-7">
   <w.rf>
    <LM>w#w-d1t773-7</LM>
   </w.rf>
   <form>nevěděla</form>
   <lemma>vědět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m994-d1e653-x11-1459">
   <w.rf>
    <LM>w#w-d1e653-x11-1459</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1460">
  <m id="m994-d1t773-9">
   <w.rf>
    <LM>w#w-d1t773-9</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t773-10">
   <w.rf>
    <LM>w#w-d1t773-10</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d-id78853">
   <w.rf>
    <LM>w#w-d-id78853</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t773-12">
   <w.rf>
    <LM>w#w-d1t773-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t773-13">
   <w.rf>
    <LM>w#w-d1t773-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t773-14">
   <w.rf>
    <LM>w#w-d1t773-14</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m994-d1t773-15">
   <w.rf>
    <LM>w#w-d1t773-15</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d-id78921">
   <w.rf>
    <LM>w#w-d-id78921</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x12">
  <m id="m994-d1t779-6">
   <w.rf>
    <LM>w#w-d1t779-6</LM>
   </w.rf>
   <form>Řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t779-2">
   <w.rf>
    <LM>w#w-d1t779-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t779-3">
   <w.rf>
    <LM>w#w-d1t779-3</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m994-d1t779-4">
   <w.rf>
    <LM>w#w-d1t779-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t779-5">
   <w.rf>
    <LM>w#w-d1t779-5</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m994-d-id79047">
   <w.rf>
    <LM>w#w-d-id79047</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t784-1">
   <w.rf>
    <LM>w#w-d1t784-1</LM>
   </w.rf>
   <form>dala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t784-2">
   <w.rf>
    <LM>w#w-d1t784-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t784-3">
   <w.rf>
    <LM>w#w-d1t784-3</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m994-d1e653-x12-2898">
   <w.rf>
    <LM>w#w-d1e653-x12-2898</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t784-4">
   <w.rf>
    <LM>w#w-d1t784-4</LM>
   </w.rf>
   <form>blbec</form>
   <lemma>blbec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1e653-x12-2899">
   <w.rf>
    <LM>w#w-d1e653-x12-2899</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t784-5">
   <w.rf>
    <LM>w#w-d1t784-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-d1t784-6">
   <w.rf>
    <LM>w#w-d1t784-6</LM>
   </w.rf>
   <form>adresu</form>
   <lemma>adresa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m994-d1e653-x12-1465">
   <w.rf>
    <LM>w#w-d1e653-x12-1465</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1466">
  <m id="m994-d1t788-3">
   <w.rf>
    <LM>w#w-d1t788-3</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t788-2">
   <w.rf>
    <LM>w#w-d1t788-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m994-d1t788-4">
   <w.rf>
    <LM>w#w-d1t788-4</LM>
   </w.rf>
   <form>nabořila</form>
   <lemma>nabořit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t788-5">
   <w.rf>
    <LM>w#w-d1t788-5</LM>
   </w.rf>
   <form>nějakého</form>
   <lemma>nějaký</lemma>
   <tag>PZMS4----------</tag>
  </m>
  <m id="m994-d1t788-6">
   <w.rf>
    <LM>w#w-d1t788-6</LM>
   </w.rf>
   <form>Holanďana</form>
   <lemma>Holanďan_;E</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m994-d1t792-1">
   <w.rf>
    <LM>w#w-d1t792-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t792-2">
   <w.rf>
    <LM>w#w-d1t792-2</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m994-d1t792-3">
   <w.rf>
    <LM>w#w-d1t792-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m994-d1t792-4">
   <w.rf>
    <LM>w#w-d1t792-4</LM>
   </w.rf>
   <form>vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d-id79463">
   <w.rf>
    <LM>w#w-d-id79463</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x13">
  <m id="m994-d1t794-4">
   <w.rf>
    <LM>w#w-d1t794-4</LM>
   </w.rf>
   <form>Vyzvedli</form>
   <lemma>vyzvednout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m994-d1t794-3">
   <w.rf>
    <LM>w#w-d1t794-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-d1e653-x13-3001">
   <w.rf>
    <LM>w#w-d1e653-x13-3001</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-2992">
  <m id="m994-d1t797-4">
   <w.rf>
    <LM>w#w-d1t797-4</LM>
   </w.rf>
   <form>Dala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t797-3">
   <w.rf>
    <LM>w#w-d1t797-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t797-5">
   <w.rf>
    <LM>w#w-d1t797-5</LM>
   </w.rf>
   <form>příkaz</form>
   <lemma>příkaz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m994-2992-3006">
   <w.rf>
    <LM>w#w-2992-3006</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t799-1">
   <w.rf>
    <LM>w#w-d1t799-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t799-2">
   <w.rf>
    <LM>w#w-d1t799-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m994-d1t799-3">
   <w.rf>
    <LM>w#w-d1t799-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-d1t799-4">
   <w.rf>
    <LM>w#w-d1t799-4</LM>
   </w.rf>
   <form>přivezla</form>
   <lemma>přivézt</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d-id79730">
   <w.rf>
    <LM>w#w-d-id79730</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x14">
  <m id="m994-d1t805-2">
   <w.rf>
    <LM>w#w-d1t805-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t805-3">
   <w.rf>
    <LM>w#w-d1t805-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m994-d1t805-4">
   <w.rf>
    <LM>w#w-d1t805-4</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m994-d1t805-5">
   <w.rf>
    <LM>w#w-d1t805-5</LM>
   </w.rf>
   <form>doktor</form>
   <lemma>doktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1t805-6">
   <w.rf>
    <LM>w#w-d1t805-6</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t805-7">
   <w.rf>
    <LM>w#w-d1t805-7</LM>
   </w.rf>
   <form>huboval</form>
   <lemma>hubovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1e653-x14-3126">
   <w.rf>
    <LM>w#w-d1e653-x14-3126</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-3127">
  <m id="m994-d1t812-6">
   <w.rf>
    <LM>w#w-d1t812-6</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t812-7">
   <w.rf>
    <LM>w#w-d1t812-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t812-8">
   <w.rf>
    <LM>w#w-d1t812-8</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m994-d1t812-10">
   <w.rf>
    <LM>w#w-d1t812-10</LM>
   </w.rf>
   <form>proces</form>
   <lemma>proces</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m994-3127-3139">
   <w.rf>
    <LM>w#w-3127-3139</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-3140">
  <m id="m994-d1t816-1">
   <w.rf>
    <LM>w#w-d1t816-1</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m994-d1t816-2">
   <w.rf>
    <LM>w#w-d1t816-2</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m994-d1t816-3">
   <w.rf>
    <LM>w#w-d1t816-3</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1t812-14">
   <w.rf>
    <LM>w#w-d1t812-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t812-13">
   <w.rf>
    <LM>w#w-d1t812-13</LM>
   </w.rf>
   <form>prý</form>
   <lemma>prý</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-d1t812-15">
   <w.rf>
    <LM>w#w-d1t812-15</LM>
   </w.rf>
   <form>zasebevraždil</form>
   <lemma>zasebevraždit_,e</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d-id80122">
   <w.rf>
    <LM>w#w-d-id80122</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t812-17">
   <w.rf>
    <LM>w#w-d1t812-17</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t812-18">
   <w.rf>
    <LM>w#w-d1t812-18</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m994-d1t812-19">
   <w.rf>
    <LM>w#w-d1t812-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t812-20">
   <w.rf>
    <LM>w#w-d1t812-20</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d-id80193">
   <w.rf>
    <LM>w#w-d-id80193</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t812-22">
   <w.rf>
    <LM>w#w-d1t812-22</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m994-3140-1482">
   <w.rf>
    <LM>w#w-3140-1482</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1483">
  <m id="m994-d1t818-3">
   <w.rf>
    <LM>w#w-d1t818-3</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t818-2">
   <w.rf>
    <LM>w#w-d1t818-2</LM>
   </w.rf>
   <form>přijela</form>
   <lemma>přijet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t818-4">
   <w.rf>
    <LM>w#w-d1t818-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t818-5">
   <w.rf>
    <LM>w#w-d1t818-5</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m994-3140-3154">
   <w.rf>
    <LM>w#w-3140-3154</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t818-9">
   <w.rf>
    <LM>w#w-d1t818-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t818-6">
   <w.rf>
    <LM>w#w-d1t818-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t818-7">
   <w.rf>
    <LM>w#w-d1t818-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t818-8">
   <w.rf>
    <LM>w#w-d1t818-8</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m994-d1t818-10">
   <w.rf>
    <LM>w#w-d1t818-10</LM>
   </w.rf>
   <form>neviděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m994-d-id80463">
   <w.rf>
    <LM>w#w-d-id80463</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t820-1">
   <w.rf>
    <LM>w#w-d1t820-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t820-2">
   <w.rf>
    <LM>w#w-d1t820-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t820-3">
   <w.rf>
    <LM>w#w-d1t820-3</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t820-4">
   <w.rf>
    <LM>w#w-d1t820-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-d1t820-5">
   <w.rf>
    <LM>w#w-d1t820-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t820-6">
   <w.rf>
    <LM>w#w-d1t820-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-3140-3160">
   <w.rf>
    <LM>w#w-3140-3160</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-3161">
  <m id="m994-d1t823-3">
   <w.rf>
    <LM>w#w-d1t823-3</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t823-5">
   <w.rf>
    <LM>w#w-d1t823-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t823-4">
   <w.rf>
    <LM>w#w-d1t823-4</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t825-1">
   <w.rf>
    <LM>w#w-d1t825-1</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t825-2">
   <w.rf>
    <LM>w#w-d1t825-2</LM>
   </w.rf>
   <form>peněz</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m994-d-id80710">
   <w.rf>
    <LM>w#w-d-id80710</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x15">
  <m id="m994-d1t831-1">
   <w.rf>
    <LM>w#w-d1t831-1</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t831-2">
   <w.rf>
    <LM>w#w-d1t831-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t831-4">
   <w.rf>
    <LM>w#w-d1t831-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t831-5">
   <w.rf>
    <LM>w#w-d1t831-5</LM>
   </w.rf>
   <form>restituci</form>
   <lemma>restituce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m994-d1t831-3">
   <w.rf>
    <LM>w#w-d1t831-3</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t831-6">
   <w.rf>
    <LM>w#w-d1t831-6</LM>
   </w.rf>
   <form>nazpátek</form>
   <lemma>nazpátek</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t831-10">
   <w.rf>
    <LM>w#w-d1t831-10</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m994-d1t831-7">
   <w.rf>
    <LM>w#w-d1t831-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t831-8">
   <w.rf>
    <LM>w#w-d1t831-8</LM>
   </w.rf>
   <form>Lysé</form>
   <lemma>Lysá_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m994-d-id80893">
   <w.rf>
    <LM>w#w-d-id80893</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-272">
  <m id="m994-d1t836-2">
   <w.rf>
    <LM>w#w-d1t836-2</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t836-1">
   <w.rf>
    <LM>w#w-d1t836-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t836-3">
   <w.rf>
    <LM>w#w-d1t836-3</LM>
   </w.rf>
   <form>nastěhovaní</form>
   <lemma>nastěhovaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m994-d1t836-4">
   <w.rf>
    <LM>w#w-d1t836-4</LM>
   </w.rf>
   <form>nějací</form>
   <lemma>nějaký</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m994-d1t836-5">
   <w.rf>
    <LM>w#w-d1t836-5</LM>
   </w.rf>
   <form>vlajkaři</form>
   <lemma>vlajkař_,h</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m994-d-id80998">
   <w.rf>
    <LM>w#w-d-id80998</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t840-5">
   <w.rf>
    <LM>w#w-d1t840-5</LM>
   </w.rf>
   <form>hádali</form>
   <lemma>hádat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t840-2">
   <w.rf>
    <LM>w#w-d1t840-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t840-3">
   <w.rf>
    <LM>w#w-d1t840-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m994-d1t840-4">
   <w.rf>
    <LM>w#w-d1t840-4</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m994-d1t840-6">
   <w.rf>
    <LM>w#w-d1t840-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t840-7">
   <w.rf>
    <LM>w#w-d1t840-7</LM>
   </w.rf>
   <form>prali</form>
   <lemma>prát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1e653-x15-3268">
   <w.rf>
    <LM>w#w-d1e653-x15-3268</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t842-1">
   <w.rf>
    <LM>w#w-d1t842-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t842-3">
   <w.rf>
    <LM>w#w-d1t842-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t842-4">
   <w.rf>
    <LM>w#w-d1t842-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-d1t842-2">
   <w.rf>
    <LM>w#w-d1t842-2</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m994-d1t842-5">
   <w.rf>
    <LM>w#w-d1t842-5</LM>
   </w.rf>
   <form>právo</form>
   <lemma>právo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m994-272-1492">
   <w.rf>
    <LM>w#w-272-1492</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1493">
  <m id="m994-d1t842-7">
   <w.rf>
    <LM>w#w-d1t842-7</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t842-8">
   <w.rf>
    <LM>w#w-d1t842-8</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m994-d1t842-9">
   <w.rf>
    <LM>w#w-d1t842-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t842-10">
   <w.rf>
    <LM>w#w-d1t842-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m994-d1t842-11">
   <w.rf>
    <LM>w#w-d1t842-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-d1t842-12">
   <w.rf>
    <LM>w#w-d1t842-12</LM>
   </w.rf>
   <form>vymohla</form>
   <lemma>vymoci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t842-13">
   <w.rf>
    <LM>w#w-d1t842-13</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m994-d1t842-14">
   <w.rf>
    <LM>w#w-d1t842-14</LM>
   </w.rf>
   <form>bratrancem</form>
   <lemma>bratranec</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m994-d-id81351">
   <w.rf>
    <LM>w#w-d-id81351</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t842-16">
   <w.rf>
    <LM>w#w-d1t842-16</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m994-d1t842-17">
   <w.rf>
    <LM>w#w-d1t842-17</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t842-18">
   <w.rf>
    <LM>w#w-d1t842-18</LM>
   </w.rf>
   <form>advokát</form>
   <lemma>advokát</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d-id81430">
   <w.rf>
    <LM>w#w-d-id81430</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x16">
  <m id="m994-d1t849-1">
   <w.rf>
    <LM>w#w-d1t849-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t849-2">
   <w.rf>
    <LM>w#w-d1t849-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m994-d1t849-3">
   <w.rf>
    <LM>w#w-d1t849-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1e653-x16-3430">
   <w.rf>
    <LM>w#w-d1e653-x16-3430</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m994-d1e653-x16-3432">
   <w.rf>
    <LM>w#w-d1e653-x16-3432</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e653-x16-3433">
   <w.rf>
    <LM>w#w-d1e653-x16-3433</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e653-x16-3434">
   <w.rf>
    <LM>w#w-d1e653-x16-3434</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-3435">
  <m id="m994-d1t853-1">
   <w.rf>
    <LM>w#w-d1t853-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t853-2">
   <w.rf>
    <LM>w#w-d1t853-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m994-d1t853-3">
   <w.rf>
    <LM>w#w-d1t853-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m994-d1t853-4">
   <w.rf>
    <LM>w#w-d1t853-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-d1t853-5">
   <w.rf>
    <LM>w#w-d1t853-5</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-3435-1501">
   <w.rf>
    <LM>w#w-3435-1501</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x17">
  <m id="m994-d1t857-1">
   <w.rf>
    <LM>w#w-d1t857-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t857-2">
   <w.rf>
    <LM>w#w-d1t857-2</LM>
   </w.rf>
   <form>mým</form>
   <lemma>můj</lemma>
   <tag>PSZS7-S1-------</tag>
  </m>
  <m id="m994-d1t857-3">
   <w.rf>
    <LM>w#w-d1t857-3</LM>
   </w.rf>
   <form>mužem</form>
   <lemma>muž</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m994-d1t857-4">
   <w.rf>
    <LM>w#w-d1t857-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t857-5">
   <w.rf>
    <LM>w#w-d1t857-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t859-1">
   <w.rf>
    <LM>w#w-d1t859-1</LM>
   </w.rf>
   <form>rozvedla</form>
   <lemma>rozvést</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1e653-x17-3390">
   <w.rf>
    <LM>w#w-d1e653-x17-3390</LM>
   </w.rf>
   <form>in</form>
   <lemma>in-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m994-d1t859-2">
   <w.rf>
    <LM>w#w-d1t859-2</LM>
   </w.rf>
   <form>contumaciam</form>
   <lemma>contumaciam-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m994-d1e653-x17-3389">
   <w.rf>
    <LM>w#w-d1e653-x17-3389</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t859-3">
   <w.rf>
    <LM>w#w-d1t859-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t859-5">
   <w.rf>
    <LM>w#w-d1t859-5</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m994-d-id81834">
   <w.rf>
    <LM>w#w-d-id81834</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t859-7">
   <w.rf>
    <LM>w#w-d1t859-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t862-1">
   <w.rf>
    <LM>w#w-d1t862-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1e653-x17-3395">
   <w.rf>
    <LM>w#w-d1e653-x17-3395</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m994-d1t862-2">
   <w.rf>
    <LM>w#w-d1t862-2</LM>
   </w.rf>
   <form>nepřítomnosti</form>
   <lemma>přítomnost_^(*3ý)</lemma>
   <tag>NNFS2-----N----</tag>
  </m>
  <m id="m994-d1e653-x17-1507">
   <w.rf>
    <LM>w#w-d1e653-x17-1507</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1508">
  <m id="m994-d1t870-2">
   <w.rf>
    <LM>w#w-d1t870-2</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m994-d1t870-4">
   <w.rf>
    <LM>w#w-d1t870-4</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t870-3">
   <w.rf>
    <LM>w#w-d1t870-3</LM>
   </w.rf>
   <form>zmizel</form>
   <lemma>zmizet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d-id82051">
   <w.rf>
    <LM>w#w-d-id82051</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t870-6">
   <w.rf>
    <LM>w#w-d1t870-6</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m994-d1e653-x17-339">
   <w.rf>
    <LM>w#w-d1e653-x17-339</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t870-9">
   <w.rf>
    <LM>w#w-d1t870-9</LM>
   </w.rf>
   <form>blbec</form>
   <lemma>blbec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1e653-x17-340">
   <w.rf>
    <LM>w#w-d1e653-x17-340</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t870-7">
   <w.rf>
    <LM>w#w-d1t870-7</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m994-d1t870-8">
   <w.rf>
    <LM>w#w-d1t870-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t870-10">
   <w.rf>
    <LM>w#w-d1t870-10</LM>
   </w.rf>
   <form>nosila</form>
   <lemma>nosit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t870-11">
   <w.rf>
    <LM>w#w-d1t870-11</LM>
   </w.rf>
   <form>jídlo</form>
   <lemma>jídlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m994-d-id82147">
   <w.rf>
    <LM>w#w-d-id82147</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x18">
  <m id="m994-d1t875-7">
   <w.rf>
    <LM>w#w-d1t875-7</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t875-2">
   <w.rf>
    <LM>w#w-d1t875-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t875-3">
   <w.rf>
    <LM>w#w-d1t875-3</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m994-d1t875-4">
   <w.rf>
    <LM>w#w-d1t875-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t875-6">
   <w.rf>
    <LM>w#w-d1t875-6</LM>
   </w.rf>
   <form>špatně</form>
   <lemma>špatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1e653-x18-3559">
   <w.rf>
    <LM>w#w-d1e653-x18-3559</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t879-4">
   <w.rf>
    <LM>w#w-d1t879-4</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m994-d1t879-5">
   <w.rf>
    <LM>w#w-d1t879-5</LM>
   </w.rf>
   <form>ženu</form>
   <lemma>žena</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m994-d1t879-3">
   <w.rf>
    <LM>w#w-d1t879-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m994-d1t879-6">
   <w.rf>
    <LM>w#w-d1t879-6</LM>
   </w.rf>
   <form>vzal</form>
   <lemma>vzít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1e653-x18-3560">
   <w.rf>
    <LM>w#w-d1e653-x18-3560</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t879-7">
   <w.rf>
    <LM>w#w-d1t879-7</LM>
   </w.rf>
   <form>odstěhoval</form>
   <lemma>odstěhovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t879-8">
   <w.rf>
    <LM>w#w-d1t879-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t879-9">
   <w.rf>
    <LM>w#w-d1t879-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t879-10">
   <w.rf>
    <LM>w#w-d1t879-10</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m994-d1t879-11">
   <w.rf>
    <LM>w#w-d1t879-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t881-1">
   <w.rf>
    <LM>w#w-d1t881-1</LM>
   </w.rf>
   <form>Švýcarska</form>
   <lemma>Švýcarsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m994-d1e653-x18-3705">
   <w.rf>
    <LM>w#w-d1e653-x18-3705</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-3698">
  <m id="m994-d1t881-5">
   <w.rf>
    <LM>w#w-d1t881-5</LM>
   </w.rf>
   <form>Hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t881-6">
   <w.rf>
    <LM>w#w-d1t881-6</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t881-4">
   <w.rf>
    <LM>w#w-d1t881-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t881-7">
   <w.rf>
    <LM>w#w-d1t881-7</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-3698-3847">
   <w.rf>
    <LM>w#w-3698-3847</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t885-1">
   <w.rf>
    <LM>w#w-d1t885-1</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t885-2">
   <w.rf>
    <LM>w#w-d1t885-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t885-3">
   <w.rf>
    <LM>w#w-d1t885-3</LM>
   </w.rf>
   <form>konexe</form>
   <lemma>konexe</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m994-d-id82566">
   <w.rf>
    <LM>w#w-d-id82566</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-3832">
  <m id="m994-d1t890-4">
   <w.rf>
    <LM>w#w-d1t890-4</LM>
   </w.rf>
   <form>Jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t890-3">
   <w.rf>
    <LM>w#w-d1t890-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t890-2">
   <w.rf>
    <LM>w#w-d1t890-2</LM>
   </w.rf>
   <form>potkala</form>
   <lemma>potkat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t890-6">
   <w.rf>
    <LM>w#w-d1t890-6</LM>
   </w.rf>
   <form>Šibravu</form>
   <lemma>Šibrava_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m994-d-id82780">
   <w.rf>
    <LM>w#w-d-id82780</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t890-10">
   <w.rf>
    <LM>w#w-d1t890-10</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t890-9">
   <w.rf>
    <LM>w#w-d1t890-9</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d-id82835">
   <w.rf>
    <LM>w#w-d-id82835</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t890-15">
   <w.rf>
    <LM>w#w-d1t890-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t890-16">
   <w.rf>
    <LM>w#w-d1t890-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t890-17">
   <w.rf>
    <LM>w#w-d1t890-17</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t890-18">
   <w.rf>
    <LM>w#w-d1t890-18</LM>
   </w.rf>
   <form>hajzl</form>
   <lemma>hajzl-2_,v</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d-id82946">
   <w.rf>
    <LM>w#w-d-id82946</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t890-20">
   <w.rf>
    <LM>w#w-d1t890-20</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t890-21">
   <w.rf>
    <LM>w#w-d1t890-21</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m994-d1t890-22">
   <w.rf>
    <LM>w#w-d1t890-22</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t890-23">
   <w.rf>
    <LM>w#w-d1t890-23</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m994-d1t890-24">
   <w.rf>
    <LM>w#w-d1t890-24</LM>
   </w.rf>
   <form>připravil</form>
   <lemma>připravit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-3832-1521">
   <w.rf>
    <LM>w#w-3832-1521</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1522">
  <m id="m994-d1t892-1">
   <w.rf>
    <LM>w#w-d1t892-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t892-4">
   <w.rf>
    <LM>w#w-d1t892-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t892-5">
   <w.rf>
    <LM>w#w-d1t892-5</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m994-d1t892-3">
   <w.rf>
    <LM>w#w-d1t892-3</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m994-3832-4048">
   <w.rf>
    <LM>w#w-3832-4048</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t890-31">
   <w.rf>
    <LM>w#w-d1t890-31</LM>
   </w.rf>
   <form>umřel</form>
   <lemma>umřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t890-32">
   <w.rf>
    <LM>w#w-d1t890-32</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t892-6">
   <w.rf>
    <LM>w#w-d1t892-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t892-7">
   <w.rf>
    <LM>w#w-d1t892-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t892-8">
   <w.rf>
    <LM>w#w-d1t892-8</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d-id83278">
   <w.rf>
    <LM>w#w-d-id83278</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x20">
  <m id="m994-d1t896-5">
   <w.rf>
    <LM>w#w-d1t896-5</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t896-4">
   <w.rf>
    <LM>w#w-d1t896-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t898-3">
   <w.rf>
    <LM>w#w-d1t898-3</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t898-4">
   <w.rf>
    <LM>w#w-d1t898-4</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m994-d1t898-5">
   <w.rf>
    <LM>w#w-d1t898-5</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m994-d-id83469">
   <w.rf>
    <LM>w#w-d-id83469</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x21">
  <m id="m994-d1t901-1">
   <w.rf>
    <LM>w#w-d1t901-1</LM>
   </w.rf>
   <form>Neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m994-d1t901-2">
   <w.rf>
    <LM>w#w-d1t901-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t901-3">
   <w.rf>
    <LM>w#w-d1t901-3</LM>
   </w.rf>
   <form>nikoho</form>
   <lemma>nikdo</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m994-d1e653-x21-4125">
   <w.rf>
    <LM>w#w-d1e653-x21-4125</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t901-4">
   <w.rf>
    <LM>w#w-d1t901-4</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-d1e653-x21-4126">
   <w.rf>
    <LM>w#w-d1e653-x21-4126</LM>
   </w.rf>
   <form>nikoho</form>
   <lemma>nikdo</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m994-d1e653-x21-4127">
   <w.rf>
    <LM>w#w-d1e653-x21-4127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-4128">
  <m id="m994-d1t909-5">
   <w.rf>
    <LM>w#w-d1t909-5</LM>
   </w.rf>
   <form>Hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t909-4">
   <w.rf>
    <LM>w#w-d1t909-4</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-4128-4140">
   <w.rf>
    <LM>w#w-4128-4140</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t909-6">
   <w.rf>
    <LM>w#w-d1t909-6</LM>
   </w.rf>
   <form>vyváděl</form>
   <lemma>vyvádět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t909-9">
   <w.rf>
    <LM>w#w-d1t909-9</LM>
   </w.rf>
   <form>domovník</form>
   <lemma>domovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d-id83778">
   <w.rf>
    <LM>w#w-d-id83778</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x22">
  <m id="m994-d1t914-2">
   <w.rf>
    <LM>w#w-d1t914-2</LM>
   </w.rf>
   <form>Vrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t914-3">
   <w.rf>
    <LM>w#w-d1t914-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t914-1">
   <w.rf>
    <LM>w#w-d1t914-1</LM>
   </w.rf>
   <form>totiž</form>
   <lemma>totiž-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t914-4">
   <w.rf>
    <LM>w#w-d1t914-4</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m994-d1t914-5">
   <w.rf>
    <LM>w#w-d1t914-5</LM>
   </w.rf>
   <form>přítel</form>
   <lemma>přítel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1t916-5">
   <w.rf>
    <LM>w#w-d1t916-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m994-d1t916-7">
   <w.rf>
    <LM>w#w-d1t916-7</LM>
   </w.rf>
   <form>Svobodovou</form>
   <lemma>Svobodův_;Y_^(*2a)</lemma>
   <tag>AUFS7M---------</tag>
  </m>
  <m id="m994-d1t916-4">
   <w.rf>
    <LM>w#w-d1t916-4</LM>
   </w.rf>
   <form>armádou</form>
   <lemma>armáda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m994-d1t918-1">
   <w.rf>
    <LM>w#w-d1t918-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t918-2">
   <w.rf>
    <LM>w#w-d1t918-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t918-4">
   <w.rf>
    <LM>w#w-d1t918-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m994-d1e653-x22-1533">
   <w.rf>
    <LM>w#w-d1e653-x22-1533</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1534">
  <m id="m994-d1t918-6">
   <w.rf>
    <LM>w#w-d1t918-6</LM>
   </w.rf>
   <form>Vzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1t918-7">
   <w.rf>
    <LM>w#w-d1t918-7</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m994-d1t918-8">
   <w.rf>
    <LM>w#w-d1t918-8</LM>
   </w.rf>
   <form>nahoru</form>
   <lemma>nahoru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t918-9">
   <w.rf>
    <LM>w#w-d1t918-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t918-10">
   <w.rf>
    <LM>w#w-d1t918-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t918-11">
   <w.rf>
    <LM>w#w-d1t918-11</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m994-d1t918-12">
   <w.rf>
    <LM>w#w-d1t918-12</LM>
   </w.rf>
   <form>zmydlili</form>
   <lemma>zmydlit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1e653-x22-4458">
   <w.rf>
    <LM>w#w-d1e653-x22-4458</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t924-1">
   <w.rf>
    <LM>w#w-d1t924-1</LM>
   </w.rf>
   <form>poněvadž</form>
   <lemma>poněvadž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t924-3">
   <w.rf>
    <LM>w#w-d1t924-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m994-d1t924-4">
   <w.rf>
    <LM>w#w-d1t924-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t924-5">
   <w.rf>
    <LM>w#w-d1t924-5</LM>
   </w.rf>
   <form>posílal</form>
   <lemma>posílat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t927-1">
   <w.rf>
    <LM>w#w-d1t927-1</LM>
   </w.rf>
   <form>Rusáky</form>
   <lemma>Rusák_;E_,h</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m994-d1e653-x23-4319">
   <w.rf>
    <LM>w#w-d1e653-x23-4319</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-4320">
  <m id="m994-d1t927-2">
   <w.rf>
    <LM>w#w-d1t927-2</LM>
   </w.rf>
   <form>Dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m994-d1t927-3">
   <w.rf>
    <LM>w#w-d1t927-3</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d1t927-4">
   <w.rf>
    <LM>w#w-d1t927-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t927-5">
   <w.rf>
    <LM>w#w-d1t927-5</LM>
   </w.rf>
   <form>poslal</form>
   <lemma>poslat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1e653-x23-4317">
   <w.rf>
    <LM>w#w-d1e653-x23-4317</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t927-8">
   <w.rf>
    <LM>w#w-d1t927-8</LM>
   </w.rf>
   <form>znásilnili</form>
   <lemma>znásilnit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1t927-7">
   <w.rf>
    <LM>w#w-d1t927-7</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m994-d-id84454">
   <w.rf>
    <LM>w#w-d-id84454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x24">
  <m id="m994-d1t931-1">
   <w.rf>
    <LM>w#w-d1t931-1</LM>
   </w.rf>
   <form>Vzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1t931-2">
   <w.rf>
    <LM>w#w-d1t931-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m994-d1t931-3">
   <w.rf>
    <LM>w#w-d1t931-3</LM>
   </w.rf>
   <form>klíče</form>
   <lemma>klíč</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m994-d1e653-x24-223">
   <w.rf>
    <LM>w#w-d1e653-x24-223</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-239">
  <m id="m994-d1t931-8">
   <w.rf>
    <LM>w#w-d1t931-8</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t931-9">
   <w.rf>
    <LM>w#w-d1t931-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t931-10">
   <w.rf>
    <LM>w#w-d1t931-10</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m994-d1t931-11">
   <w.rf>
    <LM>w#w-d1t931-11</LM>
   </w.rf>
   <form>vysoký</form>
   <lemma>vysoký</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m994-d1t931-12">
   <w.rf>
    <LM>w#w-d1t931-12</LM>
   </w.rf>
   <form>důstojník</form>
   <lemma>důstojník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-239-1539">
   <w.rf>
    <LM>w#w-239-1539</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1540">
  <m id="m994-d1t935-1">
   <w.rf>
    <LM>w#w-d1t935-1</LM>
   </w.rf>
   <form>Volala</form>
   <lemma>volat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t933-2">
   <w.rf>
    <LM>w#w-d1t933-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t933-3">
   <w.rf>
    <LM>w#w-d1t933-3</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t942-2">
   <w.rf>
    <LM>w#w-d1t942-2</LM>
   </w.rf>
   <form>ruského</form>
   <lemma>ruský</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m994-d1t942-3">
   <w.rf>
    <LM>w#w-d1t942-3</LM>
   </w.rf>
   <form>komandanta</form>
   <lemma>komandant</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m994-1540-1541">
   <w.rf>
    <LM>w#w-1540-1541</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1542">
  <m id="m994-d1e653-x24-237">
   <w.rf>
    <LM>w#w-d1e653-x24-237</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1e653-x24-238">
   <w.rf>
    <LM>w#w-d1e653-x24-238</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t944-1">
   <w.rf>
    <LM>w#w-d1t944-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t944-2">
   <w.rf>
    <LM>w#w-d1t944-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m994-d1t944-4">
   <w.rf>
    <LM>w#w-d1t944-4</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t944-7">
   <w.rf>
    <LM>w#w-d1t944-7</LM>
   </w.rf>
   <form>kavárna</form>
   <lemma>kavárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d1t944-3">
   <w.rf>
    <LM>w#w-d1t944-3</LM>
   </w.rf>
   <form>Bellevue</form>
   <lemma>Bellevue_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m994-d1t944-12">
   <w.rf>
    <LM>w#w-d1t944-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t944-13">
   <w.rf>
    <LM>w#w-d1t944-13</LM>
   </w.rf>
   <form>nábřeží</form>
   <lemma>nábřeží</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m994-d-id85061">
   <w.rf>
    <LM>w#w-d-id85061</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t944-9">
   <w.rf>
    <LM>w#w-d1t944-9</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t944-10">
   <w.rf>
    <LM>w#w-d1t944-10</LM>
   </w.rf>
   <form>víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m994-d-id85147">
   <w.rf>
    <LM>w#w-d-id85147</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t944-16">
   <w.rf>
    <LM>w#w-d1t944-16</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t946-1">
   <w.rf>
    <LM>w#w-d1t946-1</LM>
   </w.rf>
   <form>svoji</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4----------</tag>
  </m>
  <m id="m994-d1t946-2">
   <w.rf>
    <LM>w#w-d1t946-2</LM>
   </w.rf>
   <form>rezidenci</form>
   <lemma>rezidence</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m994-d-id85273">
   <w.rf>
    <LM>w#w-d-id85273</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e653-x25">
  <m id="m994-d1t950-6">
   <w.rf>
    <LM>w#w-d1t950-6</LM>
   </w.rf>
   <form>Všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m994-d1t950-3">
   <w.rf>
    <LM>w#w-d1t950-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t950-4">
   <w.rf>
    <LM>w#w-d1t950-4</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m994-d1t950-9">
   <w.rf>
    <LM>w#w-d1t950-9</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d-id85438">
   <w.rf>
    <LM>w#w-d-id85438</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t955-1">
   <w.rf>
    <LM>w#w-d1t955-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t955-6">
   <w.rf>
    <LM>w#w-d1t955-6</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m994-d1t955-7">
   <w.rf>
    <LM>w#w-d1t955-7</LM>
   </w.rf>
   <form>klíče</form>
   <lemma>klíč</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m994-d-id85560">
   <w.rf>
    <LM>w#w-d-id85560</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t955-9">
   <w.rf>
    <LM>w#w-d1t955-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t955-10">
   <w.rf>
    <LM>w#w-d1t955-10</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m994-d1t955-11">
   <w.rf>
    <LM>w#w-d1t955-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t955-12">
   <w.rf>
    <LM>w#w-d1t955-12</LM>
   </w.rf>
   <form>chodí</form>
   <lemma>chodit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m994-d1t955-13">
   <w.rf>
    <LM>w#w-d1t955-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t955-14">
   <w.rf>
    <LM>w#w-d1t955-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t955-15">
   <w.rf>
    <LM>w#w-d1t955-15</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d-id85677">
   <w.rf>
    <LM>w#w-d-id85677</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
