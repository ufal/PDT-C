<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ez_061.11.w.gz" />
  </references>
 </head>
 <s id="m061-d1e3813-x3">
  <m id="m061-d1t3820-1">
   <w.rf>
    <LM>w#w-d1t3820-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m061-d1t3820-2">
   <w.rf>
    <LM>w#w-d1t3820-2</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m061-d-m-d1e3813-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3813-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
