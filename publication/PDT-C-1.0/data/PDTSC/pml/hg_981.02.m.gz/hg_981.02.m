<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_981.02.w.gz" />
  </references>
 </head>
 <s id="m981-13808_01-10345">
  <m id="m981-d1t934-12">
   <w.rf>
    <LM>w#w-d1t934-12</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t934-13">
   <w.rf>
    <LM>w#w-d1t934-13</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d1t941-3">
   <w.rf>
    <LM>w#w-d1t941-3</LM>
   </w.rf>
   <form>sirotci</form>
   <lemma>sirotek</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m981-d-id79643">
   <w.rf>
    <LM>w#w-d-id79643</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t941-5">
   <w.rf>
    <LM>w#w-d1t941-5</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m981-d1t941-6">
   <w.rf>
    <LM>w#w-d1t941-6</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m981-d1t941-7">
   <w.rf>
    <LM>w#w-d1t941-7</LM>
   </w.rf>
   <form>tragicky</form>
   <lemma>tragicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-d1t941-8">
   <w.rf>
    <LM>w#w-d1t941-8</LM>
   </w.rf>
   <form>zahynuli</form>
   <lemma>zahynout</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m981-10345-123">
   <w.rf>
    <LM>w#w-10345-123</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-124">
  <m id="m981-d1t943-3">
   <w.rf>
    <LM>w#w-d1t943-3</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t943-4">
   <w.rf>
    <LM>w#w-d1t943-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d1t943-5">
   <w.rf>
    <LM>w#w-d1t943-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t943-6">
   <w.rf>
    <LM>w#w-d1t943-6</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m981-d1t943-7">
   <w.rf>
    <LM>w#w-d1t943-7</LM>
   </w.rf>
   <form>skupině</form>
   <lemma>skupina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m981-10345-10354">
   <w.rf>
    <LM>w#w-10345-10354</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t945-1">
   <w.rf>
    <LM>w#w-d1t945-1</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-d1t945-2">
   <w.rf>
    <LM>w#w-d1t945-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m981-d1t945-3">
   <w.rf>
    <LM>w#w-d1t945-3</LM>
   </w.rf>
   <form>přemlouvali</form>
   <lemma>přemlouvat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d-id79911">
   <w.rf>
    <LM>w#w-d-id79911</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t945-5">
   <w.rf>
    <LM>w#w-d1t945-5</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m981-d1t945-6">
   <w.rf>
    <LM>w#w-d1t945-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t945-8">
   <w.rf>
    <LM>w#w-d1t945-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m981-d1t945-9">
   <w.rf>
    <LM>w#w-d1t945-9</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m981-d1t945-7">
   <w.rf>
    <LM>w#w-d1t945-7</LM>
   </w.rf>
   <form>přidala</form>
   <lemma>přidat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m981-d-id79997">
   <w.rf>
    <LM>w#w-d-id79997</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e888-x5">
  <m id="m981-d1t949-1">
   <w.rf>
    <LM>w#w-d1t949-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t949-2">
   <w.rf>
    <LM>w#w-d1t949-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m981-d1t949-3">
   <w.rf>
    <LM>w#w-d1t949-3</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t949-4">
   <w.rf>
    <LM>w#w-d1t949-4</LM>
   </w.rf>
   <form>nevyhovovalo</form>
   <lemma>vyhovovat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m981-d-id80092">
   <w.rf>
    <LM>w#w-d-id80092</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t949-6">
   <w.rf>
    <LM>w#w-d1t949-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t951-1">
   <w.rf>
    <LM>w#w-d1t951-1</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t951-2">
   <w.rf>
    <LM>w#w-d1t951-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m981-d1t951-3">
   <w.rf>
    <LM>w#w-d1t951-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t951-4">
   <w.rf>
    <LM>w#w-d1t951-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t951-5">
   <w.rf>
    <LM>w#w-d1t951-5</LM>
   </w.rf>
   <form>úmyslu</form>
   <lemma>úmysl</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m981-d-id80203">
   <w.rf>
    <LM>w#w-d-id80203</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t951-7">
   <w.rf>
    <LM>w#w-d1t951-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t951-8">
   <w.rf>
    <LM>w#w-d1t951-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t951-10">
   <w.rf>
    <LM>w#w-d1t951-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t951-12">
   <w.rf>
    <LM>w#w-d1t951-12</LM>
   </w.rf>
   <form>Palestiny</form>
   <lemma>Palestina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d1t954-1">
   <w.rf>
    <LM>w#w-d1t954-1</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t954-2">
   <w.rf>
    <LM>w#w-d1t954-2</LM>
   </w.rf>
   <form>dostanu</form>
   <lemma>dostat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m981-d1e888-x5-10717">
   <w.rf>
    <LM>w#w-d1e888-x5-10717</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-10718">
  <m id="m981-d1t958-4">
   <w.rf>
    <LM>w#w-d1t958-4</LM>
   </w.rf>
   <form>Dostávali</form>
   <lemma>dostávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d1t958-5">
   <w.rf>
    <LM>w#w-d1t958-5</LM>
   </w.rf>
   <form>certifikáty</form>
   <lemma>certifikát</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m981-d1t958-6">
   <w.rf>
    <LM>w#w-d1t958-6</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t958-7">
   <w.rf>
    <LM>w#w-d1t958-7</LM>
   </w.rf>
   <form>Angličanů</form>
   <lemma>Angličan_;E</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m981-d-id80472">
   <w.rf>
    <LM>w#w-d-id80472</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t960-2">
   <w.rf>
    <LM>w#w-d1t960-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t960-3">
   <w.rf>
    <LM>w#w-d1t960-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t967-2">
   <w.rf>
    <LM>w#w-d1t967-2</LM>
   </w.rf>
   <form>Britský</form>
   <lemma>britský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m981-d1t960-4">
   <w.rf>
    <LM>w#w-d1t960-4</LM>
   </w.rf>
   <form>mandát</form>
   <lemma>mandát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m981-d1t960-5">
   <w.rf>
    <LM>w#w-d1t960-5</LM>
   </w.rf>
   <form>Palestina</form>
   <lemma>Palestina_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m981-10718-134">
   <w.rf>
    <LM>w#w-10718-134</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-135">
  <m id="m981-d1t967-6">
   <w.rf>
    <LM>w#w-d1t967-6</LM>
   </w.rf>
   <form>Pouštěli</form>
   <lemma>pouštět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d1t967-7">
   <w.rf>
    <LM>w#w-d1t967-7</LM>
   </w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t967-9">
   <w.rf>
    <LM>w#w-d1t967-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m981-d1t967-10">
   <w.rf>
    <LM>w#w-d1t967-10</LM>
   </w.rf>
   <form>kapitalistický</form>
   <lemma>kapitalistický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m981-d1t967-11">
   <w.rf>
    <LM>w#w-d1t967-11</LM>
   </w.rf>
   <form>certifikát</form>
   <lemma>certifikát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m981-d-id80784">
   <w.rf>
    <LM>w#w-d-id80784</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t967-13">
   <w.rf>
    <LM>w#w-d1t967-13</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m981-d1t967-14">
   <w.rf>
    <LM>w#w-d1t967-14</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t967-15">
   <w.rf>
    <LM>w#w-d1t967-15</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-d1t967-16">
   <w.rf>
    <LM>w#w-d1t967-16</LM>
   </w.rf>
   <form>drahý</form>
   <lemma>drahý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m981-d-id80848">
   <w.rf>
    <LM>w#w-d-id80848</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t969-1">
   <w.rf>
    <LM>w#w-d1t969-1</LM>
   </w.rf>
   <form>dostával</form>
   <lemma>dostávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t969-2">
   <w.rf>
    <LM>w#w-d1t969-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-10718-10728">
   <w.rf>
    <LM>w#w-10718-10728</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m981-d1t969-3">
   <w.rf>
    <LM>w#w-d1t969-3</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>1000</form>
   <lemma>1000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m981-d1t969-4">
   <w.rf>
    <LM>w#w-d1t969-4</LM>
   </w.rf>
   <form>liber</form>
   <lemma>libra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m981-10718-10732">
   <w.rf>
    <LM>w#w-10718-10732</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t973-2">
   <w.rf>
    <LM>w#w-d1t973-2</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t973-3">
   <w.rf>
    <LM>w#w-d1t973-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m981-d1t973-5">
   <w.rf>
    <LM>w#w-d1t973-5</LM>
   </w.rf>
   <form>dělnický</form>
   <lemma>dělnický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m981-d1t973-6">
   <w.rf>
    <LM>w#w-d1t973-6</LM>
   </w.rf>
   <form>certifikát</form>
   <lemma>certifikát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m981-135-136">
   <w.rf>
    <LM>w#w-135-136</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-137">
  <m id="m981-d1t973-10">
   <w.rf>
    <LM>w#w-d1t973-10</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t973-11">
   <w.rf>
    <LM>w#w-d1t973-11</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m981-d1t975-1">
   <w.rf>
    <LM>w#w-d1t975-1</LM>
   </w.rf>
   <form>limitováno</form>
   <lemma>limitovat</lemma>
   <tag>VsNS----X-API--</tag>
  </m>
  <m id="m981-d1t977-1">
   <w.rf>
    <LM>w#w-d1t977-1</LM>
   </w.rf>
   <form>ročně</form>
   <lemma>ročně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-10718-10733">
   <w.rf>
    <LM>w#w-10718-10733</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t977-2">
   <w.rf>
    <LM>w#w-d1t977-2</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m981-10718-10735">
   <w.rf>
    <LM>w#w-10718-10735</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t980-5">
   <w.rf>
    <LM>w#w-d1t980-5</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t980-1">
   <w.rf>
    <LM>w#w-d1t980-1</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t977-3">
   <w.rf>
    <LM>w#w-d1t977-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m981-d1t980-2">
   <w.rf>
    <LM>w#w-d1t980-2</LM>
   </w.rf>
   <form>200</form>
   <lemma>200</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m981-d1t980-4">
   <w.rf>
    <LM>w#w-d1t980-4</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m981-10718-10738">
   <w.rf>
    <LM>w#w-10718-10738</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-10718-10739">
   <w.rf>
    <LM>w#w-10718-10739</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m981-d1t980-6">
   <w.rf>
    <LM>w#w-d1t980-6</LM>
   </w.rf>
   <form>pouštěli</form>
   <lemma>pouštět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d1t980-7">
   <w.rf>
    <LM>w#w-d1t980-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t980-8">
   <w.rf>
    <LM>w#w-d1t980-8</LM>
   </w.rf>
   <form>Palestiny</form>
   <lemma>Palestina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d-id81326">
   <w.rf>
    <LM>w#w-d-id81326</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e981-x2">
  <m id="m981-d1t986-1">
   <w.rf>
    <LM>w#w-d1t986-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t986-2">
   <w.rf>
    <LM>w#w-d1t986-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m981-d1t986-3">
   <w.rf>
    <LM>w#w-d1t986-3</LM>
   </w.rf>
   <form>vychována</form>
   <lemma>vychovat</lemma>
   <tag>VsQW----X-APP--</tag>
  </m>
  <m id="m981-d1t986-4">
   <w.rf>
    <LM>w#w-d1t986-4</LM>
   </w.rf>
   <form>natolik</form>
   <lemma>natolik</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t986-6">
   <w.rf>
    <LM>w#w-d1t986-6</LM>
   </w.rf>
   <form>židovsky</form>
   <lemma>židovsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-d1e981-x2-11388">
   <w.rf>
    <LM>w#w-d1e981-x2-11388</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t992-3">
   <w.rf>
    <LM>w#w-d1t992-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t992-4">
   <w.rf>
    <LM>w#w-d1t992-4</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m981-d1t992-5">
   <w.rf>
    <LM>w#w-d1t992-5</LM>
   </w.rf>
   <form>toužila</form>
   <lemma>toužit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t992-6">
   <w.rf>
    <LM>w#w-d1t992-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1e981-x2-11390">
   <w.rf>
    <LM>w#w-d1e981-x2-11390</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m981-d1t992-7">
   <w.rf>
    <LM>w#w-d1t992-7</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m981-d1t992-8">
   <w.rf>
    <LM>w#w-d1t992-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t992-9">
   <w.rf>
    <LM>w#w-d1t992-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t992-10">
   <w.rf>
    <LM>w#w-d1t992-10</LM>
   </w.rf>
   <form>židovské</form>
   <lemma>židovský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m981-d1t992-11">
   <w.rf>
    <LM>w#w-d1t992-11</LM>
   </w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d1e981-x2-11391">
   <w.rf>
    <LM>w#w-d1e981-x2-11391</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e987-x3">
  <m id="m981-d1t994-1">
   <w.rf>
    <LM>w#w-d1t994-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d-id81716">
   <w.rf>
    <LM>w#w-d-id81716</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e999-x2">
  <m id="m981-d1t1002-1">
   <w.rf>
    <LM>w#w-d1t1002-1</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1002-2">
   <w.rf>
    <LM>w#w-d1t1002-2</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1002-3">
   <w.rf>
    <LM>w#w-d1t1002-3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1e999-x2-154">
   <w.rf>
    <LM>w#w-d1e999-x2-154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-155">
  <m id="m981-d1t1004-1">
   <w.rf>
    <LM>w#w-d1t1004-1</LM>
   </w.rf>
   <form>Otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-d1t1004-2">
   <w.rf>
    <LM>w#w-d1t1004-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1004-3">
   <w.rf>
    <LM>w#w-d1t1004-3</LM>
   </w.rf>
   <form>sociální</form>
   <lemma>sociální</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m981-d1t1004-4">
   <w.rf>
    <LM>w#w-d1t1004-4</LM>
   </w.rf>
   <form>demokrat</form>
   <lemma>demokrat</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-d-id81936">
   <w.rf>
    <LM>w#w-d-id81936</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1004-7">
   <w.rf>
    <LM>w#w-d1t1004-7</LM>
   </w.rf>
   <form>náboženství</form>
   <lemma>náboženství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m981-d1t1004-10">
   <w.rf>
    <LM>w#w-d1t1004-10</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m981-d1t1004-11">
   <w.rf>
    <LM>w#w-d1t1004-11</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1e999-x2-11665">
   <w.rf>
    <LM>w#w-d1e999-x2-11665</LM>
   </w.rf>
   <form>důležité</form>
   <lemma>důležitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m981-155-156">
   <w.rf>
    <LM>w#w-155-156</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-157">
  <m id="m981-d1t1006-2">
   <w.rf>
    <LM>w#w-d1t1006-2</LM>
   </w.rf>
   <form>Chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1006-3">
   <w.rf>
    <LM>w#w-d1t1006-3</LM>
   </w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m981-d1t1006-4">
   <w.rf>
    <LM>w#w-d1t1006-4</LM>
   </w.rf>
   <form>mamince</form>
   <lemma>maminka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m981-d-id82104">
   <w.rf>
    <LM>w#w-d-id82104</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1006-6">
   <w.rf>
    <LM>w#w-d1t1006-6</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m981-d1t1006-7">
   <w.rf>
    <LM>w#w-d1t1006-7</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1006-8">
   <w.rf>
    <LM>w#w-d1t1006-8</LM>
   </w.rf>
   <form>udržovala</form>
   <lemma>udržovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t1006-9">
   <w.rf>
    <LM>w#w-d1t1006-9</LM>
   </w.rf>
   <form>tradici</form>
   <lemma>tradice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m981-d-id82175">
   <w.rf>
    <LM>w#w-d-id82175</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1008-1">
   <w.rf>
    <LM>w#w-d1t1008-1</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1008-2">
   <w.rf>
    <LM>w#w-d1t1008-2</LM>
   </w.rf>
   <form>vařila</form>
   <lemma>vařit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t1008-3">
   <w.rf>
    <LM>w#w-d1t1008-3</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>košer</form>
   <lemma>košer-2_^(připravený_k_požívání_dle_předpisů_judaizmu)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1e999-x2-11669">
   <w.rf>
    <LM>w#w-d1e999-x2-11669</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-11672">
  <m id="m981-d1t1008-4">
   <w.rf>
    <LM>w#w-d1t1008-4</LM>
   </w.rf>
   <form>Tatínkovi</form>
   <lemma>tatínek</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m981-d1t1008-6">
   <w.rf>
    <LM>w#w-d1t1008-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t1008-7">
   <w.rf>
    <LM>w#w-d1t1008-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1008-8">
   <w.rf>
    <LM>w#w-d1t1008-8</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jedno</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-11672-165">
   <w.rf>
    <LM>w#w-11672-165</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-166">
  <m id="m981-d1t1013-1">
   <w.rf>
    <LM>w#w-d1t1013-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1013-2">
   <w.rf>
    <LM>w#w-d1t1013-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1013-3">
   <w.rf>
    <LM>w#w-d1t1013-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1013-6">
   <w.rf>
    <LM>w#w-d1t1013-6</LM>
   </w.rf>
   <form>zasvěcoval</form>
   <lemma>zasvěcovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1017-1">
   <w.rf>
    <LM>w#w-d1t1017-1</LM>
   </w.rf>
   <form>sabat</form>
   <lemma>sabat</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m981-d-id82449">
   <w.rf>
    <LM>w#w-d-id82449</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1017-4">
   <w.rf>
    <LM>w#w-d1t1017-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m981-d1t1017-5">
   <w.rf>
    <LM>w#w-d1t1017-5</LM>
   </w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m981-d1t1017-6">
   <w.rf>
    <LM>w#w-d1t1017-6</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1017-7">
   <w.rf>
    <LM>w#w-d1t1017-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1017-8">
   <w.rf>
    <LM>w#w-d1t1017-8</LM>
   </w.rf>
   <form>rozsvěcely</form>
   <lemma>rozsvěcet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m981-d1t1017-9">
   <w.rf>
    <LM>w#w-d1t1017-9</LM>
   </w.rf>
   <form>svíce</form>
   <lemma>svíce</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m981-d-id82567">
   <w.rf>
    <LM>w#w-d-id82567</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1017-11">
   <w.rf>
    <LM>w#w-d1t1017-11</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m981-d1t1019-1">
   <w.rf>
    <LM>w#w-d1t1019-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1019-2">
   <w.rf>
    <LM>w#w-d1t1019-2</LM>
   </w.rf>
   <form>pomodlila</form>
   <lemma>pomodlit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m981-d1t1021-1">
   <w.rf>
    <LM>w#w-d1t1021-1</LM>
   </w.rf>
   <form>kratičkou</form>
   <lemma>kratičký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m981-d1t1023-1">
   <w.rf>
    <LM>w#w-d1t1023-1</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>modlitbu</form>
   <lemma>modlitba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m981-11672-11680">
   <w.rf>
    <LM>w#w-11672-11680</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-11681">
  <m id="m981-d1t1023-3">
   <w.rf>
    <LM>w#w-d1t1023-3</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1023-4">
   <w.rf>
    <LM>w#w-d1t1023-4</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-d1t1026-3">
   <w.rf>
    <LM>w#w-d1t1026-3</LM>
   </w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m981-d1t1026-4">
   <w.rf>
    <LM>w#w-d1t1026-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3-------</tag>
  </m>
  <m id="m981-d1t1026-5">
   <w.rf>
    <LM>w#w-d1t1026-5</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1026-6">
   <w.rf>
    <LM>w#w-d1t1026-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1026-7">
   <w.rf>
    <LM>w#w-d1t1026-7</LM>
   </w.rf>
   <form>synagogy</form>
   <lemma>synagoga</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d1t1030-1">
   <w.rf>
    <LM>w#w-d1t1030-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m981-d1t1030-3">
   <w.rf>
    <LM>w#w-d1t1030-3</LM>
   </w.rf>
   <form>výroční</form>
   <lemma>výroční</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m981-d1t1030-4">
   <w.rf>
    <LM>w#w-d1t1030-4</LM>
   </w.rf>
   <form>svátky</form>
   <lemma>svátek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m981-11681-169">
   <w.rf>
    <LM>w#w-11681-169</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1030-7">
   <w.rf>
    <LM>w#w-d1t1030-7</LM>
   </w.rf>
   <form>Nový</form>
   <lemma>nový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m981-11681-11692">
   <w.rf>
    <LM>w#w-11681-11692</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m981-d1t1030-8">
   <w.rf>
    <LM>w#w-d1t1030-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-11681-11698">
   <w.rf>
    <LM>w#w-11681-11698</LM>
   </w.rf>
   <form>Jom</form>
   <lemma>Jom-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m981-11681-11698-sw1">
   <w.rf>
    <LM>w#w-11681-11698</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>kipur</form>
   <lemma>kipur-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m981-11681-11696">
   <w.rf>
    <LM>w#w-11681-11696</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1034-1">
   <w.rf>
    <LM>w#w-d1t1034-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t1034-2">
   <w.rf>
    <LM>w#w-d1t1034-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1034-3">
   <w.rf>
    <LM>w#w-d1t1034-3</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1034-4">
   <w.rf>
    <LM>w#w-d1t1034-4</LM>
   </w.rf>
   <form>vše</form>
   <lemma>všechen</lemma>
   <tag>PLNS1---------1</tag>
  </m>
  <m id="m981-11681-11701">
   <w.rf>
    <LM>w#w-11681-11701</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-11702">
  <m id="m981-d1t1036-1">
   <w.rf>
    <LM>w#w-d1t1036-1</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1036-2">
   <w.rf>
    <LM>w#w-d1t1036-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1039-1">
   <w.rf>
    <LM>w#w-d1t1039-1</LM>
   </w.rf>
   <form>dodržoval</form>
   <lemma>dodržovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1041-1">
   <w.rf>
    <LM>w#w-d1t1041-1</LM>
   </w.rf>
   <form>Pesach</form>
   <lemma>pesach</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m981-d-id83186">
   <w.rf>
    <LM>w#w-d-id83186</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1041-3">
   <w.rf>
    <LM>w#w-d1t1041-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t1041-4">
   <w.rf>
    <LM>w#w-d1t1041-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m981-d1t1041-5">
   <w.rf>
    <LM>w#w-d1t1041-5</LM>
   </w.rf>
   <form>velikonoce</form>
   <lemma>velikonoce_,i_^(^DS**Velikonoce)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m981-11702-184">
   <w.rf>
    <LM>w#w-11702-184</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-185">
  <m id="m981-d1t1043-1">
   <w.rf>
    <LM>w#w-d1t1043-1</LM>
   </w.rf>
   <form>Jedly</form>
   <lemma>jíst</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m981-d1t1043-2">
   <w.rf>
    <LM>w#w-d1t1043-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1043-3">
   <w.rf>
    <LM>w#w-d1t1043-3</LM>
   </w.rf>
   <form>macesy</form>
   <lemma>maces</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m981-d-id83299">
   <w.rf>
    <LM>w#w-d-id83299</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1043-5">
   <w.rf>
    <LM>w#w-d1t1043-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1043-6">
   <w.rf>
    <LM>w#w-d1t1043-6</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1043-7">
   <w.rf>
    <LM>w#w-d1t1043-7</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1043-8">
   <w.rf>
    <LM>w#w-d1t1043-8</LM>
   </w.rf>
   <form>chleba</form>
   <lemma>chléb</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m981-d-id83363">
   <w.rf>
    <LM>w#w-d-id83363</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1045-1">
   <w.rf>
    <LM>w#w-d1t1045-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t1045-2">
   <w.rf>
    <LM>w#w-d1t1045-2</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m981-d1t1045-3">
   <w.rf>
    <LM>w#w-d1t1045-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1047-2">
   <w.rf>
    <LM>w#w-d1t1047-2</LM>
   </w.rf>
   <form>přísné</form>
   <lemma>přísný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m981-d-id83453">
   <w.rf>
    <LM>w#w-d-id83453</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1063-x2">
  <m id="m981-d1t1060-1">
   <w.rf>
    <LM>w#w-d1t1060-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t1066-1">
   <w.rf>
    <LM>w#w-d1t1066-1</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m981-d1t1066-2">
   <w.rf>
    <LM>w#w-d1t1066-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1066-3">
   <w.rf>
    <LM>w#w-d1t1066-3</LM>
   </w.rf>
   <form>vypravila</form>
   <lemma>vypravit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m981-d1t1066-4">
   <w.rf>
    <LM>w#w-d1t1066-4</LM>
   </w.rf>
   <form>posléze</form>
   <lemma>posléze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1066-5">
   <w.rf>
    <LM>w#w-d1t1066-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m981-d1e1063-x2-290">
   <w.rf>
    <LM>w#w-d1e1063-x2-290</LM>
   </w.rf>
   <form>přáteli</form>
   <lemma>přítel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m981-d1t1076-1">
   <w.rf>
    <LM>w#w-d1t1076-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1076-2">
   <w.rf>
    <LM>w#w-d1t1076-2</LM>
   </w.rf>
   <form>Palestiny</form>
   <lemma>Palestina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d1e1063-x2-300">
   <w.rf>
    <LM>w#w-d1e1063-x2-300</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1079-x2">
  <m id="m981-d1t1082-3">
   <w.rf>
    <LM>w#w-d1t1082-3</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1e1079-x2-560">
   <w.rf>
    <LM>w#w-d1e1079-x2-560</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1082-4">
   <w.rf>
    <LM>w#w-d1t1082-4</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m981-d1t1082-5">
   <w.rf>
    <LM>w#w-d1t1082-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1082-6">
   <w.rf>
    <LM>w#w-d1t1082-6</LM>
   </w.rf>
   <form>jela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t1084-1">
   <w.rf>
    <LM>w#w-d1t1084-1</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m981-d1t1084-2">
   <w.rf>
    <LM>w#w-d1t1084-2</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m981-d1t1084-3">
   <w.rf>
    <LM>w#w-d1t1084-3</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m981-d-id84121">
   <w.rf>
    <LM>w#w-d-id84121</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1084-6">
   <w.rf>
    <LM>w#w-d1t1084-6</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1084-7">
   <w.rf>
    <LM>w#w-d1t1084-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1084-8">
   <w.rf>
    <LM>w#w-d1t1084-8</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m981-d1t1084-9">
   <w.rf>
    <LM>w#w-d1t1084-9</LM>
   </w.rf>
   <form>1935</form>
   <lemma>1935</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m981-d1e1079-x2-564">
   <w.rf>
    <LM>w#w-d1e1079-x2-564</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-567">
  <m id="m981-d1t1086-2">
   <w.rf>
    <LM>w#w-d1t1086-2</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-567-201">
   <w.rf>
    <LM>w#w-567-201</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1086-3">
   <w.rf>
    <LM>w#w-d1t1086-3</LM>
   </w.rf>
   <form>bratrance</form>
   <lemma>bratranec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m981-d-id84287">
   <w.rf>
    <LM>w#w-d-id84287</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1088-1">
   <w.rf>
    <LM>w#w-d1t1088-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1088-2">
   <w.rf>
    <LM>w#w-d1t1088-2</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m981-d-id84336">
   <w.rf>
    <LM>w#w-d-id84336</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1088-4">
   <w.rf>
    <LM>w#w-d1t1088-4</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m981-d1t1093-1">
   <w.rf>
    <LM>w#w-d1t1093-1</LM>
   </w.rf>
   <form>pocházel</form>
   <lemma>pocházet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1093-2">
   <w.rf>
    <LM>w#w-d1t1093-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1093-3">
   <w.rf>
    <LM>w#w-d1t1093-3</LM>
   </w.rf>
   <form>Vídně</form>
   <lemma>Vídeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-567-202">
   <w.rf>
    <LM>w#w-567-202</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-203">
  <m id="m981-d1t1093-7">
   <w.rf>
    <LM>w#w-d1t1093-7</LM>
   </w.rf>
   <form>Celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m981-d1t1093-8">
   <w.rf>
    <LM>w#w-d1t1093-8</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m981-d1t1095-1">
   <w.rf>
    <LM>w#w-d1t1095-1</LM>
   </w.rf>
   <form>žila</form>
   <lemma>žít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t1095-2">
   <w.rf>
    <LM>w#w-d1t1095-2</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m981-d1t1095-3">
   <w.rf>
    <LM>w#w-d1t1095-3</LM>
   </w.rf>
   <form>Vídni</form>
   <lemma>Vídeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m981-d-id84597">
   <w.rf>
    <LM>w#w-d-id84597</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1095-6">
   <w.rf>
    <LM>w#w-d1t1095-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d1t1095-5">
   <w.rf>
    <LM>w#w-d1t1095-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t1095-7">
   <w.rf>
    <LM>w#w-d1t1095-7</LM>
   </w.rf>
   <form>Kolekovi</form>
   <lemma>Kolekův_;Y_^(*2)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m981-567-576">
   <w.rf>
    <LM>w#w-567-576</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-577">
  <m id="m981-d1t1097-3">
   <w.rf>
    <LM>w#w-d1t1097-3</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m981-d1t1097-5">
   <w.rf>
    <LM>w#w-d1t1097-5</LM>
   </w.rf>
   <form>Kolek</form>
   <lemma>Kolek-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-577-585">
   <w.rf>
    <LM>w#w-577-585</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1097-8">
   <w.rf>
    <LM>w#w-d1t1097-8</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m981-d1t1097-9">
   <w.rf>
    <LM>w#w-d1t1097-9</LM>
   </w.rf>
   <form>proslulý</form>
   <lemma>proslulý_^(*3out)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m981-d1t1097-10">
   <w.rf>
    <LM>w#w-d1t1097-10</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t1097-11">
   <w.rf>
    <LM>w#w-d1t1097-11</LM>
   </w.rf>
   <form>starosta</form>
   <lemma>starosta</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-d1t1097-12">
   <w.rf>
    <LM>w#w-d1t1097-12</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m981-d1t1097-13">
   <w.rf>
    <LM>w#w-d1t1097-13</LM>
   </w.rf>
   <form>Jeruzalém</form>
   <lemma>Jeruzalém_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m981-577-213">
   <w.rf>
    <LM>w#w-577-213</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-577-214">
   <w.rf>
    <LM>w#w-577-214</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-577-215">
   <w.rf>
    <LM>w#w-577-215</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-216">
  <m id="m981-d1t1099-1">
   <w.rf>
    <LM>w#w-d1t1099-1</LM>
   </w.rf>
   <form>Jeruzalém</form>
   <lemma>Jeruzalém_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m981-577-587">
   <w.rf>
    <LM>w#w-577-587</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1099-2">
   <w.rf>
    <LM>w#w-d1t1099-2</LM>
   </w.rf>
   <form>vystavěný</form>
   <lemma>vystavěný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m981-d1t1099-3">
   <w.rf>
    <LM>w#w-d1t1099-3</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1099-4">
   <w.rf>
    <LM>w#w-d1t1099-4</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m981-d1t1099-5">
   <w.rf>
    <LM>w#w-d1t1099-5</LM>
   </w.rf>
   <form>pomocí</form>
   <lemma>pomoc</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m981-577-588">
   <w.rf>
    <LM>w#w-577-588</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1101-2">
   <w.rf>
    <LM>w#w-d1t1101-2</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1103-2">
   <w.rf>
    <LM>w#w-d1t1103-2</LM>
   </w.rf>
   <form>žebráním</form>
   <lemma>žebrání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m981-216-217">
   <w.rf>
    <LM>w#w-216-217</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-218">
  <m id="m981-d1t1106-3">
   <w.rf>
    <LM>w#w-d1t1106-3</LM>
   </w.rf>
   <form>Nazýval</form>
   <lemma>nazývat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1103-5">
   <w.rf>
    <LM>w#w-d1t1103-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1106-4">
   <w.rf>
    <LM>w#w-d1t1106-4</LM>
   </w.rf>
   <form>největším</form>
   <lemma>velký</lemma>
   <tag>AAMS7----3A----</tag>
  </m>
  <m id="m981-d1t1106-5">
   <w.rf>
    <LM>w#w-d1t1106-5</LM>
   </w.rf>
   <form>žebrákem</form>
   <lemma>žebrák</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m981-d1t1106-6">
   <w.rf>
    <LM>w#w-d1t1106-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1106-7">
   <w.rf>
    <LM>w#w-d1t1106-7</LM>
   </w.rf>
   <form>světě</form>
   <lemma>svět</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m981-d-id85204">
   <w.rf>
    <LM>w#w-d-id85204</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1106-9">
   <w.rf>
    <LM>w#w-d1t1106-9</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t1108-1">
   <w.rf>
    <LM>w#w-d1t1108-1</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1108-2">
   <w.rf>
    <LM>w#w-d1t1108-2</LM>
   </w.rf>
   <form>amerických</form>
   <lemma>americký</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m981-d1t1108-3">
   <w.rf>
    <LM>w#w-d1t1108-3</LM>
   </w.rf>
   <form>Židů</form>
   <lemma>Žid_;E</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m981-d1t1108-6">
   <w.rf>
    <LM>w#w-d1t1108-6</LM>
   </w.rf>
   <form>žebral</form>
   <lemma>žebrat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1108-5">
   <w.rf>
    <LM>w#w-d1t1108-5</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1110-2">
   <w.rf>
    <LM>w#w-d1t1110-2</LM>
   </w.rf>
   <form>úžasné</form>
   <lemma>úžasný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m981-d1t1110-3">
   <w.rf>
    <LM>w#w-d1t1110-3</LM>
   </w.rf>
   <form>sumy</form>
   <lemma>suma</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m981-d-id85372">
   <w.rf>
    <LM>w#w-d-id85372</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1110-5">
   <w.rf>
    <LM>w#w-d1t1110-5</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m981-d1t1110-6">
   <w.rf>
    <LM>w#w-d1t1110-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1110-7">
   <w.rf>
    <LM>w#w-d1t1110-7</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1110-8">
   <w.rf>
    <LM>w#w-d1t1110-8</LM>
   </w.rf>
   <form>čtvrt</form>
   <lemma>čtvrt</lemma>
   <tag>CzFS4----------</tag>
  </m>
  <m id="m981-d1t1110-9">
   <w.rf>
    <LM>w#w-d1t1110-9</LM>
   </w.rf>
   <form>miliardy</form>
   <lemma>miliarda`1000000000</lemma>
   <tag>CzFS2----------</tag>
  </m>
  <m id="m981-d1t1110-10">
   <w.rf>
    <LM>w#w-d1t1110-10</LM>
   </w.rf>
   <form>dolarů</form>
   <lemma>dolar</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m981-577-592">
   <w.rf>
    <LM>w#w-577-592</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-593">
  <m id="m981-d1t1112-2">
   <w.rf>
    <LM>w#w-d1t1112-2</LM>
   </w.rf>
   <form>Celý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m981-d1t1112-3">
   <w.rf>
    <LM>w#w-d1t1112-3</LM>
   </w.rf>
   <form>Jeruzalém</form>
   <lemma>Jeruzalém_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m981-d1t1112-4">
   <w.rf>
    <LM>w#w-d1t1112-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m981-d1t1112-5">
   <w.rf>
    <LM>w#w-d1t1112-5</LM>
   </w.rf>
   <form>vystavěný</form>
   <lemma>vystavěný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m981-d1t1112-7">
   <w.rf>
    <LM>w#w-d1t1112-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1112-8">
   <w.rf>
    <LM>w#w-d1t1112-8</LM>
   </w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m981-d1t1114-1">
   <w.rf>
    <LM>w#w-d1t1114-1</LM>
   </w.rf>
   <form>milodarů</form>
   <lemma>milodar</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m981-d1t1114-3">
   <w.rf>
    <LM>w#w-d1t1114-3</LM>
   </w.rf>
   <form>amerických</form>
   <lemma>americký</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m981-d1t1114-4">
   <w.rf>
    <LM>w#w-d1t1114-4</LM>
   </w.rf>
   <form>Židů</form>
   <lemma>Žid_;E</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m981-d-id85645">
   <w.rf>
    <LM>w#w-d-id85645</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1115-x2">
  <m id="m981-d1t1118-1">
   <w.rf>
    <LM>w#w-d1t1118-1</LM>
   </w.rf>
   <form>Ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1118-2">
   <w.rf>
    <LM>w#w-d1t1118-2</LM>
   </w.rf>
   <form>mnohem</form>
   <lemma>mnohem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1118-3">
   <w.rf>
    <LM>w#w-d1t1118-3</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m981-d1t1118-4">
   <w.rf>
    <LM>w#w-d1t1118-4</LM>
   </w.rf>
   <form>nežli</form>
   <lemma>nežli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1e1115-x2-719">
   <w.rf>
    <LM>w#w-d1e1115-x2-719</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1e1115-x2-720">
   <w.rf>
    <LM>w#w-d1e1115-x2-720</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m981-d1e1115-x2-220">
   <w.rf>
    <LM>w#w-d1e1115-x2-220</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1e1115-x2-721">
   <w.rf>
    <LM>w#w-d1e1115-x2-721</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1126-1">
   <w.rf>
    <LM>w#w-d1t1126-1</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m981-d1t1126-2">
   <w.rf>
    <LM>w#w-d1t1126-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m981-d-id85691">
   <w.rf>
    <LM>w#w-d-id85691</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1e1115-x2-735">
   <w.rf>
    <LM>w#w-d1e1115-x2-735</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1e1115-x2-736">
   <w.rf>
    <LM>w#w-d1e1115-x2-736</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1119-x3">
  <m id="m981-d1t1128-1">
   <w.rf>
    <LM>w#w-d1t1128-1</LM>
   </w.rf>
   <form>Mnohem</form>
   <lemma>mnohem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1128-2">
   <w.rf>
    <LM>w#w-d1t1128-2</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m981-d-id85860">
   <w.rf>
    <LM>w#w-d-id85860</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1129-x2">
  <m id="m981-d1t1134-5">
   <w.rf>
    <LM>w#w-d1t1134-5</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1134-6">
   <w.rf>
    <LM>w#w-d1t1134-6</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m981-d-id86040">
   <w.rf>
    <LM>w#w-d-id86040</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1134-9">
   <w.rf>
    <LM>w#w-d1t1134-9</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1134-10">
   <w.rf>
    <LM>w#w-d1t1134-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1134-11">
   <w.rf>
    <LM>w#w-d1t1134-11</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m981-d1t1134-12">
   <w.rf>
    <LM>w#w-d1t1134-12</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1134-13">
   <w.rf>
    <LM>w#w-d1t1134-13</LM>
   </w.rf>
   <form>potkala</form>
   <lemma>potkat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m981-d1t1134-14">
   <w.rf>
    <LM>w#w-d1t1134-14</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m981-d1t1134-15">
   <w.rf>
    <LM>w#w-d1t1134-15</LM>
   </w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>CnXP7----------</tag>
  </m>
  <m id="m981-d1t1134-16">
   <w.rf>
    <LM>w#w-d1t1134-16</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m981-d1e1129-x2-905">
   <w.rf>
    <LM>w#w-d1e1129-x2-905</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1136-1">
   <w.rf>
    <LM>w#w-d1t1136-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t1136-3">
   <w.rf>
    <LM>w#w-d1t1136-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1136-2">
   <w.rf>
    <LM>w#w-d1t1136-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1136-4">
   <w.rf>
    <LM>w#w-d1t1136-4</LM>
   </w.rf>
   <form>prvně</form>
   <lemma>prvně</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-d1t1138-1">
   <w.rf>
    <LM>w#w-d1t1138-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1138-2">
   <w.rf>
    <LM>w#w-d1t1138-2</LM>
   </w.rf>
   <form>návštěvě</form>
   <lemma>návštěva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m981-d1t1138-4">
   <w.rf>
    <LM>w#w-d1t1138-4</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1138-5">
   <w.rf>
    <LM>w#w-d1t1138-5</LM>
   </w.rf>
   <form>dlouhých</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m981-d1t1138-6">
   <w.rf>
    <LM>w#w-d1t1138-6</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m981-d1e1129-x2-907">
   <w.rf>
    <LM>w#w-d1e1129-x2-907</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-910">
  <m id="m981-d1t1140-1">
   <w.rf>
    <LM>w#w-d1t1140-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1140-2">
   <w.rf>
    <LM>w#w-d1t1140-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m981-d1t1140-3">
   <w.rf>
    <LM>w#w-d1t1140-3</LM>
   </w.rf>
   <form>1948</form>
   <lemma>1948</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m981-d1t1140-7">
   <w.rf>
    <LM>w#w-d1t1140-7</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1140-5">
   <w.rf>
    <LM>w#w-d1t1140-5</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1140-8">
   <w.rf>
    <LM>w#w-d1t1140-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d-id86489">
   <w.rf>
    <LM>w#w-d-id86489</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1143-1">
   <w.rf>
    <LM>w#w-d1t1143-1</LM>
   </w.rf>
   <form>vyjednával</form>
   <lemma>vyjednávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1143-2">
   <w.rf>
    <LM>w#w-d1t1143-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m981-d1t1143-3">
   <w.rf>
    <LM>w#w-d1t1143-3</LM>
   </w.rf>
   <form>vládou</form>
   <lemma>vláda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m981-d1t1143-4">
   <w.rf>
    <LM>w#w-d1t1143-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1143-5">
   <w.rf>
    <LM>w#w-d1t1143-5</LM>
   </w.rf>
   <form>dodávce</form>
   <lemma>dodávka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m981-d1t1143-6">
   <w.rf>
    <LM>w#w-d1t1143-6</LM>
   </w.rf>
   <form>zbraní</form>
   <lemma>zbraň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m981-910-920">
   <w.rf>
    <LM>w#w-910-920</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-921">
  <m id="m981-d1t1143-9">
   <w.rf>
    <LM>w#w-d1t1143-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t1143-10">
   <w.rf>
    <LM>w#w-d1t1143-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1143-12">
   <w.rf>
    <LM>w#w-d1t1143-12</LM>
   </w.rf>
   <form>Kolek</form>
   <lemma>Kolek-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-d-id86652">
   <w.rf>
    <LM>w#w-d-id86652</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1145-2">
   <w.rf>
    <LM>w#w-d1t1145-2</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-921-929">
   <w.rf>
    <LM>w#w-921-929</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m981-d1t1145-3">
   <w.rf>
    <LM>w#w-d1t1145-3</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1145-4">
   <w.rf>
    <LM>w#w-d1t1145-4</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d1t1145-5">
   <w.rf>
    <LM>w#w-d1t1145-5</LM>
   </w.rf>
   <form>Kolekt</form>
   <lemma>Kolekt_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-d-id86756">
   <w.rf>
    <LM>w#w-d-id86756</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1147-1">
   <w.rf>
    <LM>w#w-d1t1147-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t1147-2">
   <w.rf>
    <LM>w#w-d1t1147-2</LM>
   </w.rf>
   <form>všude</form>
   <lemma>všude</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1147-3">
   <w.rf>
    <LM>w#w-d1t1147-3</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1147-4">
   <w.rf>
    <LM>w#w-d1t1147-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1147-5">
   <w.rf>
    <LM>w#w-d1t1147-5</LM>
   </w.rf>
   <form>vybírat</form>
   <lemma>vybírat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m981-d1t1149-1">
   <w.rf>
    <LM>w#w-d1t1149-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1161-1">
   <w.rf>
    <LM>w#w-d1t1161-1</LM>
   </w.rf>
   <form>žebrat</form>
   <lemma>žebrat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m981-d-id85929">
   <w.rf>
    <LM>w#w-d-id85929</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1162-x2">
  <m id="m981-d1t1169-5">
   <w.rf>
    <LM>w#w-d1t1169-5</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1169-6">
   <w.rf>
    <LM>w#w-d1t1169-6</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-d1t1169-7">
   <w.rf>
    <LM>w#w-d1t1169-7</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1169-8">
   <w.rf>
    <LM>w#w-d1t1169-8</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m981-d-id87171">
   <w.rf>
    <LM>w#w-d-id87171</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1169-13">
   <w.rf>
    <LM>w#w-d1t1169-13</LM>
   </w.rf>
   <form>Kolekovci</form>
   <lemma>Kolekovec_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m981-d1e1162-x2-1389">
   <w.rf>
    <LM>w#w-d1e1162-x2-1389</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1169-11">
   <w.rf>
    <LM>w#w-d1t1169-11</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d1t1169-14">
   <w.rf>
    <LM>w#w-d1t1169-14</LM>
   </w.rf>
   <form>každé</form>
   <lemma>každý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m981-d1t1169-15">
   <w.rf>
    <LM>w#w-d1t1169-15</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m981-d1t1171-1">
   <w.rf>
    <LM>w#w-d1t1171-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1171-2">
   <w.rf>
    <LM>w#w-d1t1171-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1171-3">
   <w.rf>
    <LM>w#w-d1t1171-3</LM>
   </w.rf>
   <form>jaře</form>
   <lemma>jaro</lemma>
   <tag>NNNS6-----A---1</tag>
  </m>
  <m id="m981-d1e1162-x2-1378">
   <w.rf>
    <LM>w#w-d1e1162-x2-1378</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-1379">
  <m id="m981-d1t1171-5">
   <w.rf>
    <LM>w#w-d1t1171-5</LM>
   </w.rf>
   <form>Léto</form>
   <lemma>léto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m981-d1t1171-6">
   <w.rf>
    <LM>w#w-d1t1171-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1171-7">
   <w.rf>
    <LM>w#w-d1t1171-7</LM>
   </w.rf>
   <form>trávilo</form>
   <lemma>trávit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1171-8">
   <w.rf>
    <LM>w#w-d1t1171-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1171-9">
   <w.rf>
    <LM>w#w-d1t1171-9</LM>
   </w.rf>
   <form>Bytči</form>
   <lemma>Bytča_;G</lemma>
   <tag>NNFS6-----A---1</tag>
  </m>
  <m id="m981-d-id87408">
   <w.rf>
    <LM>w#w-d-id87408</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1171-13">
   <w.rf>
    <LM>w#w-d1t1171-13</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m981-d1t1171-12">
   <w.rf>
    <LM>w#w-d1t1171-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1171-14">
   <w.rf>
    <LM>w#w-d1t1171-14</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1176-1">
   <w.rf>
    <LM>w#w-d1t1176-1</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1176-2">
   <w.rf>
    <LM>w#w-d1t1176-2</LM>
   </w.rf>
   <form>blízké</form>
   <lemma>blízký</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m981-d1t1176-3">
   <w.rf>
    <LM>w#w-d1t1176-3</LM>
   </w.rf>
   <form>příbuzné</form>
   <lemma>příbuzný-1_^(člen_rodiny)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m981-1379-1392">
   <w.rf>
    <LM>w#w-1379-1392</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-1393">
  <m id="m981-d1t1176-7">
   <w.rf>
    <LM>w#w-d1t1176-7</LM>
   </w.rf>
   <form>Velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1176-6">
   <w.rf>
    <LM>w#w-d1t1176-6</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m981-d1t1176-8">
   <w.rf>
    <LM>w#w-d1t1176-8</LM>
   </w.rf>
   <form>ovlivnil</form>
   <lemma>ovlivnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m981-d1t1178-1">
   <w.rf>
    <LM>w#w-d1t1178-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1178-2">
   <w.rf>
    <LM>w#w-d1t1178-2</LM>
   </w.rf>
   <form>přemlouval</form>
   <lemma>přemlouvat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1178-3">
   <w.rf>
    <LM>w#w-d1t1178-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m981-d-id87663">
   <w.rf>
    <LM>w#w-d-id87663</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1178-5">
   <w.rf>
    <LM>w#w-d1t1178-5</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m981-d1t1178-6">
   <w.rf>
    <LM>w#w-d1t1178-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1178-7">
   <w.rf>
    <LM>w#w-d1t1178-7</LM>
   </w.rf>
   <form>přijela</form>
   <lemma>přijet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m981-1393-240">
   <w.rf>
    <LM>w#w-1393-240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-242">
  <m id="m981-d1t1178-11">
   <w.rf>
    <LM>w#w-d1t1178-11</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1178-12">
   <w.rf>
    <LM>w#w-d1t1178-12</LM>
   </w.rf>
   <form>sionista</form>
   <lemma>sionista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-d1t1180-1">
   <w.rf>
    <LM>w#w-d1t1180-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1180-2">
   <w.rf>
    <LM>w#w-d1t1180-2</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1182-1">
   <w.rf>
    <LM>w#w-d1t1182-1</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m981-d1t1184-1">
   <w.rf>
    <LM>w#w-d1t1184-1</LM>
   </w.rf>
   <form>mládí</form>
   <lemma>mládí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m981-d-id87853">
   <w.rf>
    <LM>w#w-d-id87853</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1184-3">
   <w.rf>
    <LM>w#w-d1t1184-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1184-4">
   <w.rf>
    <LM>w#w-d1t1184-4</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1184-5">
   <w.rf>
    <LM>w#w-d1t1184-5</LM>
   </w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m981-d1t1184-6">
   <w.rf>
    <LM>w#w-d1t1184-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m981-d1t1186-1">
   <w.rf>
    <LM>w#w-d1t1186-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1186-2">
   <w.rf>
    <LM>w#w-d1t1186-2</LM>
   </w.rf>
   <form>roznášel</form>
   <lemma>roznášet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1186-4">
   <w.rf>
    <LM>w#w-d1t1186-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m981-d1t1186-5">
   <w.rf>
    <LM>w#w-d1t1186-5</LM>
   </w.rf>
   <form>Vídni</form>
   <lemma>Vídeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m981-d1t1186-3">
   <w.rf>
    <LM>w#w-d1t1186-3</LM>
   </w.rf>
   <form>letáky</form>
   <lemma>leták</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m981-d1t1186-6">
   <w.rf>
    <LM>w#w-d1t1186-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1186-7">
   <w.rf>
    <LM>w#w-d1t1186-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1186-8">
   <w.rf>
    <LM>w#w-d1t1186-8</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d-id88030">
   <w.rf>
    <LM>w#w-d-id88030</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-1719">
  <m id="m981-d1t1190-2">
   <w.rf>
    <LM>w#w-d1t1190-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-1719-1734">
   <w.rf>
    <LM>w#w-1719-1734</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m981-d1t1190-4">
   <w.rf>
    <LM>w#w-d1t1190-4</LM>
   </w.rf>
   <form>1935</form>
   <lemma>1935</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m981-d1t1190-8">
   <w.rf>
    <LM>w#w-d1t1190-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1190-9">
   <w.rf>
    <LM>w#w-d1t1190-9</LM>
   </w.rf>
   <form>žil</form>
   <lemma>žít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1190-17">
   <w.rf>
    <LM>w#w-d1t1190-17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1190-18">
   <w.rf>
    <LM>w#w-d1t1190-18</LM>
   </w.rf>
   <form>Palestině</form>
   <lemma>Palestina_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m981-1719-1737">
   <w.rf>
    <LM>w#w-1719-1737</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1191-x2">
  <m id="m981-d1t1194-1">
   <w.rf>
    <LM>w#w-d1t1194-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m981-d1e1191-x2-83">
   <w.rf>
    <LM>w#w-d1e1191-x2-83</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1196-x2">
  <m id="m981-d1t1201-3">
   <w.rf>
    <LM>w#w-d1t1201-3</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m981-d1e1196-x2-146">
   <w.rf>
    <LM>w#w-d1e1196-x2-146</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1196-x3">
  <m id="m981-d1t1205-2">
   <w.rf>
    <LM>w#w-d1t1205-2</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1205-3">
   <w.rf>
    <LM>w#w-d1t1205-3</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m981-d1t1205-4">
   <w.rf>
    <LM>w#w-d1t1205-4</LM>
   </w.rf>
   <form>1934</form>
   <lemma>1934</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m981-d1t1205-6">
   <w.rf>
    <LM>w#w-d1t1205-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1205-7">
   <w.rf>
    <LM>w#w-d1t1205-7</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d-id88551">
   <w.rf>
    <LM>w#w-d-id88551</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1206-x2">
  <m id="m981-d1t1209-2">
   <w.rf>
    <LM>w#w-d1t1209-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1209-3">
   <w.rf>
    <LM>w#w-d1t1209-3</LM>
   </w.rf>
   <form>žil</form>
   <lemma>žít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1209-4">
   <w.rf>
    <LM>w#w-d1t1209-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1209-5">
   <w.rf>
    <LM>w#w-d1t1209-5</LM>
   </w.rf>
   <form>kibucu</form>
   <lemma>kibuc</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m981-d1t1209-6">
   <w.rf>
    <LM>w#w-d1t1209-6</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1209-7">
   <w.rf>
    <LM>w#w-d1t1209-7</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1209-8">
   <w.rf>
    <LM>w#w-d1t1209-8</LM>
   </w.rf>
   <form>Genezaretského</form>
   <lemma>genezaretský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m981-d1t1209-9">
   <w.rf>
    <LM>w#w-d1t1209-9</LM>
   </w.rf>
   <form>jezera</form>
   <lemma>jezero</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m981-d-id88812">
   <w.rf>
    <LM>w#w-d-id88812</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1211-1">
   <w.rf>
    <LM>w#w-d1t1211-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1213-1">
   <w.rf>
    <LM>w#w-d1t1213-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1215-1">
   <w.rf>
    <LM>w#w-d1t1215-1</LM>
   </w.rf>
   <form>rybářem</form>
   <lemma>rybář</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m981-d-id88883">
   <w.rf>
    <LM>w#w-d-id88883</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1206-x3">
  <m id="m981-d1t1220-3">
   <w.rf>
    <LM>w#w-d1t1220-3</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1220-4">
   <w.rf>
    <LM>w#w-d1t1220-4</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m981-d1t1220-2">
   <w.rf>
    <LM>w#w-d1t1220-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1220-5">
   <w.rf>
    <LM>w#w-d1t1220-5</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1220-6">
   <w.rf>
    <LM>w#w-d1t1220-6</LM>
   </w.rf>
   <form>brzo</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A---1</tag>
  </m>
  <m id="m981-d1t1220-7">
   <w.rf>
    <LM>w#w-d1t1220-7</LM>
   </w.rf>
   <form>poslali</form>
   <lemma>poslat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m981-d1t1220-9">
   <w.rf>
    <LM>w#w-d1t1220-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1220-10">
   <w.rf>
    <LM>w#w-d1t1220-10</LM>
   </w.rf>
   <form>Evropy</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d-id89050">
   <w.rf>
    <LM>w#w-d-id89050</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1220-12">
   <w.rf>
    <LM>w#w-d1t1220-12</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t1220-13">
   <w.rf>
    <LM>w#w-d1t1220-13</LM>
   </w.rf>
   <form>organizoval</form>
   <lemma>organizovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m981-d1t1222-1">
   <w.rf>
    <LM>w#w-d1t1222-1</LM>
   </w.rf>
   <form>chalucim</form>
   <lemma>chalucim-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m981-d-id89146">
   <w.rf>
    <LM>w#w-d-id89146</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1224-1">
   <w.rf>
    <LM>w#w-d1t1224-1</LM>
   </w.rf>
   <form>organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m981-d1t1228-2">
   <w.rf>
    <LM>w#w-d1t1228-2</LM>
   </w.rf>
   <form>mládeže</form>
   <lemma>mládež</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d-id89263">
   <w.rf>
    <LM>w#w-d-id89263</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1233-1">
   <w.rf>
    <LM>w#w-d1t1233-1</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m981-d1t1233-2">
   <w.rf>
    <LM>w#w-d1t1233-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1233-3">
   <w.rf>
    <LM>w#w-d1t1233-3</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1233-4">
   <w.rf>
    <LM>w#w-d1t1233-4</LM>
   </w.rf>
   <form>vypravily</form>
   <lemma>vypravit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m981-d1t1233-5">
   <w.rf>
    <LM>w#w-d1t1233-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m981-d1t1235-1">
   <w.rf>
    <LM>w#w-d1t1235-1</LM>
   </w.rf>
   <form>Palestiny</form>
   <lemma>Palestina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d1t1241-1">
   <w.rf>
    <LM>w#w-d1t1241-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t1243-1">
   <w.rf>
    <LM>w#w-d1t1243-1</LM>
   </w.rf>
   <form>dělníci</form>
   <lemma>dělník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m981-d1t1243-2">
   <w.rf>
    <LM>w#w-d1t1243-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1243-3">
   <w.rf>
    <LM>w#w-d1t1243-3</LM>
   </w.rf>
   <form>zakládaly</form>
   <lemma>zakládat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m981-d1t1243-4">
   <w.rf>
    <LM>w#w-d1t1243-4</LM>
   </w.rf>
   <form>kibucy</form>
   <lemma>kibuc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m981-d1t1243-5">
   <w.rf>
    <LM>w#w-d1t1243-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1243-6">
   <w.rf>
    <LM>w#w-d1t1243-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d-id89566">
   <w.rf>
    <LM>w#w-d-id89566</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1244-x2">
  <m id="m981-d1t1247-2">
   <w.rf>
    <LM>w#w-d1t1247-2</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m981-d1t1247-3">
   <w.rf>
    <LM>w#w-d1t1247-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m981-d1t1247-4">
   <w.rf>
    <LM>w#w-d1t1247-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1247-5">
   <w.rf>
    <LM>w#w-d1t1247-5</LM>
   </w.rf>
   <form>jela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t1247-6">
   <w.rf>
    <LM>w#w-d1t1247-6</LM>
   </w.rf>
   <form>individuálně</form>
   <lemma>individuálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-d1t1247-7">
   <w.rf>
    <LM>w#w-d1t1247-7</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1247-8">
   <w.rf>
    <LM>w#w-d1t1247-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m981-d1t1253-1">
   <w.rf>
    <LM>w#w-d1t1253-1</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS7----------</tag>
  </m>
  <m id="m981-d1e1244-x2-659">
   <w.rf>
    <LM>w#w-d1e1244-x2-659</LM>
   </w.rf>
   <form>skupinou</form>
   <lemma>skupina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m981-d1e1244-x2-660">
   <w.rf>
    <LM>w#w-d1e1244-x2-660</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1256-x2">
  <m id="m981-d1t1255-4">
   <w.rf>
    <LM>w#w-d1t1255-4</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1e1256-x2-893">
   <w.rf>
    <LM>w#w-d1e1256-x2-893</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1255-3">
   <w.rf>
    <LM>w#w-d1t1255-3</LM>
   </w.rf>
   <form>jela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t1255-2">
   <w.rf>
    <LM>w#w-d1t1255-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1259-4">
   <w.rf>
    <LM>w#w-d1t1259-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t1259-5">
   <w.rf>
    <LM>w#w-d1t1259-5</LM>
   </w.rf>
   <form>turistka</form>
   <lemma>turistka_^(*2a)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m981-d1e1256-x2-261">
   <w.rf>
    <LM>w#w-d1e1256-x2-261</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-262">
  <m id="m981-d1t1259-7">
   <w.rf>
    <LM>w#w-d1t1259-7</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1259-8">
   <w.rf>
    <LM>w#w-d1t1259-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m981-d1t1259-9">
   <w.rf>
    <LM>w#w-d1t1259-9</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS7----------</tag>
  </m>
  <m id="m981-d1t1259-10">
   <w.rf>
    <LM>w#w-d1t1259-10</LM>
   </w.rf>
   <form>přítelkyní</form>
   <lemma>přítelkyně</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m981-d1e1256-x2-898">
   <w.rf>
    <LM>w#w-d1e1256-x2-898</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1259-11">
   <w.rf>
    <LM>w#w-d1t1259-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1259-12">
   <w.rf>
    <LM>w#w-d1t1259-12</LM>
   </w.rf>
   <form>Bytčankou</form>
   <lemma>Bytčanka_;E</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m981-d1e1256-x2-900">
   <w.rf>
    <LM>w#w-d1e1256-x2-900</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1261-1">
   <w.rf>
    <LM>w#w-d1t1261-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1261-2">
   <w.rf>
    <LM>w#w-d1t1261-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1261-3">
   <w.rf>
    <LM>w#w-d1t1261-3</LM>
   </w.rf>
   <form>vypravily</form>
   <lemma>vypravit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m981-d1t1261-4">
   <w.rf>
    <LM>w#w-d1t1261-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1261-5">
   <w.rf>
    <LM>w#w-d1t1261-5</LM>
   </w.rf>
   <form>dostaly</form>
   <lemma>dostat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m981-d1t1261-6">
   <w.rf>
    <LM>w#w-d1t1261-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1261-8">
   <w.rf>
    <LM>w#w-d1t1261-8</LM>
   </w.rf>
   <form>turistické</form>
   <lemma>turistický</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m981-d1t1263-1">
   <w.rf>
    <LM>w#w-d1t1263-1</LM>
   </w.rf>
   <form>vízum</form>
   <lemma>vízum_^(cest._formalita)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m981-d1e1256-x2-903">
   <w.rf>
    <LM>w#w-d1e1256-x2-903</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-906">
  <m id="m981-d1t1274-1">
   <w.rf>
    <LM>w#w-d1t1274-1</LM>
   </w.rf>
   <form>Musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t1274-2">
   <w.rf>
    <LM>w#w-d1t1274-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1274-3">
   <w.rf>
    <LM>w#w-d1t1274-3</LM>
   </w.rf>
   <form>dát</form>
   <lemma>dát-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m981-d1t1274-4">
   <w.rf>
    <LM>w#w-d1t1274-4</LM>
   </w.rf>
   <form>záloha</form>
   <lemma>záloha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m981-d1t1276-1">
   <w.rf>
    <LM>w#w-d1t1276-1</LM>
   </w.rf>
   <form>Angličanům</form>
   <lemma>Angličan_;E</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m981-d-id90422">
   <w.rf>
    <LM>w#w-d-id90422</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1278-1">
   <w.rf>
    <LM>w#w-d1t1278-1</LM>
   </w.rf>
   <form>stálo</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1278-2">
   <w.rf>
    <LM>w#w-d1t1278-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t1278-3">
   <w.rf>
    <LM>w#w-d1t1278-3</LM>
   </w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m981-d1t1278-4">
   <w.rf>
    <LM>w#w-d1t1278-4</LM>
   </w.rf>
   <form>liber</form>
   <lemma>libra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m981-d-id90501">
   <w.rf>
    <LM>w#w-d-id90501</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1278-6">
   <w.rf>
    <LM>w#w-d1t1278-6</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m981-d1t1278-7">
   <w.rf>
    <LM>w#w-d1t1278-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1278-8">
   <w.rf>
    <LM>w#w-d1t1278-8</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-d1t1280-1">
   <w.rf>
    <LM>w#w-d1t1280-1</LM>
   </w.rf>
   <form>peněz</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m981-906-274">
   <w.rf>
    <LM>w#w-906-274</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-275">
  <m id="m981-d1t1283-2">
   <w.rf>
    <LM>w#w-d1t1283-2</LM>
   </w.rf>
   <form>Povolení</form>
   <lemma>povolení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m981-d1t1285-1">
   <w.rf>
    <LM>w#w-d1t1285-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m981-d1t1285-2">
   <w.rf>
    <LM>w#w-d1t1285-2</LM>
   </w.rf>
   <form>pobytu</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m981-d1t1285-3">
   <w.rf>
    <LM>w#w-d1t1285-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m981-906-224">
   <w.rf>
    <LM>w#w-906-224</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m981-d1t1287-1">
   <w.rf>
    <LM>w#w-d1t1287-1</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m981-d1t1287-2">
   <w.rf>
    <LM>w#w-d1t1287-2</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m981-d-id90705">
   <w.rf>
    <LM>w#w-d-id90705</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1256-x3">
  <m id="m981-d1t1291-7">
   <w.rf>
    <LM>w#w-d1t1291-7</LM>
   </w.rf>
   <form>Obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m981-d1t1291-8">
   <w.rf>
    <LM>w#w-d1t1291-8</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m981-d1t1291-4">
   <w.rf>
    <LM>w#w-d1t1291-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1291-5">
   <w.rf>
    <LM>w#w-d1t1291-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1291-6">
   <w.rf>
    <LM>w#w-d1t1291-6</LM>
   </w.rf>
   <form>vypravily</form>
   <lemma>vypravit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m981-d1t1291-12">
   <w.rf>
    <LM>w#w-d1t1291-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1293-3">
   <w.rf>
    <LM>w#w-d1t1293-3</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m981-d1t1293-1">
   <w.rf>
    <LM>w#w-d1t1293-1</LM>
   </w.rf>
   <form>1935</form>
   <lemma>1935</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m981-d1t1293-4">
   <w.rf>
    <LM>w#w-d1t1293-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m981-d1t1293-5">
   <w.rf>
    <LM>w#w-d1t1293-5</LM>
   </w.rf>
   <form>říjnu</form>
   <lemma>říjen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m981-d1e1256-x3-281">
   <w.rf>
    <LM>w#w-d1e1256-x3-281</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-282">
  <m id="m981-d1t1296-2">
   <w.rf>
    <LM>w#w-d1t1296-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1296-3">
   <w.rf>
    <LM>w#w-d1t1296-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t1296-4">
   <w.rf>
    <LM>w#w-d1t1296-4</LM>
   </w.rf>
   <form>všelijaké</form>
   <lemma>všelijaký</lemma>
   <tag>PZNS1----------</tag>
  </m>
  <m id="m981-282-283">
   <w.rf>
    <LM>w#w-282-283</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-284">
  <m id="m981-d1e1256-x3-392">
   <w.rf>
    <LM>w#w-d1e1256-x3-392</LM>
   </w.rf>
   <form>Napřed</form>
   <lemma>napřed</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1e1256-x3-393">
   <w.rf>
    <LM>w#w-d1e1256-x3-393</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m981-d1e1256-x3-394">
   <w.rf>
    <LM>w#w-d1e1256-x3-394</LM>
   </w.rf>
   <form>myslely</form>
   <lemma>myslit</lemma>
   <tag>VpTP----R-AAI-1</tag>
  </m>
  <m id="m981-d1e1256-x3-399">
   <w.rf>
    <LM>w#w-d1e1256-x3-399</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1e1256-x3-395">
   <w.rf>
    <LM>w#w-d1e1256-x3-395</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m981-d1t1300-3">
   <w.rf>
    <LM>w#w-d1t1300-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m981-d1t1300-4">
   <w.rf>
    <LM>w#w-d1t1300-4</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m981-d1t1300-5">
   <w.rf>
    <LM>w#w-d1t1300-5</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m981-d1t1300-6">
   <w.rf>
    <LM>w#w-d1t1300-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m981-d1t1300-7">
   <w.rf>
    <LM>w#w-d1t1300-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1300-8">
   <w.rf>
    <LM>w#w-d1t1300-8</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m981-d1t1300-9">
   <w.rf>
    <LM>w#w-d1t1300-9</LM>
   </w.rf>
   <form>vydržíme</form>
   <lemma>vydržet</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m981-d1e1256-x3-400">
   <w.rf>
    <LM>w#w-d1e1256-x3-400</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1304-1">
   <w.rf>
    <LM>w#w-d1t1304-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1304-2">
   <w.rf>
    <LM>w#w-d1t1304-2</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1304-6">
   <w.rf>
    <LM>w#w-d1t1304-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1304-7">
   <w.rf>
    <LM>w#w-d1t1304-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m981-d1t1304-8">
   <w.rf>
    <LM>w#w-d1t1304-8</LM>
   </w.rf>
   <form>pomalu</form>
   <lemma>pomalu</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m981-d1t1304-9">
   <w.rf>
    <LM>w#w-d1t1304-9</LM>
   </w.rf>
   <form>zvykly</form>
   <lemma>zvyknout</lemma>
   <tag>VpTP----R-AAP-1</tag>
  </m>
  <m id="m981-d1e1256-x3-370">
   <w.rf>
    <LM>w#w-d1e1256-x3-370</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-371">
  <m id="m981-d1t1304-11">
   <w.rf>
    <LM>w#w-d1t1304-11</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m981-d1t1304-12">
   <w.rf>
    <LM>w#w-d1t1304-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1304-13">
   <w.rf>
    <LM>w#w-d1t1304-13</LM>
   </w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m981-d1t1311-1">
   <w.rf>
    <LM>w#w-d1t1311-1</LM>
   </w.rf>
   <form>mládeže</form>
   <lemma>mládež</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d1t1311-2">
   <w.rf>
    <LM>w#w-d1t1311-2</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m981-d1t1311-3">
   <w.rf>
    <LM>w#w-d1t1311-3</LM>
   </w.rf>
   <form>Žiliny</form>
   <lemma>Žilina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d-id91542">
   <w.rf>
    <LM>w#w-d-id91542</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1311-6">
   <w.rf>
    <LM>w#w-d1t1311-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m981-d1t1311-7">
   <w.rf>
    <LM>w#w-d1t1311-7</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m981-d1t1311-8">
   <w.rf>
    <LM>w#w-d1t1311-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1311-9">
   <w.rf>
    <LM>w#w-d1t1311-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m981-d1t1311-10">
   <w.rf>
    <LM>w#w-d1t1311-10</LM>
   </w.rf>
   <form>spřátelily</form>
   <lemma>spřátelit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m981-d-id91631">
   <w.rf>
    <LM>w#w-d-id91631</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-d1e1256-x4">
  <m id="m981-d1t1311-12">
   <w.rf>
    <LM>w#w-d1t1311-12</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1311-13">
   <w.rf>
    <LM>w#w-d1t1311-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1313-12">
   <w.rf>
    <LM>w#w-d1t1313-12</LM>
   </w.rf>
   <form>honorární</form>
   <lemma>honorární</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m981-d1t1313-13">
   <w.rf>
    <LM>w#w-d1t1313-13</LM>
   </w.rf>
   <form>konzul</form>
   <lemma>konzul</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-d1t1313-14">
   <w.rf>
    <LM>w#w-d1t1313-14</LM>
   </w.rf>
   <form>Československa</form>
   <lemma>Československo_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m981-d1e1256-x4-292">
   <w.rf>
    <LM>w#w-d1e1256-x4-292</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1313-15">
   <w.rf>
    <LM>w#w-d1t1313-15</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1315-3">
   <w.rf>
    <LM>w#w-d1t1315-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1315-1">
   <w.rf>
    <LM>w#w-d1t1315-1</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m981-d1t1315-2">
   <w.rf>
    <LM>w#w-d1t1315-2</LM>
   </w.rf>
   <form>Žiliny</form>
   <lemma>Žilina_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m981-d1e1256-x4-577">
   <w.rf>
    <LM>w#w-d1e1256-x4-577</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m981-d1t1317-1">
   <w.rf>
    <LM>w#w-d1t1317-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m981-d1t1317-2">
   <w.rf>
    <LM>w#w-d1t1317-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m981-d1t1317-3">
   <w.rf>
    <LM>w#w-d1t1317-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m981-d1t1317-4">
   <w.rf>
    <LM>w#w-d1t1317-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1317-5">
   <w.rf>
    <LM>w#w-d1t1317-5</LM>
   </w.rf>
   <form>přítel</form>
   <lemma>přítel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m981-d1t1317-6">
   <w.rf>
    <LM>w#w-d1t1317-6</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m981-d1t1319-1">
   <w.rf>
    <LM>w#w-d1t1319-1</LM>
   </w.rf>
   <form>bratrance</form>
   <lemma>bratranec</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m981-d1e1256-x4-583">
   <w.rf>
    <LM>w#w-d1e1256-x4-583</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m981-13808_01-584">
  <m id="m981-d1t1322-4">
   <w.rf>
    <LM>w#w-d1t1322-4</LM>
   </w.rf>
   <form>Pomalounku</form>
   <lemma>pomalounku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1324-1">
   <w.rf>
    <LM>w#w-d1t1324-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m981-d1t1324-2">
   <w.rf>
    <LM>w#w-d1t1324-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m981-d1t1324-3">
   <w.rf>
    <LM>w#w-d1t1324-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m981-d1t1324-4">
   <w.rf>
    <LM>w#w-d1t1324-4</LM>
   </w.rf>
   <form>zvykaly</form>
   <lemma>zvykat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m981-d-id91639">
   <w.rf>
    <LM>w#w-d-id91639</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
