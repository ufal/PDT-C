<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_714.01.w.gz" />
  </references>
 </head>
 <s id="m714-26171_04-51">
  <m id="m714-d1t209-11">
   <w.rf>
    <LM>w#w-d1t209-11</LM>
   </w.rf>
   <form>Řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t209-10">
   <w.rf>
    <LM>w#w-d1t209-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x20-3487">
   <w.rf>
    <LM>w#w-d1e24-x20-3487</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m714-51-52">
   <w.rf>
    <LM>w#w-51-52</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x20-3488">
   <w.rf>
    <LM>w#w-d1e24-x20-3488</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t209-13">
   <w.rf>
    <LM>w#w-d1t209-13</LM>
   </w.rf>
   <form>Aha</form>
   <lemma>aha</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m714-51-55">
   <w.rf>
    <LM>w#w-51-55</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x20-3489">
   <w.rf>
    <LM>w#w-d1e24-x20-3489</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-56">
  <m id="m714-d1t211-6">
   <w.rf>
    <LM>w#w-d1t211-6</LM>
   </w.rf>
   <form>Řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t211-5">
   <w.rf>
    <LM>w#w-d1t211-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x20-3493">
   <w.rf>
    <LM>w#w-d1e24-x20-3493</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x20-3492">
   <w.rf>
    <LM>w#w-d1e24-x20-3492</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t211-9">
   <w.rf>
    <LM>w#w-d1t211-9</LM>
   </w.rf>
   <form>Musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t211-10">
   <w.rf>
    <LM>w#w-d1t211-10</LM>
   </w.rf>
   <form>otevřít</form>
   <lemma>otevřít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d1t211-11">
   <w.rf>
    <LM>w#w-d1t211-11</LM>
   </w.rf>
   <form>okno</form>
   <lemma>okno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m714-d-id66609">
   <w.rf>
    <LM>w#w-d-id66609</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t211-14">
   <w.rf>
    <LM>w#w-d1t211-14</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t211-15">
   <w.rf>
    <LM>w#w-d1t211-15</LM>
   </w.rf>
   <form>málo</form>
   <lemma>málo-1_^(málo_peněz)</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m714-d1t211-16">
   <w.rf>
    <LM>w#w-d1t211-16</LM>
   </w.rf>
   <form>vzduchu</form>
   <lemma>vzduch</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d-id66680">
   <w.rf>
    <LM>w#w-d-id66680</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x20-3494">
   <w.rf>
    <LM>w#w-d1e24-x20-3494</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x21">
  <m id="m714-d1t213-1">
   <w.rf>
    <LM>w#w-d1t213-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t213-2">
   <w.rf>
    <LM>w#w-d1t213-2</LM>
   </w.rf>
   <form>šup</form>
   <lemma>šup-2</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m714-d1e24-x21-3686">
   <w.rf>
    <LM>w#w-d1e24-x21-3686</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t213-4">
   <w.rf>
    <LM>w#w-d1t213-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t213-5">
   <w.rf>
    <LM>w#w-d1t213-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t213-6">
   <w.rf>
    <LM>w#w-d1t213-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t213-7">
   <w.rf>
    <LM>w#w-d1t213-7</LM>
   </w.rf>
   <form>venku</form>
   <lemma>venku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t213-8">
   <w.rf>
    <LM>w#w-d1t213-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t213-9">
   <w.rf>
    <LM>w#w-d1t213-9</LM>
   </w.rf>
   <form>okna</form>
   <lemma>okno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m714-d-id66844">
   <w.rf>
    <LM>w#w-d-id66844</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t213-11">
   <w.rf>
    <LM>w#w-d1t213-11</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t213-12">
   <w.rf>
    <LM>w#w-d1t213-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t213-17">
   <w.rf>
    <LM>w#w-d1t213-17</LM>
   </w.rf>
   <form>oběhla</form>
   <lemma>oběhnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m714-d1t213-18">
   <w.rf>
    <LM>w#w-d1t213-18</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t215-1">
   <w.rf>
    <LM>w#w-d1t215-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t215-2">
   <w.rf>
    <LM>w#w-d1t215-2</LM>
   </w.rf>
   <form>šup</form>
   <lemma>šup-2</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m714-d1t215-3">
   <w.rf>
    <LM>w#w-d1t215-3</LM>
   </w.rf>
   <form>dozadu</form>
   <lemma>dozadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t215-4">
   <w.rf>
    <LM>w#w-d1t215-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t215-5">
   <w.rf>
    <LM>w#w-d1t215-5</LM>
   </w.rf>
   <form>polí</form>
   <lemma>pole</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m714-d-id67056">
   <w.rf>
    <LM>w#w-d-id67056</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x22">
  <m id="m714-d1t222-2">
   <w.rf>
    <LM>w#w-d1t222-2</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t222-3">
   <w.rf>
    <LM>w#w-d1t222-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m714-d1t222-4">
   <w.rf>
    <LM>w#w-d1t222-4</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d1t222-6">
   <w.rf>
    <LM>w#w-d1t222-6</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t222-7">
   <w.rf>
    <LM>w#w-d1t222-7</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m714-d1t222-8">
   <w.rf>
    <LM>w#w-d1t222-8</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS6-----A---9</tag>
  </m>
  <m id="m714-d1t222-9">
   <w.rf>
    <LM>w#w-d1t222-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t222-10">
   <w.rf>
    <LM>w#w-d1t222-10</LM>
   </w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d1e24-x22-3792">
   <w.rf>
    <LM>w#w-d1e24-x22-3792</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t224-1">
   <w.rf>
    <LM>w#w-d1t224-1</LM>
   </w.rf>
   <form>čili</form>
   <lemma>čili-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t224-11">
   <w.rf>
    <LM>w#w-d1t224-11</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m714-d1t224-13">
   <w.rf>
    <LM>w#w-d1t224-13</LM>
   </w.rf>
   <form>vězeňkyně</form>
   <lemma>vězeňkyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1t224-9">
   <w.rf>
    <LM>w#w-d1t224-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t224-10">
   <w.rf>
    <LM>w#w-d1t224-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t224-12">
   <w.rf>
    <LM>w#w-d1t224-12</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t224-7">
   <w.rf>
    <LM>w#w-d1t224-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t224-8">
   <w.rf>
    <LM>w#w-d1t224-8</LM>
   </w.rf>
   <form>Němkami</form>
   <lemma>Němka_;E</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m714-d1t224-14">
   <w.rf>
    <LM>w#w-d1t224-14</LM>
   </w.rf>
   <form>schovat</form>
   <lemma>schovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d1t224-17">
   <w.rf>
    <LM>w#w-d1t224-17</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t224-18">
   <w.rf>
    <LM>w#w-d1t224-18</LM>
   </w.rf>
   <form>Rusy</form>
   <lemma>Rus-1_;E</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m714-d-id67480">
   <w.rf>
    <LM>w#w-d-id67480</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x23">
  <m id="m714-d1t233-4">
   <w.rf>
    <LM>w#w-d1t233-4</LM>
   </w.rf>
   <form>Jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m714-d1t233-5">
   <w.rf>
    <LM>w#w-d1t233-5</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d1t233-6">
   <w.rf>
    <LM>w#w-d1t233-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t233-7">
   <w.rf>
    <LM>w#w-d1t233-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t233-9">
   <w.rf>
    <LM>w#w-d1t233-9</LM>
   </w.rf>
   <form>sebraly</form>
   <lemma>sebrat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m714-d1t233-10">
   <w.rf>
    <LM>w#w-d1t233-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t233-11">
   <w.rf>
    <LM>w#w-d1t233-11</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m714-d1t235-1">
   <w.rf>
    <LM>w#w-d1t235-1</LM>
   </w.rf>
   <form>dívkou</form>
   <lemma>dívka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m714-d1t235-2">
   <w.rf>
    <LM>w#w-d1t235-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t235-4">
   <w.rf>
    <LM>w#w-d1t235-4</LM>
   </w.rf>
   <form>Bratislavy</form>
   <lemma>Bratislava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m714-d1t235-5">
   <w.rf>
    <LM>w#w-d1t235-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t235-6">
   <w.rf>
    <LM>w#w-d1t235-6</LM>
   </w.rf>
   <form>přidala</form>
   <lemma>přidat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t235-7">
   <w.rf>
    <LM>w#w-d1t235-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t235-8">
   <w.rf>
    <LM>w#w-d1t235-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t235-9">
   <w.rf>
    <LM>w#w-d1t235-9</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m714-d1t235-11">
   <w.rf>
    <LM>w#w-d1t235-11</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m714-d1t235-12">
   <w.rf>
    <LM>w#w-d1t235-12</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t235-14">
   <w.rf>
    <LM>w#w-d1t235-14</LM>
   </w.rf>
   <form>Berlína</form>
   <lemma>Berlín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d-id67926">
   <w.rf>
    <LM>w#w-d-id67926</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t235-16">
   <w.rf>
    <LM>w#w-d1t235-16</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t235-17">
   <w.rf>
    <LM>w#w-d1t235-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t235-18">
   <w.rf>
    <LM>w#w-d1t235-18</LM>
   </w.rf>
   <form>pojede</form>
   <lemma>jet-1</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m714-d1e24-x23-67">
   <w.rf>
    <LM>w#w-d1e24-x23-67</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-68">
  <m id="m714-d1t235-22">
   <w.rf>
    <LM>w#w-d1t235-22</LM>
   </w.rf>
   <form>Řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t235-21">
   <w.rf>
    <LM>w#w-d1t235-21</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x23-3956">
   <w.rf>
    <LM>w#w-d1e24-x23-3956</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x23-3957">
   <w.rf>
    <LM>w#w-d1e24-x23-3957</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t237-3">
   <w.rf>
    <LM>w#w-d1t237-3</LM>
   </w.rf>
   <form>Vezmeme</form>
   <lemma>vzít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m714-d1t237-2">
   <w.rf>
    <LM>w#w-d1t237-2</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="m714-d1e24-x23-3960">
   <w.rf>
    <LM>w#w-d1e24-x23-3960</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t237-4">
   <w.rf>
    <LM>w#w-d1t237-4</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m714-d-id68101">
   <w.rf>
    <LM>w#w-d-id68101</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t237-7">
   <w.rf>
    <LM>w#w-d1t237-7</LM>
   </w.rf>
   <form>řekneme</form>
   <lemma>říci</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m714-d1e24-x23-4194">
   <w.rf>
    <LM>w#w-d1e24-x23-4194</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t237-8">
   <w.rf>
    <LM>w#w-d1t237-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t237-9">
   <w.rf>
    <LM>w#w-d1t237-9</LM>
   </w.rf>
   <form>jsi</form>
   <lemma>být</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="m714-d1t237-10">
   <w.rf>
    <LM>w#w-d1t237-10</LM>
   </w.rf>
   <form>vězeňkyně</form>
   <lemma>vězeňkyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-68-69">
   <w.rf>
    <LM>w#w-68-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-70">
  <m id="m714-d1t237-11">
   <w.rf>
    <LM>w#w-d1t237-11</LM>
   </w.rf>
   <form>Ať</form>
   <lemma>ať-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t237-12">
   <w.rf>
    <LM>w#w-d1t237-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t237-13">
   <w.rf>
    <LM>w#w-d1t237-13</LM>
   </w.rf>
   <form>dostaneme</form>
   <lemma>dostat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m714-d1t237-14">
   <w.rf>
    <LM>w#w-d1t237-14</LM>
   </w.rf>
   <form>kamkoliv</form>
   <lemma>kamkoliv_,s_^(^DD**kamkoli)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x23-3963">
   <w.rf>
    <LM>w#w-d1e24-x23-3963</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t239-2">
   <w.rf>
    <LM>w#w-d1t239-2</LM>
   </w.rf>
   <form>pojedeš</form>
   <lemma>jet-1</lemma>
   <tag>VB-S---2F-AAI--</tag>
  </m>
  <m id="m714-d1t239-3">
   <w.rf>
    <LM>w#w-d1t239-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t239-4">
   <w.rf>
    <LM>w#w-d1t239-4</LM>
   </w.rf>
   <form>náma</form>
   <lemma>my</lemma>
   <tag>PP-P7--1------6</tag>
  </m>
  <m id="m714-d1t239-5">
   <w.rf>
    <LM>w#w-d1t239-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t239-7">
   <w.rf>
    <LM>w#w-d1t239-7</LM>
   </w.rf>
   <form>Berlína</form>
   <lemma>Berlín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d-id68376">
   <w.rf>
    <LM>w#w-d-id68376</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-70-918">
   <w.rf>
    <LM>w#w-70-918</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x24">
  <m id="m714-d1t248-1">
   <w.rf>
    <LM>w#w-d1t248-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t248-2">
   <w.rf>
    <LM>w#w-d1t248-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t248-3">
   <w.rf>
    <LM>w#w-d1t248-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d-id68481">
   <w.rf>
    <LM>w#w-d-id68481</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x25">
  <m id="m714-d1t252-3">
   <w.rf>
    <LM>w#w-d1t252-3</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d1e24-x25-4184">
   <w.rf>
    <LM>w#w-d1e24-x25-4184</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t252-4">
   <w.rf>
    <LM>w#w-d1t252-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t252-5">
   <w.rf>
    <LM>w#w-d1t252-5</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t252-6">
   <w.rf>
    <LM>w#w-d1t252-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t252-8">
   <w.rf>
    <LM>w#w-d1t252-8</LM>
   </w.rf>
   <form>putovaly</form>
   <lemma>putovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x25-83">
   <w.rf>
    <LM>w#w-d1e24-x25-83</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-84">
  <m id="m714-d1t252-11">
   <w.rf>
    <LM>w#w-d1t252-11</LM>
   </w.rf>
   <form>Přišly</form>
   <lemma>přijít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m714-d1t252-12">
   <w.rf>
    <LM>w#w-d1t252-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t252-13">
   <w.rf>
    <LM>w#w-d1t252-13</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t252-14">
   <w.rf>
    <LM>w#w-d1t252-14</LM>
   </w.rf>
   <form>nějakému</form>
   <lemma>nějaký</lemma>
   <tag>PZZS3----------</tag>
  </m>
  <m id="m714-d1t252-15">
   <w.rf>
    <LM>w#w-d1t252-15</LM>
   </w.rf>
   <form>nádražíčku</form>
   <lemma>nádražíčko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m714-d1e24-x25-4189">
   <w.rf>
    <LM>w#w-d1e24-x25-4189</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t256-3">
   <w.rf>
    <LM>w#w-d1t256-3</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t256-2">
   <w.rf>
    <LM>w#w-d1t256-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d1t256-4">
   <w.rf>
    <LM>w#w-d1t256-4</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d1t256-5">
   <w.rf>
    <LM>w#w-d1t256-5</LM>
   </w.rf>
   <form>poznamenané</form>
   <lemma>poznamenaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m714-84-85">
   <w.rf>
    <LM>w#w-84-85</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-86">
  <m id="m714-d1t259-3">
   <w.rf>
    <LM>w#w-d1t259-3</LM>
   </w.rf>
   <form>Čekalo</form>
   <lemma>čekat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t259-2">
   <w.rf>
    <LM>w#w-d1t259-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t259-4">
   <w.rf>
    <LM>w#w-d1t259-4</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t259-5">
   <w.rf>
    <LM>w#w-d1t259-5</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t259-6">
   <w.rf>
    <LM>w#w-d1t259-6</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m714-d1t259-9">
   <w.rf>
    <LM>w#w-d1t259-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t259-10">
   <w.rf>
    <LM>w#w-d1t259-10</LM>
   </w.rf>
   <form>čekalo</form>
   <lemma>čekat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t259-11">
   <w.rf>
    <LM>w#w-d1t259-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t261-2">
   <w.rf>
    <LM>w#w-d1t261-2</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m714-d1t261-1">
   <w.rf>
    <LM>w#w-d1t261-1</LM>
   </w.rf>
   <form>vojáků</form>
   <lemma>voják</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m714-d-id69224">
   <w.rf>
    <LM>w#w-d-id69224</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t261-5">
   <w.rf>
    <LM>w#w-d1t261-5</LM>
   </w.rf>
   <form>viděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t261-4">
   <w.rf>
    <LM>w#w-d1t261-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t261-7">
   <w.rf>
    <LM>w#w-d1t261-7</LM>
   </w.rf>
   <form>jakési</form>
   <lemma>jakýsi</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m714-d1t261-8">
   <w.rf>
    <LM>w#w-d1t261-8</LM>
   </w.rf>
   <form>uniformy</form>
   <lemma>uniforma</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m714-d-id69297">
   <w.rf>
    <LM>w#w-d-id69297</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x26">
  <m id="m714-d1t263-2">
   <w.rf>
    <LM>w#w-d1t263-2</LM>
   </w.rf>
   <form>Mluvili</form>
   <lemma>mluvit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t263-3">
   <w.rf>
    <LM>w#w-d1t263-3</LM>
   </w.rf>
   <form>česky</form>
   <lemma>česky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d-id69368">
   <w.rf>
    <LM>w#w-d-id69368</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x27">
  <m id="m714-d1t265-1">
   <w.rf>
    <LM>w#w-d1t265-1</LM>
   </w.rf>
   <form>Jenže</form>
   <lemma>jenže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t265-2">
   <w.rf>
    <LM>w#w-d1t265-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m714-d1t265-8">
   <w.rf>
    <LM>w#w-d1t265-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x27-4529">
   <w.rf>
    <LM>w#w-d1e24-x27-4529</LM>
   </w.rf>
   <form>uměla</form>
   <lemma>umět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t265-3">
   <w.rf>
    <LM>w#w-d1t265-3</LM>
   </w.rf>
   <form>česky</form>
   <lemma>česky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t265-4">
   <w.rf>
    <LM>w#w-d1t265-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t265-5">
   <w.rf>
    <LM>w#w-d1t265-5</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m714-d1t265-6">
   <w.rf>
    <LM>w#w-d1t265-6</LM>
   </w.rf>
   <form>slov</form>
   <lemma>slovo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m714-d1e24-x27-4530">
   <w.rf>
    <LM>w#w-d1e24-x27-4530</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t267-1">
   <w.rf>
    <LM>w#w-d1t267-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t267-2">
   <w.rf>
    <LM>w#w-d1t267-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t267-3">
   <w.rf>
    <LM>w#w-d1t267-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t267-4">
   <w.rf>
    <LM>w#w-d1t267-4</LM>
   </w.rf>
   <form>domluvili</form>
   <lemma>domluvit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x27-96">
   <w.rf>
    <LM>w#w-d1e24-x27-96</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x27-97">
   <w.rf>
    <LM>w#w-d1e24-x27-97</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x27-98">
   <w.rf>
    <LM>w#w-d1e24-x27-98</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-99">
  <m id="m714-d1t267-9">
   <w.rf>
    <LM>w#w-d1t267-9</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d1e24-x27-4403">
   <w.rf>
    <LM>w#w-d1e24-x27-4403</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t267-11">
   <w.rf>
    <LM>w#w-d1t267-11</LM>
   </w.rf>
   <form>odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t267-12">
   <w.rf>
    <LM>w#w-d1t267-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t267-13">
   <w.rf>
    <LM>w#w-d1t267-13</LM>
   </w.rf>
   <form>vraceli</form>
   <lemma>vracet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x27-4405">
   <w.rf>
    <LM>w#w-d1e24-x27-4405</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t267-14">
   <w.rf>
    <LM>w#w-d1t267-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t267-15">
   <w.rf>
    <LM>w#w-d1t267-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m714-d1t267-16">
   <w.rf>
    <LM>w#w-d1t267-16</LM>
   </w.rf>
   <form>nevzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-99-100">
   <w.rf>
    <LM>w#w-99-100</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-101">
  <m id="m714-101-102">
   <w.rf>
    <LM>w#w-101-102</LM>
   </w.rf>
   <form>Říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-101-104">
   <w.rf>
    <LM>w#w-101-104</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t269-2">
   <w.rf>
    <LM>w#w-d1t269-2</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t269-3">
   <w.rf>
    <LM>w#w-d1t269-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t269-4">
   <w.rf>
    <LM>w#w-d1t269-4</LM>
   </w.rf>
   <form>chtějí</form>
   <lemma>chtít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m714-d1t269-5">
   <w.rf>
    <LM>w#w-d1t269-5</LM>
   </w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d1t269-6">
   <w.rf>
    <LM>w#w-d1t269-6</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t272-1">
   <w.rf>
    <LM>w#w-d1t272-1</LM>
   </w.rf>
   <form>směrem</form>
   <lemma>směr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m714-d1t272-3">
   <w.rf>
    <LM>w#w-d1t272-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t272-4">
   <w.rf>
    <LM>w#w-d1t272-4</LM>
   </w.rf>
   <form>našim</form>
   <lemma>náš</lemma>
   <tag>PSXP3-P1-------</tag>
  </m>
  <m id="m714-d1t272-5">
   <w.rf>
    <LM>w#w-d1t272-5</LM>
   </w.rf>
   <form>hranicím</form>
   <lemma>hranice</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m714-d1e24-x27-4531">
   <w.rf>
    <LM>w#w-d1e24-x27-4531</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t272-7">
   <w.rf>
    <LM>w#w-d1t272-7</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t272-8">
   <w.rf>
    <LM>w#w-d1t272-8</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m714-d1t272-9">
   <w.rf>
    <LM>w#w-d1t272-9</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t272-10">
   <w.rf>
    <LM>w#w-d1t272-10</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t274-1">
   <w.rf>
    <LM>w#w-d1t274-1</LM>
   </w.rf>
   <form>dolů</form>
   <lemma>dolů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t274-3">
   <w.rf>
    <LM>w#w-d1t274-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t274-4">
   <w.rf>
    <LM>w#w-d1t274-4</LM>
   </w.rf>
   <form>jih</form>
   <lemma>jih</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x27-5058">
   <w.rf>
    <LM>w#w-d1e24-x27-5058</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t276-1">
   <w.rf>
    <LM>w#w-d1t276-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t276-2">
   <w.rf>
    <LM>w#w-d1t276-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t276-3">
   <w.rf>
    <LM>w#w-d1t276-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t276-4">
   <w.rf>
    <LM>w#w-d1t276-4</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t276-7">
   <w.rf>
    <LM>w#w-d1t276-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t276-8">
   <w.rf>
    <LM>w#w-d1t276-8</LM>
   </w.rf>
   <form>severu</form>
   <lemma>sever</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d-id70295">
   <w.rf>
    <LM>w#w-d-id70295</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x29">
  <m id="m714-d1e24-x29-5164">
   <w.rf>
    <LM>w#w-d1e24-x29-5164</LM>
   </w.rf>
   <form>Dostaly</form>
   <lemma>dostat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x29-5166">
   <w.rf>
    <LM>w#w-d1e24-x29-5166</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5165">
   <w.rf>
    <LM>w#w-d1e24-x29-5165</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1e24-x29-110">
   <w.rf>
    <LM>w#w-d1e24-x29-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-111">
   <w.rf>
    <LM>w#w-d1e24-x29-111</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-112">
   <w.rf>
    <LM>w#w-d1e24-x29-112</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-113">
  <m id="m714-d1e24-x29-5162">
   <w.rf>
    <LM>w#w-d1e24-x29-5162</LM>
   </w.rf>
   <form>Přijel</form>
   <lemma>přijet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x29-5161">
   <w.rf>
    <LM>w#w-d1e24-x29-5161</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m714-d1e24-x29-5160">
   <w.rf>
    <LM>w#w-d1e24-x29-5160</LM>
   </w.rf>
   <form>vojenský</form>
   <lemma>vojenský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-d1e24-x29-5159">
   <w.rf>
    <LM>w#w-d1e24-x29-5159</LM>
   </w.rf>
   <form>transport</form>
   <lemma>transport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x29-5158">
   <w.rf>
    <LM>w#w-d1e24-x29-5158</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5157">
   <w.rf>
    <LM>w#w-d1e24-x29-5157</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5156">
   <w.rf>
    <LM>w#w-d1e24-x29-5156</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5155">
   <w.rf>
    <LM>w#w-d1e24-x29-5155</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5154">
   <w.rf>
    <LM>w#w-d1e24-x29-5154</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1e24-x29-5153">
   <w.rf>
    <LM>w#w-d1e24-x29-5153</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m714-d1e24-x29-5152">
   <w.rf>
    <LM>w#w-d1e24-x29-5152</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5151">
   <w.rf>
    <LM>w#w-d1e24-x29-5151</LM>
   </w.rf>
   <form>jakási</form>
   <lemma>jakýsi</lemma>
   <tag>PZNP1----------</tag>
  </m>
  <m id="m714-d1e24-x29-5150">
   <w.rf>
    <LM>w#w-d1e24-x29-5150</LM>
   </w.rf>
   <form>děla</form>
   <lemma>dělo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m714-113-114">
   <w.rf>
    <LM>w#w-113-114</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-115">
  <m id="m714-d1e24-x29-5146">
   <w.rf>
    <LM>w#w-d1e24-x29-5146</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5258">
   <w.rf>
    <LM>w#w-d1e24-x29-5258</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5145">
   <w.rf>
    <LM>w#w-d1e24-x29-5145</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m714-d1e24-x29-5144">
   <w.rf>
    <LM>w#w-d1e24-x29-5144</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1e24-x29-5143">
   <w.rf>
    <LM>w#w-d1e24-x29-5143</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m714-d1e24-x29-5142">
   <w.rf>
    <LM>w#w-d1e24-x29-5142</LM>
   </w.rf>
   <form>vagónech</form>
   <lemma>vagón</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m714-d1e24-x29-5141">
   <w.rf>
    <LM>w#w-d1e24-x29-5141</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5140">
   <w.rf>
    <LM>w#w-d1e24-x29-5140</LM>
   </w.rf>
   <form>normálně</form>
   <lemma>normálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1e24-x29-5259">
   <w.rf>
    <LM>w#w-d1e24-x29-5259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-5260">
  <m id="m714-5260-124">
   <w.rf>
    <LM>w#w-5260-124</LM>
   </w.rf>
   <form>Nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m714-5260-126">
   <w.rf>
    <LM>w#w-5260-126</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5136">
   <w.rf>
    <LM>w#w-d1e24-x29-5136</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m714-d1e24-x29-5135">
   <w.rf>
    <LM>w#w-d1e24-x29-5135</LM>
   </w.rf>
   <form>chlapům</form>
   <lemma>chlap</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m714-5260-125">
   <w.rf>
    <LM>w#w-5260-125</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5131">
   <w.rf>
    <LM>w#w-d1e24-x29-5131</LM>
   </w.rf>
   <form>vzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x29-5132">
   <w.rf>
    <LM>w#w-d1e24-x29-5132</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m714-d1e24-x29-5126">
   <w.rf>
    <LM>w#w-d1e24-x29-5126</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m714-d1e24-x29-5125">
   <w.rf>
    <LM>w#w-d1e24-x29-5125</LM>
   </w.rf>
   <form>ženské</form>
   <lemma>ženská_^(osoba)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m714-d1e24-x29-5130">
   <w.rf>
    <LM>w#w-d1e24-x29-5130</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1e24-x29-5129">
   <w.rf>
    <LM>w#w-d1e24-x29-5129</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m714-5260-5268">
   <w.rf>
    <LM>w#w-5260-5268</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5122">
   <w.rf>
    <LM>w#w-d1e24-x29-5122</LM>
   </w.rf>
   <form>dovolili</form>
   <lemma>dovolit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x29-5121">
   <w.rf>
    <LM>w#w-d1e24-x29-5121</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1e24-x29-5120">
   <w.rf>
    <LM>w#w-d1e24-x29-5120</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m714-d1e24-x29-5119">
   <w.rf>
    <LM>w#w-d1e24-x29-5119</LM>
   </w.rf>
   <form>sednout</form>
   <lemma>sednout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d1e24-x29-5118">
   <w.rf>
    <LM>w#w-d1e24-x29-5118</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1e24-x29-5116">
   <w.rf>
    <LM>w#w-d1e24-x29-5116</LM>
   </w.rf>
   <form>vagóny</form>
   <lemma>vagón</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m714-d1e24-x29-5114">
   <w.rf>
    <LM>w#w-d1e24-x29-5114</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1e24-x29-5113">
   <w.rf>
    <LM>w#w-d1e24-x29-5113</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m714-d1e24-x29-5112">
   <w.rf>
    <LM>w#w-d1e24-x29-5112</LM>
   </w.rf>
   <form>dělům</form>
   <lemma>dělo</lemma>
   <tag>NNNP3-----A----</tag>
  </m>
  <m id="m714-5260-127">
   <w.rf>
    <LM>w#w-5260-127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-128">
  <m id="m714-d1e24-x29-5109">
   <w.rf>
    <LM>w#w-d1e24-x29-5109</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5108">
   <w.rf>
    <LM>w#w-d1e24-x29-5108</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5107">
   <w.rf>
    <LM>w#w-d1e24-x29-5107</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5106">
   <w.rf>
    <LM>w#w-d1e24-x29-5106</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5105">
   <w.rf>
    <LM>w#w-d1e24-x29-5105</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5102">
   <w.rf>
    <LM>w#w-d1e24-x29-5102</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZIP1----------</tag>
  </m>
  <m id="m714-d1e24-x29-5104">
   <w.rf>
    <LM>w#w-d1e24-x29-5104</LM>
   </w.rf>
   <form>tanky</form>
   <lemma>tank</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m714-d1e24-x29-5101">
   <w.rf>
    <LM>w#w-d1e24-x29-5101</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5100">
   <w.rf>
    <LM>w#w-d1e24-x29-5100</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m714-d1e24-x29-5103">
   <w.rf>
    <LM>w#w-d1e24-x29-5103</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5096">
   <w.rf>
    <LM>w#w-d1e24-x29-5096</LM>
   </w.rf>
   <form>samá</form>
   <lemma>samý</lemma>
   <tag>PLNP1----------</tag>
  </m>
  <m id="m714-d1e24-x29-5097">
   <w.rf>
    <LM>w#w-d1e24-x29-5097</LM>
   </w.rf>
   <form>děla</form>
   <lemma>dělo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m714-d1e24-x29-5094">
   <w.rf>
    <LM>w#w-d1e24-x29-5094</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1e24-x29-5093">
   <w.rf>
    <LM>w#w-d1e24-x29-5093</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5092">
   <w.rf>
    <LM>w#w-d1e24-x29-5092</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5091">
   <w.rf>
    <LM>w#w-d1e24-x29-5091</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZIP1----------</tag>
  </m>
  <m id="m714-d1e24-x29-5090">
   <w.rf>
    <LM>w#w-d1e24-x29-5090</LM>
   </w.rf>
   <form>dlouhé</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m714-d1e24-x29-5089">
   <w.rf>
    <LM>w#w-d1e24-x29-5089</LM>
   </w.rf>
   <form>laufy</form>
   <lemma>lauf_,h</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m714-128-129">
   <w.rf>
    <LM>w#w-128-129</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-130">
  <m id="m714-d1e24-x29-5082">
   <w.rf>
    <LM>w#w-d1e24-x29-5082</LM>
   </w.rf>
   <form>Seděly</form>
   <lemma>sedět</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5086">
   <w.rf>
    <LM>w#w-d1e24-x29-5086</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5084">
   <w.rf>
    <LM>w#w-d1e24-x29-5084</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1e24-x29-5083">
   <w.rf>
    <LM>w#w-d1e24-x29-5083</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m714-d1e24-x29-5081">
   <w.rf>
    <LM>w#w-d1e24-x29-5081</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5080">
   <w.rf>
    <LM>w#w-d1e24-x29-5080</LM>
   </w.rf>
   <form>dojely</form>
   <lemma>dojet</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x29-5079">
   <w.rf>
    <LM>w#w-d1e24-x29-5079</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5078">
   <w.rf>
    <LM>w#w-d1e24-x29-5078</LM>
   </w.rf>
   <form>kus</form>
   <lemma>kus</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-5260-5282">
   <w.rf>
    <LM>w#w-5260-5282</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5077">
   <w.rf>
    <LM>w#w-d1e24-x29-5077</LM>
   </w.rf>
   <form>jenže</form>
   <lemma>jenže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5076">
   <w.rf>
    <LM>w#w-d1e24-x29-5076</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5074">
   <w.rf>
    <LM>w#w-d1e24-x29-5074</LM>
   </w.rf>
   <form>trať</form>
   <lemma>trať</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x29-5073">
   <w.rf>
    <LM>w#w-d1e24-x29-5073</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5072">
   <w.rf>
    <LM>w#w-d1e24-x29-5072</LM>
   </w.rf>
   <form>jinam</form>
   <lemma>jinam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5071">
   <w.rf>
    <LM>w#w-d1e24-x29-5071</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5070">
   <w.rf>
    <LM>w#w-d1e24-x29-5070</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1e24-x29-5068">
   <w.rf>
    <LM>w#w-d1e24-x29-5068</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x29-5067">
   <w.rf>
    <LM>w#w-d1e24-x29-5067</LM>
   </w.rf>
   <form>potřebovaly</form>
   <lemma>potřebovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-130-131">
   <w.rf>
    <LM>w#w-130-131</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-132">
  <m id="m714-d1t300-3">
   <w.rf>
    <LM>w#w-d1t300-3</LM>
   </w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m714-d1t300-4">
   <w.rf>
    <LM>w#w-d1t300-4</LM>
   </w.rf>
   <form>chlapi</form>
   <lemma>chlap</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m714-d1t300-5">
   <w.rf>
    <LM>w#w-d1t300-5</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t300-6">
   <w.rf>
    <LM>w#w-d1t300-6</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-5260-2648">
   <w.rf>
    <LM>w#w-5260-2648</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t300-7">
   <w.rf>
    <LM>w#w-d1t300-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t300-9">
   <w.rf>
    <LM>w#w-d1t300-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t300-10">
   <w.rf>
    <LM>w#w-d1t300-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t300-11">
   <w.rf>
    <LM>w#w-d1t300-11</LM>
   </w.rf>
   <form>vylezly</form>
   <lemma>vylézt</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x29-5066">
   <w.rf>
    <LM>w#w-d1e24-x29-5066</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x30">
  <m id="m714-d1t304-2">
   <w.rf>
    <LM>w#w-d1t304-2</LM>
   </w.rf>
   <form>Zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t304-3">
   <w.rf>
    <LM>w#w-d1t304-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t304-4">
   <w.rf>
    <LM>w#w-d1t304-4</LM>
   </w.rf>
   <form>čekaly</form>
   <lemma>čekat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1t304-5">
   <w.rf>
    <LM>w#w-d1t304-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t304-6">
   <w.rf>
    <LM>w#w-d1t304-6</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t304-7">
   <w.rf>
    <LM>w#w-d1t304-7</LM>
   </w.rf>
   <form>zas</form>
   <lemma>zas-1_,s_^(^DD**zase-1)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t304-8">
   <w.rf>
    <LM>w#w-d1t304-8</LM>
   </w.rf>
   <form>přijel</form>
   <lemma>přijet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d1t304-9">
   <w.rf>
    <LM>w#w-d1t304-9</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m714-d1t304-12">
   <w.rf>
    <LM>w#w-d1t304-12</LM>
   </w.rf>
   <form>ruský</form>
   <lemma>ruský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-d1t304-10">
   <w.rf>
    <LM>w#w-d1t304-10</LM>
   </w.rf>
   <form>vojenský</form>
   <lemma>vojenský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-d1t304-11">
   <w.rf>
    <LM>w#w-d1t304-11</LM>
   </w.rf>
   <form>transport</form>
   <lemma>transport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-d-id72262">
   <w.rf>
    <LM>w#w-d-id72262</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x31">
  <m id="m714-d1t311-7">
   <w.rf>
    <LM>w#w-d1t311-7</LM>
   </w.rf>
   <form>Řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x31-2783">
   <w.rf>
    <LM>w#w-d1e24-x31-2783</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t311-9">
   <w.rf>
    <LM>w#w-d1t311-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t311-10">
   <w.rf>
    <LM>w#w-d1t311-10</LM>
   </w.rf>
   <form>můžeme</form>
   <lemma>moci</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t311-11">
   <w.rf>
    <LM>w#w-d1t311-11</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1e24-x31-2785">
   <w.rf>
    <LM>w#w-d1e24-x31-2785</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t311-12">
   <w.rf>
    <LM>w#w-d1t311-12</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m714-d-id72483">
   <w.rf>
    <LM>w#w-d-id72483</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t311-14">
   <w.rf>
    <LM>w#w-d1t311-14</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t311-15">
   <w.rf>
    <LM>w#w-d1t311-15</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m714-d1t311-16">
   <w.rf>
    <LM>w#w-d1t311-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t311-17">
   <w.rf>
    <LM>w#w-d1t311-17</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t311-18">
   <w.rf>
    <LM>w#w-d1t311-18</LM>
   </w.rf>
   <form>strach</form>
   <lemma>strach</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x31-2787">
   <w.rf>
    <LM>w#w-d1e24-x31-2787</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1t311-19">
   <w.rf>
    <LM>w#w-d1t311-19</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t311-21">
   <w.rf>
    <LM>w#w-d1t311-21</LM>
   </w.rf>
   <form>Rusy</form>
   <lemma>Rus-1_;E</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m714-d1e24-x31-150">
   <w.rf>
    <LM>w#w-d1e24-x31-150</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-151">
  <m id="m714-d1t313-1">
   <w.rf>
    <LM>w#w-d1t313-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t313-2">
   <w.rf>
    <LM>w#w-d1t313-2</LM>
   </w.rf>
   <form>nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t313-3">
   <w.rf>
    <LM>w#w-d1t313-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t313-4">
   <w.rf>
    <LM>w#w-d1t313-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t313-5">
   <w.rf>
    <LM>w#w-d1t313-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t313-6">
   <w.rf>
    <LM>w#w-d1t313-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t313-7">
   <w.rf>
    <LM>w#w-d1t313-7</LM>
   </w.rf>
   <form>otevřených</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m714-d1t313-8">
   <w.rf>
    <LM>w#w-d1t313-8</LM>
   </w.rf>
   <form>vagónech</form>
   <lemma>vagón</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m714-151-152">
   <w.rf>
    <LM>w#w-151-152</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-153">
  <m id="m714-d1t315-1">
   <w.rf>
    <LM>w#w-d1t315-1</LM>
   </w.rf>
   <form>Nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t315-2">
   <w.rf>
    <LM>w#w-d1t315-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t315-3">
   <w.rf>
    <LM>w#w-d1t315-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t315-4">
   <w.rf>
    <LM>w#w-d1t315-4</LM>
   </w.rf>
   <form>jela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t315-5">
   <w.rf>
    <LM>w#w-d1t315-5</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m714-d1e24-x31-2793">
   <w.rf>
    <LM>w#w-d1e24-x31-2793</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t315-6">
   <w.rf>
    <LM>w#w-d1t315-6</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m714-d1t315-7">
   <w.rf>
    <LM>w#w-d1t315-7</LM>
   </w.rf>
   <form>Slovenka</form>
   <lemma>Slovenka_;E</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1t315-8">
   <w.rf>
    <LM>w#w-d1t315-8</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d-id72882">
   <w.rf>
    <LM>w#w-d-id72882</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t315-11">
   <w.rf>
    <LM>w#w-d1t315-11</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m714-d1t315-13">
   <w.rf>
    <LM>w#w-d1t315-13</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t315-14">
   <w.rf>
    <LM>w#w-d1t315-14</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t315-15">
   <w.rf>
    <LM>w#w-d1t315-15</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m714-d-id72969">
   <w.rf>
    <LM>w#w-d-id72969</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t317-2">
   <w.rf>
    <LM>w#w-d1t317-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t317-3">
   <w.rf>
    <LM>w#w-d1t317-3</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m714-d1t317-4">
   <w.rf>
    <LM>w#w-d1t317-4</LM>
   </w.rf>
   <form>Němkou</form>
   <lemma>Němka_;E</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m714-153-154">
   <w.rf>
    <LM>w#w-153-154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-155">
  <m id="m714-d1t321-8">
   <w.rf>
    <LM>w#w-d1t321-8</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t321-2">
   <w.rf>
    <LM>w#w-d1t321-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m714-d1t321-3">
   <w.rf>
    <LM>w#w-d1t321-3</LM>
   </w.rf>
   <form>nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d1t321-4">
   <w.rf>
    <LM>w#w-d1t321-4</LM>
   </w.rf>
   <form>vzpomenout</form>
   <lemma>vzpomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d1e24-x32-3074">
   <w.rf>
    <LM>w#w-d1e24-x32-3074</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t321-5">
   <w.rf>
    <LM>w#w-d1t321-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t321-6">
   <w.rf>
    <LM>w#w-d1t321-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t321-7">
   <w.rf>
    <LM>w#w-d1t321-7</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m714-d-id73049">
   <w.rf>
    <LM>w#w-d-id73049</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x32">
  <m id="m714-d1t324-2">
   <w.rf>
    <LM>w#w-d1t324-2</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t324-3">
   <w.rf>
    <LM>w#w-d1t324-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t324-4">
   <w.rf>
    <LM>w#w-d1t324-4</LM>
   </w.rf>
   <form>jely</form>
   <lemma>jet-1</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1t324-5">
   <w.rf>
    <LM>w#w-d1t324-5</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t324-6">
   <w.rf>
    <LM>w#w-d1t324-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t324-7">
   <w.rf>
    <LM>w#w-d1t324-7</LM>
   </w.rf>
   <form>Fürstenbergu</form>
   <lemma>Fürstenberg-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d-id73310">
   <w.rf>
    <LM>w#w-d-id73310</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t326-1">
   <w.rf>
    <LM>w#w-d1t326-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t326-2">
   <w.rf>
    <LM>w#w-d1t326-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t326-3">
   <w.rf>
    <LM>w#w-d1t326-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t326-4">
   <w.rf>
    <LM>w#w-d1t326-4</LM>
   </w.rf>
   <form>Neusterlitzu</form>
   <lemma>Neusterlitz_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d1t326-5">
   <w.rf>
    <LM>w#w-d1t326-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t326-6">
   <w.rf>
    <LM>w#w-d1t326-6</LM>
   </w.rf>
   <form>Fürstenbergu</form>
   <lemma>Fürstenberg-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d1e24-x32-171">
   <w.rf>
    <LM>w#w-d1e24-x32-171</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-173">
  <m id="m714-d1t328-1">
   <w.rf>
    <LM>w#w-d1t328-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t328-2">
   <w.rf>
    <LM>w#w-d1t328-2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m714-d1t328-3">
   <w.rf>
    <LM>w#w-d1t328-3</LM>
   </w.rf>
   <form>vysadili</form>
   <lemma>vysadit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-173-174">
   <w.rf>
    <LM>w#w-173-174</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t328-7">
   <w.rf>
    <LM>w#w-d1t328-7</LM>
   </w.rf>
   <form>řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t328-6">
   <w.rf>
    <LM>w#w-d1t328-6</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m714-d-id73538">
   <w.rf>
    <LM>w#w-d-id73538</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t328-9">
   <w.rf>
    <LM>w#w-d1t328-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t328-10">
   <w.rf>
    <LM>w#w-d1t328-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t328-11">
   <w.rf>
    <LM>w#w-d1t328-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1t328-12">
   <w.rf>
    <LM>w#w-d1t328-12</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS1----------</tag>
  </m>
  <m id="m714-d1t328-13">
   <w.rf>
    <LM>w#w-d1t328-13</LM>
   </w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m714-173-175">
   <w.rf>
    <LM>w#w-173-175</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-176">
  <m id="m714-d1t328-17">
   <w.rf>
    <LM>w#w-d1t328-17</LM>
   </w.rf>
   <form>Přijíždí</form>
   <lemma>přijíždět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1t328-16">
   <w.rf>
    <LM>w#w-d1t328-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t328-19">
   <w.rf>
    <LM>w#w-d1t328-19</LM>
   </w.rf>
   <form>styčný</form>
   <lemma>styčný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m714-d1t328-20">
   <w.rf>
    <LM>w#w-d1t328-20</LM>
   </w.rf>
   <form>důstojník</form>
   <lemma>důstojník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1t328-21">
   <w.rf>
    <LM>w#w-d1t328-21</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t328-22">
   <w.rf>
    <LM>w#w-d1t328-22</LM>
   </w.rf>
   <form>Československa</form>
   <lemma>Československo_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m714-176-177">
   <w.rf>
    <LM>w#w-176-177</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t328-28">
   <w.rf>
    <LM>w#w-d1t328-28</LM>
   </w.rf>
   <form>repatriuje</form>
   <lemma>repatriovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m714-d1t328-27">
   <w.rf>
    <LM>w#w-d1t328-27</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t328-26">
   <w.rf>
    <LM>w#w-d1t328-26</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t328-29">
   <w.rf>
    <LM>w#w-d1t328-29</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t328-32">
   <w.rf>
    <LM>w#w-d1t328-32</LM>
   </w.rf>
   <form>přijíždějí</form>
   <lemma>přijíždět</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m714-d1t328-31">
   <w.rf>
    <LM>w#w-d1t328-31</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t328-33">
   <w.rf>
    <LM>w#w-d1t328-33</LM>
   </w.rf>
   <form>autobusy</form>
   <lemma>autobus</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m714-d1e24-x32-3084">
   <w.rf>
    <LM>w#w-d1e24-x32-3084</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-3085">
  <m id="m714-d1t328-37">
   <w.rf>
    <LM>w#w-d1t328-37</LM>
   </w.rf>
   <form>Nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m714-d1t328-38">
   <w.rf>
    <LM>w#w-d1t328-38</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t328-39">
   <w.rf>
    <LM>w#w-d1t328-39</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t328-40">
   <w.rf>
    <LM>w#w-d1t328-40</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t328-41">
   <w.rf>
    <LM>w#w-d1t328-41</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1t330-1">
   <w.rf>
    <LM>w#w-d1t330-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t330-2">
   <w.rf>
    <LM>w#w-d1t330-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m714-d1t330-3">
   <w.rf>
    <LM>w#w-d1t330-3</LM>
   </w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d-id74066">
   <w.rf>
    <LM>w#w-d-id74066</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t330-6">
   <w.rf>
    <LM>w#w-d1t330-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t330-7">
   <w.rf>
    <LM>w#w-d1t330-7</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d-id74121">
   <w.rf>
    <LM>w#w-d-id74121</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-3085-183">
   <w.rf>
    <LM>w#w-3085-183</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-3085-182">
   <w.rf>
    <LM>w#w-3085-182</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-3085-3103">
   <w.rf>
    <LM>w#w-3085-3103</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m714-d1t332-1">
   <w.rf>
    <LM>w#w-d1t332-1</LM>
   </w.rf>
   <form>poschoďová</form>
   <lemma>poschoďový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m714-3085-3105">
   <w.rf>
    <LM>w#w-3085-3105</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t332-3">
   <w.rf>
    <LM>w#w-d1t332-3</LM>
   </w.rf>
   <form>úzká</form>
   <lemma>úzký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m714-d1t332-5">
   <w.rf>
    <LM>w#w-d1t332-5</LM>
   </w.rf>
   <form>budova</form>
   <lemma>budova</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-3085-184">
   <w.rf>
    <LM>w#w-3085-184</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-185">
  <m id="m714-d1t334-2">
   <w.rf>
    <LM>w#w-d1t334-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t334-4">
   <w.rf>
    <LM>w#w-d1t334-4</LM>
   </w.rf>
   <form>přijely</form>
   <lemma>přijet</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m714-d1t334-5">
   <w.rf>
    <LM>w#w-d1t334-5</LM>
   </w.rf>
   <form>autobusy</form>
   <lemma>autobus</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m714-d1t337-1">
   <w.rf>
    <LM>w#w-d1t337-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t337-2">
   <w.rf>
    <LM>w#w-d1t337-2</LM>
   </w.rf>
   <form>jely</form>
   <lemma>jet-1</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1t337-3">
   <w.rf>
    <LM>w#w-d1t337-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-3085-3107">
   <w.rf>
    <LM>w#w-3085-3107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-3108">
  <m id="m714-d1t337-5">
   <w.rf>
    <LM>w#w-d1t337-5</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t337-6">
   <w.rf>
    <LM>w#w-d1t337-6</LM>
   </w.rf>
   <form>našich</form>
   <lemma>náš</lemma>
   <tag>PSXP6-P1-------</tag>
  </m>
  <m id="m714-d1t337-7">
   <w.rf>
    <LM>w#w-d1t337-7</LM>
   </w.rf>
   <form>hranicích</form>
   <lemma>hranice</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m714-3108-3449">
   <w.rf>
    <LM>w#w-3108-3449</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-3108-3450">
   <w.rf>
    <LM>w#w-3108-3450</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-3108-3451">
   <w.rf>
    <LM>w#w-3108-3451</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-3452">
  <m id="m714-d1t337-9">
   <w.rf>
    <LM>w#w-d1t337-9</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t337-10">
   <w.rf>
    <LM>w#w-d1t337-10</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m714-d1t337-11">
   <w.rf>
    <LM>w#w-d1t337-11</LM>
   </w.rf>
   <form>nezapomněla</form>
   <lemma>zapomenout</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m714-3452-191">
   <w.rf>
    <LM>w#w-3452-191</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-193">
  <m id="m714-d1t341-5">
   <w.rf>
    <LM>w#w-d1t341-5</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t341-4">
   <w.rf>
    <LM>w#w-d1t341-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t341-8">
   <w.rf>
    <LM>w#w-d1t341-8</LM>
   </w.rf>
   <form>vysoko</form>
   <lemma>vysoko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d-id74698">
   <w.rf>
    <LM>w#w-d-id74698</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t341-11">
   <w.rf>
    <LM>w#w-d1t341-11</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d-id74731">
   <w.rf>
    <LM>w#w-d-id74731</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t341-13">
   <w.rf>
    <LM>w#w-d1t341-13</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t341-15">
   <w.rf>
    <LM>w#w-d1t341-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t341-16">
   <w.rf>
    <LM>w#w-d1t341-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-193-194">
   <w.rf>
    <LM>w#w-193-194</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t341-17">
   <w.rf>
    <LM>w#w-d1t341-17</LM>
   </w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-193-195">
   <w.rf>
    <LM>w#w-193-195</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-196">
  <m id="m714-d1t341-20">
   <w.rf>
    <LM>w#w-d1t341-20</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t341-19">
   <w.rf>
    <LM>w#w-d1t341-19</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t341-21">
   <w.rf>
    <LM>w#w-d1t341-21</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t341-22">
   <w.rf>
    <LM>w#w-d1t341-22</LM>
   </w.rf>
   <form>Berlín</form>
   <lemma>Berlín_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-196-197">
   <w.rf>
    <LM>w#w-196-197</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-198">
  <m id="m714-d1t341-24">
   <w.rf>
    <LM>w#w-d1t341-24</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d-id74913">
   <w.rf>
    <LM>w#w-d-id74913</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t341-26">
   <w.rf>
    <LM>w#w-d1t341-26</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t341-27">
   <w.rf>
    <LM>w#w-d1t341-27</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t341-28">
   <w.rf>
    <LM>w#w-d1t341-28</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m714-d1t345-1">
   <w.rf>
    <LM>w#w-d1t345-1</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t341-29">
   <w.rf>
    <LM>w#w-d1t341-29</LM>
   </w.rf>
   <form>vysadili</form>
   <lemma>vysadit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d-id75010">
   <w.rf>
    <LM>w#w-d-id75010</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x34">
  <m id="m714-d1t347-3">
   <w.rf>
    <LM>w#w-d1t347-3</LM>
   </w.rf>
   <form>Musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t347-1">
   <w.rf>
    <LM>w#w-d1t347-1</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m714-d1t347-2">
   <w.rf>
    <LM>w#w-d1t347-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t347-4">
   <w.rf>
    <LM>w#w-d1t347-4</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d1t347-5">
   <w.rf>
    <LM>w#w-d1t347-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t347-6">
   <w.rf>
    <LM>w#w-d1t347-6</LM>
   </w.rf>
   <form>mapě</form>
   <lemma>mapa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d-id75120">
   <w.rf>
    <LM>w#w-d-id75120</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x35">
  <m id="m714-d1t350-2">
   <w.rf>
    <LM>w#w-d1t350-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t350-4">
   <w.rf>
    <LM>w#w-d1t350-4</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t350-3">
   <w.rf>
    <LM>w#w-d1t350-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d-id75206">
   <w.rf>
    <LM>w#w-d-id75206</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t350-6">
   <w.rf>
    <LM>w#w-d1t350-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t350-7">
   <w.rf>
    <LM>w#w-d1t350-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t350-8">
   <w.rf>
    <LM>w#w-d1t350-8</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t350-9">
   <w.rf>
    <LM>w#w-d1t350-9</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t350-10">
   <w.rf>
    <LM>w#w-d1t350-10</LM>
   </w.rf>
   <form>Drážďany</form>
   <lemma>Drážďany_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m714-d1e24-x35-208">
   <w.rf>
    <LM>w#w-d1e24-x35-208</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-209">
  <m id="m714-d1t350-14">
   <w.rf>
    <LM>w#w-d1t350-14</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t350-13">
   <w.rf>
    <LM>w#w-d1t350-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t350-15">
   <w.rf>
    <LM>w#w-d1t350-15</LM>
   </w.rf>
   <form>zhrozená</form>
   <lemma>zhrozený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m714-d-id75350">
   <w.rf>
    <LM>w#w-d-id75350</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t350-17">
   <w.rf>
    <LM>w#w-d1t350-17</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t350-19">
   <w.rf>
    <LM>w#w-d1t350-19</LM>
   </w.rf>
   <form>Drážďany</form>
   <lemma>Drážďany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m714-d1t350-20">
   <w.rf>
    <LM>w#w-d1t350-20</LM>
   </w.rf>
   <form>vypadaly</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d-id75420">
   <w.rf>
    <LM>w#w-d-id75420</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t350-22">
   <w.rf>
    <LM>w#w-d1t350-22</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t350-23">
   <w.rf>
    <LM>w#w-d1t350-23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t350-24">
   <w.rf>
    <LM>w#w-d1t350-24</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t350-26">
   <w.rf>
    <LM>w#w-d1t350-26</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m714-d1t350-25">
   <w.rf>
    <LM>w#w-d1t350-25</LM>
   </w.rf>
   <form>rozbombardované</form>
   <lemma>rozbombardovaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m714-209-210">
   <w.rf>
    <LM>w#w-209-210</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-211">
  <m id="m714-d1t350-29">
   <w.rf>
    <LM>w#w-d1t350-29</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t350-30">
   <w.rf>
    <LM>w#w-d1t350-30</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t350-31">
   <w.rf>
    <LM>w#w-d1t350-31</LM>
   </w.rf>
   <form>přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t350-32">
   <w.rf>
    <LM>w#w-d1t350-32</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t350-33">
   <w.rf>
    <LM>w#w-d1t350-33</LM>
   </w.rf>
   <form>našim</form>
   <lemma>náš</lemma>
   <tag>PSXP3-P1-------</tag>
  </m>
  <m id="m714-d1t350-34">
   <w.rf>
    <LM>w#w-d1t350-34</LM>
   </w.rf>
   <form>hranicím</form>
   <lemma>hranice</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m714-d1e24-x35-3768">
   <w.rf>
    <LM>w#w-d1e24-x35-3768</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t352-1">
   <w.rf>
    <LM>w#w-d1t352-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t352-2">
   <w.rf>
    <LM>w#w-d1t352-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t352-3">
   <w.rf>
    <LM>w#w-d1t352-3</LM>
   </w.rf>
   <form>zastavili</form>
   <lemma>zastavit_^(uvést_do_klidu;;zástavní_právo)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-211-212">
   <w.rf>
    <LM>w#w-211-212</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-213">
  <m id="m714-d1t354-4">
   <w.rf>
    <LM>w#w-d1t354-4</LM>
   </w.rf>
   <form>Hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t354-5">
   <w.rf>
    <LM>w#w-d1t354-5</LM>
   </w.rf>
   <form>hymnu</form>
   <lemma>hymna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t354-6">
   <w.rf>
    <LM>w#w-d1t354-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t354-7">
   <w.rf>
    <LM>w#w-d1t354-7</LM>
   </w.rf>
   <form>slzy</form>
   <lemma>slza</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m714-d1t354-8">
   <w.rf>
    <LM>w#w-d1t354-8</LM>
   </w.rf>
   <form>tekly</form>
   <lemma>téci</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x35-4869">
   <w.rf>
    <LM>w#w-d1e24-x35-4869</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t354-9">
   <w.rf>
    <LM>w#w-d1t354-9</LM>
   </w.rf>
   <form>pochopitelně</form>
   <lemma>pochopitelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1e24-x35-3773">
   <w.rf>
    <LM>w#w-d1e24-x35-3773</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t358-2">
   <w.rf>
    <LM>w#w-d1t358-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t358-3">
   <w.rf>
    <LM>w#w-d1t358-3</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t358-4">
   <w.rf>
    <LM>w#w-d1t358-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t358-5">
   <w.rf>
    <LM>w#w-d1t358-5</LM>
   </w.rf>
   <form>přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t358-6">
   <w.rf>
    <LM>w#w-d1t358-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t358-7">
   <w.rf>
    <LM>w#w-d1t358-7</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m714-d1e24-x35-3774">
   <w.rf>
    <LM>w#w-d1e24-x35-3774</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-3775">
  <m id="m714-d1t360-3">
   <w.rf>
    <LM>w#w-d1t360-3</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t360-2">
   <w.rf>
    <LM>w#w-d1t360-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m714-d1t360-4">
   <w.rf>
    <LM>w#w-d1t360-4</LM>
   </w.rf>
   <form>nevzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-3775-4947">
   <w.rf>
    <LM>w#w-3775-4947</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-3775-219">
   <w.rf>
    <LM>w#w-3775-219</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-3775-220">
   <w.rf>
    <LM>w#w-3775-220</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-3775-221">
   <w.rf>
    <LM>w#w-3775-221</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t360-5">
   <w.rf>
    <LM>w#w-d1t360-5</LM>
   </w.rf>
   <form>Legerova</form>
   <lemma>Legerův-1_;Y_^(*4-1)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m714-d1t360-6">
   <w.rf>
    <LM>w#w-d1t360-6</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t360-7">
   <w.rf>
    <LM>w#w-d1t360-7</LM>
   </w.rf>
   <form>kdesi</form>
   <lemma>kdesi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t360-9">
   <w.rf>
    <LM>w#w-d1t360-9</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t360-10">
   <w.rf>
    <LM>w#w-d1t360-10</LM>
   </w.rf>
   <form>Vinohrady</form>
   <lemma>Vinohrady_;G</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m714-3775-4026">
   <w.rf>
    <LM>w#w-3775-4026</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t367-2">
   <w.rf>
    <LM>w#w-d1t367-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t367-1">
   <w.rf>
    <LM>w#w-d1t367-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t367-3">
   <w.rf>
    <LM>w#w-d1t367-3</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS1----------</tag>
  </m>
  <m id="m714-d1t367-4">
   <w.rf>
    <LM>w#w-d1t367-4</LM>
   </w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m714-d1t367-5">
   <w.rf>
    <LM>w#w-d1t367-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t367-6">
   <w.rf>
    <LM>w#w-d1t367-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m714-3775-222">
   <w.rf>
    <LM>w#w-3775-222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-223">
  <m id="m714-d1t367-7">
   <w.rf>
    <LM>w#w-d1t367-7</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t367-8">
   <w.rf>
    <LM>w#w-d1t367-8</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m714-d1t367-9">
   <w.rf>
    <LM>w#w-d1t367-9</LM>
   </w.rf>
   <form>vysadili</form>
   <lemma>vysadit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-3775-4030">
   <w.rf>
    <LM>w#w-3775-4030</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t367-10">
   <w.rf>
    <LM>w#w-d1t367-10</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t367-11">
   <w.rf>
    <LM>w#w-d1t367-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-3775-576">
   <w.rf>
    <LM>w#w-3775-576</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t367-14">
   <w.rf>
    <LM>w#w-d1t367-14</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-223-224">
   <w.rf>
    <LM>w#w-223-224</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t367-16">
   <w.rf>
    <LM>w#w-d1t367-16</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t367-17">
   <w.rf>
    <LM>w#w-d1t367-17</LM>
   </w.rf>
   <form>padesát</form>
   <lemma>padesát`50</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m714-d1t367-18">
   <w.rf>
    <LM>w#w-d1t367-18</LM>
   </w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m714-d1t367-19">
   <w.rf>
    <LM>w#w-d1t367-19</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t367-20">
   <w.rf>
    <LM>w#w-d1t367-20</LM>
   </w.rf>
   <form>500</form>
   <lemma>500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m714-d1t367-22">
   <w.rf>
    <LM>w#w-d1t367-22</LM>
   </w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m714-d1t369-1">
   <w.rf>
    <LM>w#w-d1t369-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t369-2">
   <w.rf>
    <LM>w#w-d1t369-2</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m714-d1t369-3">
   <w.rf>
    <LM>w#w-d1t369-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t369-4">
   <w.rf>
    <LM>w#w-d1t369-4</LM>
   </w.rf>
   <form>skončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m714-d-id76598">
   <w.rf>
    <LM>w#w-d-id76598</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x37">
  <m id="m714-d1t373-2">
   <w.rf>
    <LM>w#w-d1t373-2</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t373-1">
   <w.rf>
    <LM>w#w-d1t373-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t373-3">
   <w.rf>
    <LM>w#w-d1t373-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t373-4">
   <w.rf>
    <LM>w#w-d1t373-4</LM>
   </w.rf>
   <form>rodiči</form>
   <lemma>rodič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m714-d1t373-5">
   <w.rf>
    <LM>w#w-d1t373-5</LM>
   </w.rf>
   <form>domluveni</form>
   <lemma>domluvit</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m714-d-id76769">
   <w.rf>
    <LM>w#w-d-id76769</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x37-4351">
   <w.rf>
    <LM>w#w-d1e24-x37-4351</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t373-9">
   <w.rf>
    <LM>w#w-d1t373-9</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t373-10">
   <w.rf>
    <LM>w#w-d1t373-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t373-11">
   <w.rf>
    <LM>w#w-d1t373-11</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m714-d1t373-12">
   <w.rf>
    <LM>w#w-d1t373-12</LM>
   </w.rf>
   <form>vrátí</form>
   <lemma>vrátit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m714-d-id76871">
   <w.rf>
    <LM>w#w-d-id76871</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t373-14">
   <w.rf>
    <LM>w#w-d1t373-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t373-15">
   <w.rf>
    <LM>w#w-d1t373-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t373-16">
   <w.rf>
    <LM>w#w-d1t373-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t373-17">
   <w.rf>
    <LM>w#w-d1t373-17</LM>
   </w.rf>
   <form>sejdeme</form>
   <lemma>sejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m714-d1t373-19">
   <w.rf>
    <LM>w#w-d1t373-19</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t376-1">
   <w.rf>
    <LM>w#w-d1t376-1</LM>
   </w.rf>
   <form>jedněch</form>
   <lemma>jedny`1</lemma>
   <tag>CdXP2----------</tag>
  </m>
  <m id="m714-d1t376-2">
   <w.rf>
    <LM>w#w-d1t376-2</LM>
   </w.rf>
   <form>známých</form>
   <lemma>známý-1_^(potkat_známého_[člověka])</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m714-d1t376-3">
   <w.rf>
    <LM>w#w-d1t376-3</LM>
   </w.rf>
   <form>rodičů</form>
   <lemma>rodič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m714-d1e24-x37-4198">
   <w.rf>
    <LM>w#w-d1e24-x37-4198</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t376-4">
   <w.rf>
    <LM>w#w-d1t376-4</LM>
   </w.rf>
   <form>nějací</form>
   <lemma>nějaký</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m714-d1t376-5">
   <w.rf>
    <LM>w#w-d1t376-5</LM>
   </w.rf>
   <form>Netlovi</form>
   <lemma>Netlův_;Y_^(*2)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m714-d1e24-x37-230">
   <w.rf>
    <LM>w#w-d1e24-x37-230</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-231">
  <m id="m714-d1t378-2">
   <w.rf>
    <LM>w#w-d1t378-2</LM>
   </w.rf>
   <form>Ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m714-d1t378-3">
   <w.rf>
    <LM>w#w-d1t378-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t378-4">
   <w.rf>
    <LM>w#w-d1t378-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t378-7">
   <w.rf>
    <LM>w#w-d1t378-7</LM>
   </w.rf>
   <form>Árijka</form>
   <lemma>árijka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1t378-8">
   <w.rf>
    <LM>w#w-d1t378-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t378-9">
   <w.rf>
    <LM>w#w-d1t378-9</LM>
   </w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t378-11">
   <w.rf>
    <LM>w#w-d1t378-11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t378-12">
   <w.rf>
    <LM>w#w-d1t378-12</LM>
   </w.rf>
   <form>Holanďanka</form>
   <lemma>Holanďanka_;E_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d-id77257">
   <w.rf>
    <LM>w#w-d-id77257</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x38">
  <m id="m714-d1t382-3">
   <w.rf>
    <LM>w#w-d1t382-3</LM>
   </w.rf>
   <form>Řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t382-2">
   <w.rf>
    <LM>w#w-d1t382-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x38-4344">
   <w.rf>
    <LM>w#w-d1e24-x38-4344</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m714-d-id77336">
   <w.rf>
    <LM>w#w-d-id77336</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t382-5">
   <w.rf>
    <LM>w#w-d1t382-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t382-7">
   <w.rf>
    <LM>w#w-d1t382-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t382-8">
   <w.rf>
    <LM>w#w-d1t382-8</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m714-d1t382-6">
   <w.rf>
    <LM>w#w-d1t382-6</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t382-9">
   <w.rf>
    <LM>w#w-d1t382-9</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m714-d1t382-10">
   <w.rf>
    <LM>w#w-d1t382-10</LM>
   </w.rf>
   <form>nestane</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m714-d1e24-x38-239">
   <w.rf>
    <LM>w#w-d1e24-x38-239</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-240">
  <m id="m714-d1e24-x38-4352">
   <w.rf>
    <LM>w#w-d1e24-x38-4352</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t382-13">
   <w.rf>
    <LM>w#w-d1t382-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t382-15">
   <w.rf>
    <LM>w#w-d1t382-15</LM>
   </w.rf>
   <form>domluveni</form>
   <lemma>domluvit</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m714-d-id77508">
   <w.rf>
    <LM>w#w-d-id77508</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x38-4350">
   <w.rf>
    <LM>w#w-d1e24-x38-4350</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t382-17">
   <w.rf>
    <LM>w#w-d1t382-17</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t382-18">
   <w.rf>
    <LM>w#w-d1t382-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t382-19">
   <w.rf>
    <LM>w#w-d1t382-19</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m714-d1t382-20">
   <w.rf>
    <LM>w#w-d1t382-20</LM>
   </w.rf>
   <form>vrátí</form>
   <lemma>vrátit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m714-d-id77579">
   <w.rf>
    <LM>w#w-d-id77579</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t382-22">
   <w.rf>
    <LM>w#w-d1t382-22</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t382-23">
   <w.rf>
    <LM>w#w-d1t382-23</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t382-24">
   <w.rf>
    <LM>w#w-d1t382-24</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t382-25">
   <w.rf>
    <LM>w#w-d1t382-25</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t382-26">
   <w.rf>
    <LM>w#w-d1t382-26</LM>
   </w.rf>
   <form>sejdeme</form>
   <lemma>sejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m714-240-241">
   <w.rf>
    <LM>w#w-240-241</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-242">
  <m id="m714-d1t382-29">
   <w.rf>
    <LM>w#w-d1t382-29</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t382-28">
   <w.rf>
    <LM>w#w-d1t382-28</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t382-30">
   <w.rf>
    <LM>w#w-d1t382-30</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t382-31">
   <w.rf>
    <LM>w#w-d1t382-31</LM>
   </w.rf>
   <form>Národní</form>
   <lemma>národní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m714-d1t382-32">
   <w.rf>
    <LM>w#w-d1t382-32</LM>
   </w.rf>
   <form>třídě</form>
   <lemma>třída</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d1t382-33">
   <w.rf>
    <LM>w#w-d1t382-33</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t382-34">
   <w.rf>
    <LM>w#w-d1t382-34</LM>
   </w.rf>
   <form>Platýzu</form>
   <lemma>Platýz_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d-id77768">
   <w.rf>
    <LM>w#w-d-id77768</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x39">
  <m id="m714-d1t389-5">
   <w.rf>
    <LM>w#w-d1t389-5</LM>
   </w.rf>
   <form>Šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t389-3">
   <w.rf>
    <LM>w#w-d1t389-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t389-4">
   <w.rf>
    <LM>w#w-d1t389-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d-id77881">
   <w.rf>
    <LM>w#w-d-id77881</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t389-7">
   <w.rf>
    <LM>w#w-d1t389-7</LM>
   </w.rf>
   <form>zazvonila</form>
   <lemma>zazvonit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t393-1">
   <w.rf>
    <LM>w#w-d1t393-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t393-2">
   <w.rf>
    <LM>w#w-d1t393-2</LM>
   </w.rf>
   <form>otevřela</form>
   <lemma>otevřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t393-3">
   <w.rf>
    <LM>w#w-d1t393-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m714-d1t393-4">
   <w.rf>
    <LM>w#w-d1t393-4</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m714-d1t393-5">
   <w.rf>
    <LM>w#w-d1t393-5</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x39-248">
   <w.rf>
    <LM>w#w-d1e24-x39-248</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
