<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_773.00.w.gz" />
  </references>
 </head>
 <s id="m773-26127_03-d1e7-x2">
  <m id="m773-d1e7-x2-17">
   <w.rf>
    <LM>w#w-d1e7-x2-17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1e7-x2-18">
   <w.rf>
    <LM>w#w-d1e7-x2-18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1e7-x2-19">
   <w.rf>
    <LM>w#w-d1e7-x2-19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t16-1">
   <w.rf>
    <LM>w#w-d1t16-1</LM>
   </w.rf>
   <form>97</form>
   <lemma>97</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m773-d1e7-x2-26">
   <w.rf>
    <LM>w#w-d1e7-x2-26</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t18-2">
   <w.rf>
    <LM>w#w-d1t18-2</LM>
   </w.rf>
   <form>rozhovor</form>
   <lemma>rozhovor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m773-d1t18-3">
   <w.rf>
    <LM>w#w-d1t18-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t18-4">
   <w.rf>
    <LM>w#w-d1t18-4</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m773-d1t21-1">
   <w.rf>
    <LM>w#w-d1t21-1</LM>
   </w.rf>
   <form>Alicí</form>
   <lemma>Alice_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m773-d1t21-2">
   <w.rf>
    <LM>w#w-d1t21-2</LM>
   </w.rf>
   <form>Hrbkovou</form>
   <lemma>Hrbková_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m773-d1e7-x2-27">
   <w.rf>
    <LM>w#w-d1e7-x2-27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t25-1">
   <w.rf>
    <LM>w#w-d1t25-1</LM>
   </w.rf>
   <form>moderátor</form>
   <lemma>moderátor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d1t25-2">
   <w.rf>
    <LM>w#w-d1t25-2</LM>
   </w.rf>
   <form>Jelínek</form>
   <lemma>Jelínek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d1e7-x2-28">
   <w.rf>
    <LM>w#w-d1e7-x2-28</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t25-3">
   <w.rf>
    <LM>w#w-d1t25-3</LM>
   </w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m773-d1t25-4">
   <w.rf>
    <LM>w#w-d1t25-4</LM>
   </w.rf>
   <form>kazeta</form>
   <lemma>kazeta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d1e7-x2-29">
   <w.rf>
    <LM>w#w-d1e7-x2-29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-30">
  <m id="m773-d1t29-1">
   <w.rf>
    <LM>w#w-d1t29-1</LM>
   </w.rf>
   <form>Paní</form>
   <lemma>paní</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m773-d1t29-2">
   <w.rf>
    <LM>w#w-d1t29-2</LM>
   </w.rf>
   <form>Hrbková</form>
   <lemma>Hrbková_;Y</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m773-d-id55088">
   <w.rf>
    <LM>w#w-d-id55088</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t29-4">
   <w.rf>
    <LM>w#w-d1t29-4</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m773-d1t29-5">
   <w.rf>
    <LM>w#w-d1t29-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t29-6">
   <w.rf>
    <LM>w#w-d1t29-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t31-1">
   <w.rf>
    <LM>w#w-d1t31-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t31-2">
   <w.rf>
    <LM>w#w-d1t31-2</LM>
   </w.rf>
   <form>Kinderheimu</form>
   <lemma>kinderheim</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m773-d-id55151">
   <w.rf>
    <LM>w#w-d-id55151</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e32-x2">
  <m id="m773-d1t39-2">
   <w.rf>
    <LM>w#w-d1t39-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t39-3">
   <w.rf>
    <LM>w#w-d1t39-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t39-4">
   <w.rf>
    <LM>w#w-d1t39-4</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m773-d1t39-5">
   <w.rf>
    <LM>w#w-d1t39-5</LM>
   </w.rf>
   <form>Kinderheim</form>
   <lemma>kinderheim</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m773-d-id55311">
   <w.rf>
    <LM>w#w-d-id55311</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e32-x3">
  <m id="m773-d1t43-3">
   <w.rf>
    <LM>w#w-d1t43-3</LM>
   </w.rf>
   <form>Jugendheim</form>
   <lemma>jugendheim</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m773-d1t43-4">
   <w.rf>
    <LM>w#w-d1t43-4</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1e32-x3-81">
   <w.rf>
    <LM>w#w-d1e32-x3-81</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t43-5">
   <w.rf>
    <LM>w#w-d1t43-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d-id55420">
   <w.rf>
    <LM>w#w-d-id55420</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e47-x2">
  <m id="m773-d1t52-1">
   <w.rf>
    <LM>w#w-d1t52-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t52-2">
   <w.rf>
    <LM>w#w-d1t52-2</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d1e47-x2-96">
   <w.rf>
    <LM>w#w-d1e47-x2-96</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-97">
  <m id="m773-d1t52-4">
   <w.rf>
    <LM>w#w-d1t52-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t52-5">
   <w.rf>
    <LM>w#w-d1t52-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t52-6">
   <w.rf>
    <LM>w#w-d1t52-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t52-7">
   <w.rf>
    <LM>w#w-d1t52-7</LM>
   </w.rf>
   <form>něčem</form>
   <lemma>něco</lemma>
   <tag>PK--6----------</tag>
  </m>
  <m id="m773-d1t52-8">
   <w.rf>
    <LM>w#w-d1t52-8</LM>
   </w.rf>
   <form>takovém</form>
   <lemma>takový</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m773-d-id55578">
   <w.rf>
    <LM>w#w-d-id55578</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e57-x3">
  <m id="m773-d1t64-1">
   <w.rf>
    <LM>w#w-d1t64-1</LM>
   </w.rf>
   <form>Myslíte</form>
   <lemma>myslit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t64-2">
   <w.rf>
    <LM>w#w-d1t64-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t64-4">
   <w.rf>
    <LM>w#w-d1t64-4</LM>
   </w.rf>
   <form>Terezíně</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m773-d-id55783">
   <w.rf>
    <LM>w#w-d-id55783</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-378">
  <m id="m773-d1t62-1">
   <w.rf>
    <LM>w#w-d1t62-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d-id55679">
   <w.rf>
    <LM>w#w-d-id55679</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e65-x2">
  <m id="m773-d1t70-2">
   <w.rf>
    <LM>w#w-d1t70-2</LM>
   </w.rf>
   <form>Kinderheim</form>
   <lemma>kinderheim</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m773-d1t70-4">
   <w.rf>
    <LM>w#w-d1t70-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t70-3">
   <w.rf>
    <LM>w#w-d1t70-3</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t72-1">
   <w.rf>
    <LM>w#w-d1t72-1</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t72-3">
   <w.rf>
    <LM>w#w-d1t72-3</LM>
   </w.rf>
   <form>menší</form>
   <lemma>malý</lemma>
   <tag>AAFP4----2A----</tag>
  </m>
  <m id="m773-d1t72-4">
   <w.rf>
    <LM>w#w-d1t72-4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d-id55983">
   <w.rf>
    <LM>w#w-d-id55983</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e73-x2">
  <m id="m773-d1t80-1">
   <w.rf>
    <LM>w#w-d1t80-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t80-2">
   <w.rf>
    <LM>w#w-d1t80-2</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m773-d1t80-4">
   <w.rf>
    <LM>w#w-d1t80-4</LM>
   </w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t80-3">
   <w.rf>
    <LM>w#w-d1t80-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t80-5">
   <w.rf>
    <LM>w#w-d1t80-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t80-6">
   <w.rf>
    <LM>w#w-d1t80-6</LM>
   </w.rf>
   <form>zařazená</form>
   <lemma>zařazený_^(*4dit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m773-d1t80-7">
   <w.rf>
    <LM>w#w-d1t80-7</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t80-8">
   <w.rf>
    <LM>w#w-d1t80-8</LM>
   </w.rf>
   <form>ženy</form>
   <lemma>žena</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d-id56177">
   <w.rf>
    <LM>w#w-d-id56177</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e81-x2">
  <m id="m773-d1t86-1">
   <w.rf>
    <LM>w#w-d1t86-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1e81-x2-38">
   <w.rf>
    <LM>w#w-d1e81-x2-38</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t86-8">
   <w.rf>
    <LM>w#w-d1t86-8</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t86-6">
   <w.rf>
    <LM>w#w-d1t86-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t86-7">
   <w.rf>
    <LM>w#w-d1t86-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t88-1">
   <w.rf>
    <LM>w#w-d1t88-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m773-d1t88-3">
   <w.rf>
    <LM>w#w-d1t88-3</LM>
   </w.rf>
   <form>věku</form>
   <lemma>věk</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m773-d1t88-4">
   <w.rf>
    <LM>w#w-d1t88-4</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t88-5">
   <w.rf>
    <LM>w#w-d1t88-5</LM>
   </w.rf>
   <form>čtrnácti</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m773-d1t88-6">
   <w.rf>
    <LM>w#w-d1t88-6</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t88-7">
   <w.rf>
    <LM>w#w-d1t88-7</LM>
   </w.rf>
   <form>sedmnácti</form>
   <lemma>sedmnáct`17</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m773-d1t88-8">
   <w.rf>
    <LM>w#w-d1t88-8</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m773-d-id56494">
   <w.rf>
    <LM>w#w-d-id56494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e89-x2">
  <m id="m773-d1e89-x2-1748">
   <w.rf>
    <LM>w#w-d1e89-x2-1748</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t98-1">
   <w.rf>
    <LM>w#w-d1t98-1</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m773-d1t98-2">
   <w.rf>
    <LM>w#w-d1t98-2</LM>
   </w.rf>
   <form>intimní</form>
   <lemma>intimní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m773-d1t98-3">
   <w.rf>
    <LM>w#w-d1t98-3</LM>
   </w.rf>
   <form>otázku</form>
   <lemma>otázka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m773-d-id56619">
   <w.rf>
    <LM>w#w-d-id56619</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t98-5">
   <w.rf>
    <LM>w#w-d1t98-5</LM>
   </w.rf>
   <form>nemusíte</form>
   <lemma>muset</lemma>
   <tag>VB-P---2P-NAI--</tag>
  </m>
  <m id="m773-d1t98-6">
   <w.rf>
    <LM>w#w-d1t98-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t98-7">
   <w.rf>
    <LM>w#w-d1t98-7</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m773-d1t98-8">
   <w.rf>
    <LM>w#w-d1t98-8</LM>
   </w.rf>
   <form>odpovídat</form>
   <lemma>odpovídat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d1e89-x2-1746">
   <w.rf>
    <LM>w#w-d1e89-x2-1746</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1747">
  <m id="m773-d1t100-1">
   <w.rf>
    <LM>w#w-d1t100-1</LM>
   </w.rf>
   <form>Stala</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d1t100-2">
   <w.rf>
    <LM>w#w-d1t100-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t100-3">
   <w.rf>
    <LM>w#w-d1t100-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t100-4">
   <w.rf>
    <LM>w#w-d1t100-4</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P2--2-------</tag>
  </m>
  <m id="m773-d1t100-5">
   <w.rf>
    <LM>w#w-d1t100-5</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d1e89-x2-86">
   <w.rf>
    <LM>w#w-d1e89-x2-86</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t100-7">
   <w.rf>
    <LM>w#w-d1t100-7</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t100-8">
   <w.rf>
    <LM>w#w-d1t100-8</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t100-9">
   <w.rf>
    <LM>w#w-d1t100-9</LM>
   </w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m773-d1t100-10">
   <w.rf>
    <LM>w#w-d1t100-10</LM>
   </w.rf>
   <form>hygienické</form>
   <lemma>hygienický</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m773-d1t103-1">
   <w.rf>
    <LM>w#w-d1t103-1</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m773-d-id56802">
   <w.rf>
    <LM>w#w-d-id56802</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t103-3">
   <w.rf>
    <LM>w#w-d1t103-3</LM>
   </w.rf>
   <form>potíže</form>
   <lemma>potíž</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d-id56826">
   <w.rf>
    <LM>w#w-d-id56826</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t105-1">
   <w.rf>
    <LM>w#w-d1t105-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t105-2">
   <w.rf>
    <LM>w#w-d1t105-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t107-1">
   <w.rf>
    <LM>w#w-d1t107-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t107-2">
   <w.rf>
    <LM>w#w-d1t107-2</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m773-d1t105-3">
   <w.rf>
    <LM>w#w-d1t105-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t105-4">
   <w.rf>
    <LM>w#w-d1t105-4</LM>
   </w.rf>
   <form>takových</form>
   <lemma>takový</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m773-d1t105-5">
   <w.rf>
    <LM>w#w-d1t105-5</LM>
   </w.rf>
   <form>podmínkách</form>
   <lemma>podmínka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m773-d1t107-3">
   <w.rf>
    <LM>w#w-d1t107-3</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t107-4">
   <w.rf>
    <LM>w#w-d1t107-4</LM>
   </w.rf>
   <form>mohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t111-1">
   <w.rf>
    <LM>w#w-d1t111-1</LM>
   </w.rf>
   <form>žít</form>
   <lemma>žít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d-id56966">
   <w.rf>
    <LM>w#w-d-id56966</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e112-x2">
  <m id="m773-d1t117-1">
   <w.rf>
    <LM>w#w-d1t117-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t117-2">
   <w.rf>
    <LM>w#w-d1t117-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m773-d1t117-3">
   <w.rf>
    <LM>w#w-d1t117-3</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d1e112-x2-147">
   <w.rf>
    <LM>w#w-d1e112-x2-147</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-148">
  <m id="m773-d1t117-7">
   <w.rf>
    <LM>w#w-d1t117-7</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t117-6">
   <w.rf>
    <LM>w#w-d1t117-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t117-8">
   <w.rf>
    <LM>w#w-d1t117-8</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t117-9">
   <w.rf>
    <LM>w#w-d1t117-9</LM>
   </w.rf>
   <form>vyvinutá</form>
   <lemma>vyvinutý_^(*3out)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m773-148-158">
   <w.rf>
    <LM>w#w-148-158</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t117-10">
   <w.rf>
    <LM>w#w-d1t117-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t117-11">
   <w.rf>
    <LM>w#w-d1t117-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t117-12">
   <w.rf>
    <LM>w#w-d1t117-12</LM>
   </w.rf>
   <form>jedenácti</form>
   <lemma>jedenáct`11</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m773-d1t117-13">
   <w.rf>
    <LM>w#w-d1t117-13</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m773-d1t119-1">
   <w.rf>
    <LM>w#w-d1t119-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t119-2">
   <w.rf>
    <LM>w#w-d1t119-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t119-4">
   <w.rf>
    <LM>w#w-d1t119-4</LM>
   </w.rf>
   <form>cykly</form>
   <lemma>cyklus</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m773-148-160">
   <w.rf>
    <LM>w#w-148-160</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t123-1">
   <w.rf>
    <LM>w#w-d1t123-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t123-2">
   <w.rf>
    <LM>w#w-d1t123-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t123-3">
   <w.rf>
    <LM>w#w-d1t123-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t123-4">
   <w.rf>
    <LM>w#w-d1t123-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t123-5">
   <w.rf>
    <LM>w#w-d1t123-5</LM>
   </w.rf>
   <form>ztratily</form>
   <lemma>ztratit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m773-d-id57425">
   <w.rf>
    <LM>w#w-d-id57425</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e112-x3">
  <m id="m773-d1t128-3">
   <w.rf>
    <LM>w#w-d1t128-3</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d-id57504">
   <w.rf>
    <LM>w#w-d-id57504</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t128-5">
   <w.rf>
    <LM>w#w-d1t128-5</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t128-6">
   <w.rf>
    <LM>w#w-d1t128-6</LM>
   </w.rf>
   <form>každá</form>
   <lemma>každý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m773-d-id57544">
   <w.rf>
    <LM>w#w-d-id57544</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t128-8">
   <w.rf>
    <LM>w#w-d1t128-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t128-9">
   <w.rf>
    <LM>w#w-d1t128-9</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m773-d1t128-10">
   <w.rf>
    <LM>w#w-d1t128-10</LM>
   </w.rf>
   <form>rozhodně</form>
   <lemma>rozhodně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t128-11">
   <w.rf>
    <LM>w#w-d1t128-11</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d-id57615">
   <w.rf>
    <LM>w#w-d-id57615</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e112-x4">
  <m id="m773-d1t132-2">
   <w.rf>
    <LM>w#w-d1t132-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1e112-x4-231">
   <w.rf>
    <LM>w#w-d1e112-x4-231</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t132-4">
   <w.rf>
    <LM>w#w-d1t132-4</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d-id57710">
   <w.rf>
    <LM>w#w-d-id57710</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t132-6">
   <w.rf>
    <LM>w#w-d1t132-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t132-7">
   <w.rf>
    <LM>w#w-d1t132-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t132-8">
   <w.rf>
    <LM>w#w-d1t132-8</LM>
   </w.rf>
   <form>zjistili</form>
   <lemma>zjistit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m773-d-id57765">
   <w.rf>
    <LM>w#w-d-id57765</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t132-11">
   <w.rf>
    <LM>w#w-d1t132-11</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m773-d1t132-12">
   <w.rf>
    <LM>w#w-d1t132-12</LM>
   </w.rf>
   <form>dávali</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m773-d1t132-13">
   <w.rf>
    <LM>w#w-d1t132-13</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m773-d1t132-14">
   <w.rf>
    <LM>w#w-d1t132-14</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t132-15">
   <w.rf>
    <LM>w#w-d1t132-15</LM>
   </w.rf>
   <form>jídla</form>
   <lemma>jídlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m773-d-id57867">
   <w.rf>
    <LM>w#w-d-id57867</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e141-x2">
  <m id="m773-d1t144-2">
   <w.rf>
    <LM>w#w-d1t144-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t144-3">
   <w.rf>
    <LM>w#w-d1t144-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t144-4">
   <w.rf>
    <LM>w#w-d1t144-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t144-5">
   <w.rf>
    <LM>w#w-d1t144-5</LM>
   </w.rf>
   <form>vrátila</form>
   <lemma>vrátit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d-id58083">
   <w.rf>
    <LM>w#w-d-id58083</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t144-7">
   <w.rf>
    <LM>w#w-d1t144-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t144-8">
   <w.rf>
    <LM>w#w-d1t144-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t144-9">
   <w.rf>
    <LM>w#w-d1t144-9</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t144-10">
   <w.rf>
    <LM>w#w-d1t144-10</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d1t144-11">
   <w.rf>
    <LM>w#w-d1t144-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t144-12">
   <w.rf>
    <LM>w#w-d1t144-12</LM>
   </w.rf>
   <form>injekce</form>
   <lemma>injekce</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d-id58185">
   <w.rf>
    <LM>w#w-d-id58185</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t146-4">
   <w.rf>
    <LM>w#w-d1t146-4</LM>
   </w.rf>
   <form>snižovali</form>
   <lemma>snižovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m773-d1t146-3">
   <w.rf>
    <LM>w#w-d1t146-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m773-d1t146-2">
   <w.rf>
    <LM>w#w-d1t146-2</LM>
   </w.rf>
   <form>dávky</form>
   <lemma>dávka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d1e141-x2-1763">
   <w.rf>
    <LM>w#w-d1e141-x2-1763</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1764">
  <m id="m773-d1t150-2">
   <w.rf>
    <LM>w#w-d1t150-2</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t150-3">
   <w.rf>
    <LM>w#w-d1t150-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m773-d1t150-4">
   <w.rf>
    <LM>w#w-d1t150-4</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m773-d1t150-5">
   <w.rf>
    <LM>w#w-d1t150-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t150-6">
   <w.rf>
    <LM>w#w-d1t150-6</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t150-7">
   <w.rf>
    <LM>w#w-d1t150-7</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t150-8">
   <w.rf>
    <LM>w#w-d1t150-8</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m773-d1e141-x2-335">
   <w.rf>
    <LM>w#w-d1e141-x2-335</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-328">
  <m id="m773-d1t152-4">
   <w.rf>
    <LM>w#w-d1t152-4</LM>
   </w.rf>
   <form>Nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t152-6">
   <w.rf>
    <LM>w#w-d1t152-6</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t152-7">
   <w.rf>
    <LM>w#w-d1t152-7</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t152-8">
   <w.rf>
    <LM>w#w-d1t152-8</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m773-d-id58581">
   <w.rf>
    <LM>w#w-d-id58581</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t152-10">
   <w.rf>
    <LM>w#w-d1t152-10</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t152-11">
   <w.rf>
    <LM>w#w-d1t152-11</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t152-12">
   <w.rf>
    <LM>w#w-d1t152-12</LM>
   </w.rf>
   <form>obličej</form>
   <lemma>obličej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m773-d1t155-1">
   <w.rf>
    <LM>w#w-d1t155-1</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t155-2">
   <w.rf>
    <LM>w#w-d1t155-2</LM>
   </w.rf>
   <form>odulý</form>
   <lemma>odulý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m773-d1t155-3">
   <w.rf>
    <LM>w#w-d1t155-3</LM>
   </w.rf>
   <form>nežli</form>
   <lemma>nežli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t155-4">
   <w.rf>
    <LM>w#w-d1t155-4</LM>
   </w.rf>
   <form>hubený</form>
   <lemma>hubený_^(*3it)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m773-d-id58701">
   <w.rf>
    <LM>w#w-d-id58701</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e141-x3">
  <m id="m773-d1t159-5">
   <w.rf>
    <LM>w#w-d1t159-5</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d1e141-x3-383">
   <w.rf>
    <LM>w#w-d1e141-x3-383</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t161-6">
   <w.rf>
    <LM>w#w-d1t161-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m773-d1t161-7">
   <w.rf>
    <LM>w#w-d1t161-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t161-8">
   <w.rf>
    <LM>w#w-d1t161-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d-id58812">
   <w.rf>
    <LM>w#w-d-id58812</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t161-1">
   <w.rf>
    <LM>w#w-d1t161-1</LM>
   </w.rf>
   <form>nechci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d1t161-2">
   <w.rf>
    <LM>w#w-d1t161-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t161-3">
   <w.rf>
    <LM>w#w-d1t161-3</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t161-4">
   <w.rf>
    <LM>w#w-d1t161-4</LM>
   </w.rf>
   <form>tvrdit</form>
   <lemma>tvrdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d-id58947">
   <w.rf>
    <LM>w#w-d-id58947</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e141-x4">
  <m id="m773-d1t165-1">
   <w.rf>
    <LM>w#w-d1t165-1</LM>
   </w.rf>
   <form>Slyšela</form>
   <lemma>slyšet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t165-2">
   <w.rf>
    <LM>w#w-d1t165-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d-id59010">
   <w.rf>
    <LM>w#w-d-id59010</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t165-4">
   <w.rf>
    <LM>w#w-d1t165-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t165-5">
   <w.rf>
    <LM>w#w-d1t165-5</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m773-d1t165-6">
   <w.rf>
    <LM>w#w-d1t165-6</LM>
   </w.rf>
   <form>dávali</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m773-d1t165-8">
   <w.rf>
    <LM>w#w-d1t165-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t165-9">
   <w.rf>
    <LM>w#w-d1t165-9</LM>
   </w.rf>
   <form>jídla</form>
   <lemma>jídlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m773-d1t165-7">
   <w.rf>
    <LM>w#w-d1t165-7</LM>
   </w.rf>
   <form>arsen</form>
   <lemma>arsen_,s_^(^DD**arzén)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m773-d1e141-x4-1782">
   <w.rf>
    <LM>w#w-d1e141-x4-1782</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1783">
  <m id="m773-d1t165-11">
   <w.rf>
    <LM>w#w-d1t165-11</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t165-12">
   <w.rf>
    <LM>w#w-d1t165-12</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t165-13">
   <w.rf>
    <LM>w#w-d1t165-13</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d-id59167">
   <w.rf>
    <LM>w#w-d-id59167</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t165-15">
   <w.rf>
    <LM>w#w-d1t165-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t165-16">
   <w.rf>
    <LM>w#w-d1t165-16</LM>
   </w.rf>
   <form>arsen</form>
   <lemma>arsen_,s_^(^DD**arzén)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m773-d1t165-17">
   <w.rf>
    <LM>w#w-d1t165-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m773-d1t165-18">
   <w.rf>
    <LM>w#w-d1t165-18</LM>
   </w.rf>
   <form>jed</form>
   <lemma>jed</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m773-d1e141-x4-169">
   <w.rf>
    <LM>w#w-d1e141-x4-169</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t168-1">
   <w.rf>
    <LM>w#w-d1t168-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t168-3">
   <w.rf>
    <LM>w#w-d1t168-3</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m773-d1t168-4">
   <w.rf>
    <LM>w#w-d1t168-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m773-d1t168-5">
   <w.rf>
    <LM>w#w-d1t168-5</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t170-1">
   <w.rf>
    <LM>w#w-d1t170-1</LM>
   </w.rf>
   <form>otrávili</form>
   <lemma>otrávit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m773-d1e141-x4-173">
   <w.rf>
    <LM>w#w-d1e141-x4-173</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-174">
  <m id="m773-d1t172-2">
   <w.rf>
    <LM>w#w-d1t172-2</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-174-192">
   <w.rf>
    <LM>w#w-174-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-183">
  <m id="m773-d1t172-4">
   <w.rf>
    <LM>w#w-d1t172-4</LM>
   </w.rf>
   <form>Opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t172-5">
   <w.rf>
    <LM>w#w-d1t172-5</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d-id59431">
   <w.rf>
    <LM>w#w-d-id59431</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t172-7">
   <w.rf>
    <LM>w#w-d1t172-7</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m773-d1t172-8">
   <w.rf>
    <LM>w#w-d1t172-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t172-9">
   <w.rf>
    <LM>w#w-d1t172-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-183-1793">
   <w.rf>
    <LM>w#w-183-1793</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1794">
  <m id="m773-d1t172-12">
   <w.rf>
    <LM>w#w-d1t172-12</LM>
   </w.rf>
   <form>Pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d1t172-11">
   <w.rf>
    <LM>w#w-d1t172-11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t172-13">
   <w.rf>
    <LM>w#w-d1t172-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m773-d-id59540">
   <w.rf>
    <LM>w#w-d-id59540</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t172-15">
   <w.rf>
    <LM>w#w-d1t172-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t176-1">
   <w.rf>
    <LM>w#w-d1t176-1</LM>
   </w.rf>
   <form>zkraje</form>
   <lemma>zkraje-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t176-3">
   <w.rf>
    <LM>w#w-d1t176-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t176-4">
   <w.rf>
    <LM>w#w-d1t176-4</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t176-6">
   <w.rf>
    <LM>w#w-d1t176-6</LM>
   </w.rf>
   <form>potíže</form>
   <lemma>potíž</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d1t176-7">
   <w.rf>
    <LM>w#w-d1t176-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t176-8">
   <w.rf>
    <LM>w#w-d1t176-8</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t176-9">
   <w.rf>
    <LM>w#w-d1t176-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t178-1">
   <w.rf>
    <LM>w#w-d1t178-1</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t178-2">
   <w.rf>
    <LM>w#w-d1t178-2</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t178-3">
   <w.rf>
    <LM>w#w-d1t178-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t178-4">
   <w.rf>
    <LM>w#w-d1t178-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t178-5">
   <w.rf>
    <LM>w#w-d1t178-5</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m773-183-132">
   <w.rf>
    <LM>w#w-183-132</LM>
   </w.rf>
   <form>potíže</form>
   <lemma>potíž</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d1t178-7">
   <w.rf>
    <LM>w#w-d1t178-7</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m773-183-143">
   <w.rf>
    <LM>w#w-183-143</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-199">
  <m id="m773-d1t178-10">
   <w.rf>
    <LM>w#w-d1t178-10</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t178-11">
   <w.rf>
    <LM>w#w-d1t178-11</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t178-12">
   <w.rf>
    <LM>w#w-d1t178-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t178-13">
   <w.rf>
    <LM>w#w-d1t178-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t178-14">
   <w.rf>
    <LM>w#w-d1t178-14</LM>
   </w.rf>
   <form>vrátila</form>
   <lemma>vrátit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d-id59950">
   <w.rf>
    <LM>w#w-d-id59950</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t183-1">
   <w.rf>
    <LM>w#w-d1t183-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t183-2">
   <w.rf>
    <LM>w#w-d1t183-2</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t183-3">
   <w.rf>
    <LM>w#w-d1t183-3</LM>
   </w.rf>
   <form>naopak</form>
   <lemma>naopak-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-199-216">
   <w.rf>
    <LM>w#w-199-216</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-209">
  <m id="m773-d1t183-5">
   <w.rf>
    <LM>w#w-d1t183-5</LM>
   </w.rf>
   <form>Musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t183-6">
   <w.rf>
    <LM>w#w-d1t183-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t183-7">
   <w.rf>
    <LM>w#w-d1t183-7</LM>
   </w.rf>
   <form>navštívit</form>
   <lemma>navštívit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d1t183-8">
   <w.rf>
    <LM>w#w-d1t183-8</LM>
   </w.rf>
   <form>lékařku</form>
   <lemma>lékařka_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m773-d-id60094">
   <w.rf>
    <LM>w#w-d-id60094</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t185-1">
   <w.rf>
    <LM>w#w-d1t185-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t185-2">
   <w.rf>
    <LM>w#w-d1t185-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t185-3">
   <w.rf>
    <LM>w#w-d1t185-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d1t185-4">
   <w.rf>
    <LM>w#w-d1t185-4</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t185-5">
   <w.rf>
    <LM>w#w-d1t185-5</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-209-220">
   <w.rf>
    <LM>w#w-209-220</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t185-6">
   <w.rf>
    <LM>w#w-d1t185-6</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t185-7">
   <w.rf>
    <LM>w#w-d1t185-7</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m773-d1t185-8">
   <w.rf>
    <LM>w#w-d1t185-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t185-9">
   <w.rf>
    <LM>w#w-d1t185-9</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t185-10">
   <w.rf>
    <LM>w#w-d1t185-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t185-11">
   <w.rf>
    <LM>w#w-d1t185-11</LM>
   </w.rf>
   <form>vykrvácet</form>
   <lemma>vykrvácet</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d-id60282">
   <w.rf>
    <LM>w#w-d-id60282</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e187-x2">
  <m id="m773-d1t190-4">
   <w.rf>
    <LM>w#w-d1t190-4</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t190-5">
   <w.rf>
    <LM>w#w-d1t190-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t190-6">
   <w.rf>
    <LM>w#w-d1t190-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t190-2">
   <w.rf>
    <LM>w#w-d1t190-2</LM>
   </w.rf>
   <form>zkraje</form>
   <lemma>zkraje-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t190-7">
   <w.rf>
    <LM>w#w-d1t190-7</LM>
   </w.rf>
   <form>řešily</form>
   <lemma>řešit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1e187-x2-244">
   <w.rf>
    <LM>w#w-d1e187-x2-244</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-233">
  <m id="m773-d1t190-8">
   <w.rf>
    <LM>w#w-d1t190-8</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t190-10">
   <w.rf>
    <LM>w#w-d1t190-10</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t190-11">
   <w.rf>
    <LM>w#w-d1t190-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t190-9">
   <w.rf>
    <LM>w#w-d1t190-9</LM>
   </w.rf>
   <form>přeci</form>
   <lemma>přeci-2_,h_^(^GC**přece-2)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t190-12">
   <w.rf>
    <LM>w#w-d1t190-12</LM>
   </w.rf>
   <form>nemohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m773-d1t190-13">
   <w.rf>
    <LM>w#w-d1t190-13</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m773-d1t190-14">
   <w.rf>
    <LM>w#w-d1t190-14</LM>
   </w.rf>
   <form>pořídit</form>
   <lemma>pořídit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-233-248">
   <w.rf>
    <LM>w#w-233-248</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t190-15">
   <w.rf>
    <LM>w#w-d1t190-15</LM>
   </w.rf>
   <form>koupit</form>
   <lemma>koupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-233-251">
   <w.rf>
    <LM>w#w-233-251</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t194-1">
   <w.rf>
    <LM>w#w-d1t194-1</LM>
   </w.rf>
   <form>hygiena</form>
   <lemma>hygiena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d1t194-2">
   <w.rf>
    <LM>w#w-d1t194-2</LM>
   </w.rf>
   <form>veškerá</form>
   <lemma>veškerý</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m773-d1t194-3">
   <w.rf>
    <LM>w#w-d1t194-3</LM>
   </w.rf>
   <form>žádná</form>
   <lemma>žádný</lemma>
   <tag>PWFS1----------</tag>
  </m>
  <m id="m773-233-252">
   <w.rf>
    <LM>w#w-233-252</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-253">
  <m id="m773-d1t194-5">
   <w.rf>
    <LM>w#w-d1t194-5</LM>
   </w.rf>
   <form>Nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t194-6">
   <w.rf>
    <LM>w#w-d1t194-6</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t194-7">
   <w.rf>
    <LM>w#w-d1t194-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t194-8">
   <w.rf>
    <LM>w#w-d1t194-8</LM>
   </w.rf>
   <form>mohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t194-9">
   <w.rf>
    <LM>w#w-d1t194-9</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m773-d1t194-10">
   <w.rf>
    <LM>w#w-d1t194-10</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m773-d1t194-11">
   <w.rf>
    <LM>w#w-d1t194-11</LM>
   </w.rf>
   <form>koupat</form>
   <lemma>koupat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d-id60614">
   <w.rf>
    <LM>w#w-d-id60614</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e195-x2">
  <m id="m773-d1t198-4">
   <w.rf>
    <LM>w#w-d1t198-4</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d-id60728">
   <w.rf>
    <LM>w#w-d-id60728</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t198-6">
   <w.rf>
    <LM>w#w-d1t198-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t200-1">
   <w.rf>
    <LM>w#w-d1t200-1</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t200-2">
   <w.rf>
    <LM>w#w-d1t200-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1e195-x2-483">
   <w.rf>
    <LM>w#w-d1e195-x2-483</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-484">
  <m id="m773-d1t204-1">
   <w.rf>
    <LM>w#w-d1t204-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t204-3">
   <w.rf>
    <LM>w#w-d1t204-3</LM>
   </w.rf>
   <form>hygienou</form>
   <lemma>hygiena</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m773-d1t204-4">
   <w.rf>
    <LM>w#w-d1t204-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t204-5">
   <w.rf>
    <LM>w#w-d1t204-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t204-6">
   <w.rf>
    <LM>w#w-d1t204-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d1t204-7">
   <w.rf>
    <LM>w#w-d1t204-7</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t204-8">
   <w.rf>
    <LM>w#w-d1t204-8</LM>
   </w.rf>
   <form>špatné</form>
   <lemma>špatný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m773-484-1809">
   <w.rf>
    <LM>w#w-484-1809</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t211-1">
   <w.rf>
    <LM>w#w-d1t211-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t211-2">
   <w.rf>
    <LM>w#w-d1t211-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t211-3">
   <w.rf>
    <LM>w#w-d1t211-3</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d-id61006">
   <w.rf>
    <LM>w#w-d-id61006</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t211-7">
   <w.rf>
    <LM>w#w-d1t211-7</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t211-6">
   <w.rf>
    <LM>w#w-d1t211-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t211-9">
   <w.rf>
    <LM>w#w-d1t211-9</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m773-d1t211-10">
   <w.rf>
    <LM>w#w-d1t211-10</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m773-484-494">
   <w.rf>
    <LM>w#w-484-494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-496">
  <m id="m773-d1t211-15">
   <w.rf>
    <LM>w#w-d1t211-15</LM>
   </w.rf>
   <form>Nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t211-14">
   <w.rf>
    <LM>w#w-d1t211-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t211-16">
   <w.rf>
    <LM>w#w-d1t211-16</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t211-17">
   <w.rf>
    <LM>w#w-d1t211-17</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m773-d1t211-18">
   <w.rf>
    <LM>w#w-d1t211-18</LM>
   </w.rf>
   <form>nemluvily</form>
   <lemma>mluvit</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m773-d1e195-x2-458">
   <w.rf>
    <LM>w#w-d1e195-x2-458</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-451">
  <m id="m773-d1t213-1">
   <w.rf>
    <LM>w#w-d1t213-1</LM>
   </w.rf>
   <form>Některé</form>
   <lemma>některý</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m773-d1t213-4">
   <w.rf>
    <LM>w#w-d1t213-4</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m773-d1t215-1">
   <w.rf>
    <LM>w#w-d1t215-1</LM>
   </w.rf>
   <form>zas</form>
   <lemma>zas-1_,s_^(^DD**zase-1)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t215-2">
   <w.rf>
    <LM>w#w-d1t215-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t215-3">
   <w.rf>
    <LM>w#w-d1t215-3</LM>
   </w.rf>
   <form>vyvinuté</form>
   <lemma>vyvinutý_^(*3out)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m773-d-id61391">
   <w.rf>
    <LM>w#w-d-id61391</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t215-8">
   <w.rf>
    <LM>w#w-d1t215-8</LM>
   </w.rf>
   <form>některá</form>
   <lemma>některý</lemma>
   <tag>PZNP1----------</tag>
  </m>
  <m id="m773-d1t215-9">
   <w.rf>
    <LM>w#w-d1t215-9</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m773-d1t217-1">
   <w.rf>
    <LM>w#w-d1t217-1</LM>
   </w.rf>
   <form>začínají</form>
   <lemma>začínat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m773-d1t217-2">
   <w.rf>
    <LM>w#w-d1t217-2</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t217-3">
   <w.rf>
    <LM>w#w-d1t217-3</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t217-5">
   <w.rf>
    <LM>w#w-d1t217-5</LM>
   </w.rf>
   <form>patnácti</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m773-d1t217-6">
   <w.rf>
    <LM>w#w-d1t217-6</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t217-7">
   <w.rf>
    <LM>w#w-d1t217-7</LM>
   </w.rf>
   <form>šestnácti</form>
   <lemma>šestnáct`16</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m773-d1t217-8">
   <w.rf>
    <LM>w#w-d1t217-8</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m773-451-1818">
   <w.rf>
    <LM>w#w-451-1818</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1819">
  <m id="m773-d1t219-4">
   <w.rf>
    <LM>w#w-d1t219-4</LM>
   </w.rf>
   <form>Přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t219-3">
   <w.rf>
    <LM>w#w-d1t219-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-451-479">
   <w.rf>
    <LM>w#w-451-479</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t219-5">
   <w.rf>
    <LM>w#w-d1t219-5</LM>
   </w.rf>
   <form>nevzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-451-470">
   <w.rf>
    <LM>w#w-451-470</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t219-6">
   <w.rf>
    <LM>w#w-d1t219-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t219-7">
   <w.rf>
    <LM>w#w-d1t219-7</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t219-8">
   <w.rf>
    <LM>w#w-d1t219-8</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m773-d1t219-9">
   <w.rf>
    <LM>w#w-d1t219-9</LM>
   </w.rf>
   <form>takového</form>
   <lemma>takový</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m773-d1t219-10">
   <w.rf>
    <LM>w#w-d1t219-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d-id61768">
   <w.rf>
    <LM>w#w-d-id61768</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t222-2">
   <w.rf>
    <LM>w#w-d1t222-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t222-3">
   <w.rf>
    <LM>w#w-d1t222-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t222-4">
   <w.rf>
    <LM>w#w-d1t222-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t222-5">
   <w.rf>
    <LM>w#w-d1t222-5</LM>
   </w.rf>
   <form>musely</form>
   <lemma>muset</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t222-6">
   <w.rf>
    <LM>w#w-d1t222-6</LM>
   </w.rf>
   <form>poradit</form>
   <lemma>poradit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d1t222-7">
   <w.rf>
    <LM>w#w-d1t222-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t222-8">
   <w.rf>
    <LM>w#w-d1t222-8</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m773-d-id61909">
   <w.rf>
    <LM>w#w-d-id61909</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t222-10">
   <w.rf>
    <LM>w#w-d1t222-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m773-d1t222-11">
   <w.rf>
    <LM>w#w-d1t222-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t222-12">
   <w.rf>
    <LM>w#w-d1t222-12</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-451-475">
   <w.rf>
    <LM>w#w-451-475</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t222-13">
   <w.rf>
    <LM>w#w-d1t222-13</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m773-d1t222-15">
   <w.rf>
    <LM>w#w-d1t222-15</LM>
   </w.rf>
   <form>hadry</form>
   <lemma>hadr</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m773-451-477">
   <w.rf>
    <LM>w#w-451-477</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t222-16">
   <w.rf>
    <LM>w#w-d1t222-16</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t224-2">
   <w.rf>
    <LM>w#w-d1t224-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t224-1">
   <w.rf>
    <LM>w#w-d1t224-1</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m773-d1t224-3">
   <w.rf>
    <LM>w#w-d1t224-3</LM>
   </w.rf>
   <form>sehnat</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-1819-1820">
   <w.rf>
    <LM>w#w-1819-1820</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1821">
  <m id="m773-d1t224-4">
   <w.rf>
    <LM>w#w-d1t224-4</LM>
   </w.rf>
   <form>Nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t224-5">
   <w.rf>
    <LM>w#w-d1t224-5</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m773-d1t224-6">
   <w.rf>
    <LM>w#w-d1t224-6</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m773-d1t224-7">
   <w.rf>
    <LM>w#w-d1t224-7</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m773-d1t224-8">
   <w.rf>
    <LM>w#w-d1t224-8</LM>
   </w.rf>
   <form>sehnal</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m773-451-928">
   <w.rf>
    <LM>w#w-451-928</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t228-1">
   <w.rf>
    <LM>w#w-d1t228-1</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t228-2">
   <w.rf>
    <LM>w#w-d1t228-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t228-3">
   <w.rf>
    <LM>w#w-d1t228-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t228-4">
   <w.rf>
    <LM>w#w-d1t228-4</LM>
   </w.rf>
   <form>potřebovaly</form>
   <lemma>potřebovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d-id62160">
   <w.rf>
    <LM>w#w-d-id62160</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-802">
  <m id="m773-d1t228-5">
   <w.rf>
    <LM>w#w-d1t228-5</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d1t228-6">
   <w.rf>
    <LM>w#w-d1t228-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t228-7">
   <w.rf>
    <LM>w#w-d1t228-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t228-8">
   <w.rf>
    <LM>w#w-d1t228-8</LM>
   </w.rf>
   <form>každém</form>
   <lemma>každý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m773-d1t228-9">
   <w.rf>
    <LM>w#w-d1t228-9</LM>
   </w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m773-d1t228-10">
   <w.rf>
    <LM>w#w-d1t228-10</LM>
   </w.rf>
   <form>nepříjemné</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m773-d-id62335">
   <w.rf>
    <LM>w#w-d-id62335</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e229-x2">
  <m id="m773-d1t234-1">
   <w.rf>
    <LM>w#w-d1t234-1</LM>
   </w.rf>
   <form>Přesto</form>
   <lemma>přesto-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t234-3">
   <w.rf>
    <LM>w#w-d1t234-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t234-4">
   <w.rf>
    <LM>w#w-d1t234-4</LM>
   </w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m773-d1t234-5">
   <w.rf>
    <LM>w#w-d1t234-5</LM>
   </w.rf>
   <form>dívky</form>
   <lemma>dívka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m773-d1t234-6">
   <w.rf>
    <LM>w#w-d1t234-6</LM>
   </w.rf>
   <form>přišly</form>
   <lemma>přijít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m773-d1t234-7">
   <w.rf>
    <LM>w#w-d1t234-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t234-8">
   <w.rf>
    <LM>w#w-d1t234-8</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m773-d1t234-9">
   <w.rf>
    <LM>w#w-d1t234-9</LM>
   </w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m773-d-id62515">
   <w.rf>
    <LM>w#w-d-id62515</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1106">
  <m id="m773-d1t248-2">
   <w.rf>
    <LM>w#w-d1t248-2</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d-id62745">
   <w.rf>
    <LM>w#w-d-id62745</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e241-x2">
  <m id="m773-d1t246-1">
   <w.rf>
    <LM>w#w-d1t246-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m773-d1t246-2">
   <w.rf>
    <LM>w#w-d1t246-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t246-3">
   <w.rf>
    <LM>w#w-d1t246-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t246-4">
   <w.rf>
    <LM>w#w-d1t246-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m773-d1t246-5">
   <w.rf>
    <LM>w#w-d1t246-5</LM>
   </w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m773-d1t246-6">
   <w.rf>
    <LM>w#w-d1t246-6</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m773-d-id62728">
   <w.rf>
    <LM>w#w-d-id62728</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e249-x2">
  <m id="m773-d1t256-6">
   <w.rf>
    <LM>w#w-d1t256-6</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t256-7">
   <w.rf>
    <LM>w#w-d1t256-7</LM>
   </w.rf>
   <form>žádným</form>
   <lemma>žádný</lemma>
   <tag>PWZS7----------</tag>
  </m>
  <m id="m773-d1t256-8">
   <w.rf>
    <LM>w#w-d1t256-8</LM>
   </w.rf>
   <form>takovým</form>
   <lemma>takový</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m773-d1t256-9">
   <w.rf>
    <LM>w#w-d1t256-9</LM>
   </w.rf>
   <form>případem</form>
   <lemma>případ</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m773-d1t256-3">
   <w.rf>
    <LM>w#w-d1t256-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t256-4">
   <w.rf>
    <LM>w#w-d1t256-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t256-5">
   <w.rf>
    <LM>w#w-d1t256-5</LM>
   </w.rf>
   <form>nesetkala</form>
   <lemma>setkat</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m773-d-id62983">
   <w.rf>
    <LM>w#w-d-id62983</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t256-11">
   <w.rf>
    <LM>w#w-d1t256-11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t256-12">
   <w.rf>
    <LM>w#w-d1t256-12</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d-id63038">
   <w.rf>
    <LM>w#w-d-id63038</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t256-15">
   <w.rf>
    <LM>w#w-d1t256-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t256-16">
   <w.rf>
    <LM>w#w-d1t256-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t256-17">
   <w.rf>
    <LM>w#w-d1t256-17</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t256-18">
   <w.rf>
    <LM>w#w-d1t256-18</LM>
   </w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m773-d1e249-x2-1128">
   <w.rf>
    <LM>w#w-d1e249-x2-1128</LM>
   </w.rf>
   <form>dívky</form>
   <lemma>dívka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m773-d1t256-19">
   <w.rf>
    <LM>w#w-d1t256-19</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t256-20">
   <w.rf>
    <LM>w#w-d1t256-20</LM>
   </w.rf>
   <form>jiném</form>
   <lemma>jiný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m773-d1t256-21">
   <w.rf>
    <LM>w#w-d1t256-21</LM>
   </w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m773-d1e249-x2-1129">
   <w.rf>
    <LM>w#w-d1e249-x2-1129</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1130">
  <m id="m773-d1t260-3">
   <w.rf>
    <LM>w#w-d1t260-3</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-1130-1165">
   <w.rf>
    <LM>w#w-1130-1165</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1155">
  <m id="m773-d1t260-5">
   <w.rf>
    <LM>w#w-d1t260-5</LM>
   </w.rf>
   <form>Pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t260-6">
   <w.rf>
    <LM>w#w-d1t260-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m773-d1t260-7">
   <w.rf>
    <LM>w#w-d1t260-7</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t260-8">
   <w.rf>
    <LM>w#w-d1t260-8</LM>
   </w.rf>
   <form>dali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m773-d1t260-9">
   <w.rf>
    <LM>w#w-d1t260-9</LM>
   </w.rf>
   <form>jinam</form>
   <lemma>jinam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d-id63295">
   <w.rf>
    <LM>w#w-d-id63295</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t260-14">
   <w.rf>
    <LM>w#w-d1t260-14</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t260-15">
   <w.rf>
    <LM>w#w-d1t260-15</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t260-17">
   <w.rf>
    <LM>w#w-d1t260-17</LM>
   </w.rf>
   <form>děcko</form>
   <lemma>děcko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m773-1155-1844">
   <w.rf>
    <LM>w#w-1155-1844</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1845">
  <m id="m773-d1t260-21">
   <w.rf>
    <LM>w#w-d1t260-21</LM>
   </w.rf>
   <form>Nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d1t260-20">
   <w.rf>
    <LM>w#w-d1t260-20</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d-id63454">
   <w.rf>
    <LM>w#w-d-id63454</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t260-23">
   <w.rf>
    <LM>w#w-d1t260-23</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t260-24">
   <w.rf>
    <LM>w#w-d1t260-24</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m773-d1t263-1">
   <w.rf>
    <LM>w#w-d1t263-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t263-2">
   <w.rf>
    <LM>w#w-d1t263-2</LM>
   </w.rf>
   <form>ubikaci</form>
   <lemma>ubikace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m773-d1t263-3">
   <w.rf>
    <LM>w#w-d1t263-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t263-4">
   <w.rf>
    <LM>w#w-d1t263-4</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m773-d1t263-6">
   <w.rf>
    <LM>w#w-d1t263-6</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS1----------</tag>
  </m>
  <m id="m773-d1t263-7">
   <w.rf>
    <LM>w#w-d1t263-7</LM>
   </w.rf>
   <form>děcko</form>
   <lemma>děcko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m773-d1t263-5">
   <w.rf>
    <LM>w#w-d1t263-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-1130-1154">
   <w.rf>
    <LM>w#w-1130-1154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1142">
  <m id="m773-d1t263-9">
   <w.rf>
    <LM>w#w-d1t263-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t263-10">
   <w.rf>
    <LM>w#w-d1t263-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t263-11">
   <w.rf>
    <LM>w#w-d1t263-11</LM>
   </w.rf>
   <form>nevzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d-id63653">
   <w.rf>
    <LM>w#w-d-id63653</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e264-x2">
  <m id="m773-d1t275-1">
   <w.rf>
    <LM>w#w-d1t275-1</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t275-2">
   <w.rf>
    <LM>w#w-d1t275-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1e264-x2-1852">
   <w.rf>
    <LM>w#w-d1e264-x2-1852</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t275-6">
   <w.rf>
    <LM>w#w-d1t275-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t275-7">
   <w.rf>
    <LM>w#w-d1t275-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t275-9">
   <w.rf>
    <LM>w#w-d1t275-9</LM>
   </w.rf>
   <form>potkala</form>
   <lemma>potkat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d1t275-4">
   <w.rf>
    <LM>w#w-d1t275-4</LM>
   </w.rf>
   <form>svou</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m773-d1t275-5">
   <w.rf>
    <LM>w#w-d1t275-5</LM>
   </w.rf>
   <form>tetu</form>
   <lemma>teta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m773-d1e264-x2-384">
   <w.rf>
    <LM>w#w-d1e264-x2-384</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1253">
  <m id="m773-d1t278-1">
   <w.rf>
    <LM>w#w-d1t278-1</LM>
   </w.rf>
   <form>Povídejte</form>
   <lemma>povídat</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m773-d1t278-2">
   <w.rf>
    <LM>w#w-d1t278-2</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t278-3">
   <w.rf>
    <LM>w#w-d1t278-3</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m773-d1t278-4">
   <w.rf>
    <LM>w#w-d1t278-4</LM>
   </w.rf>
   <form>chvilku</form>
   <lemma>chvilka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m773-d-id64079">
   <w.rf>
    <LM>w#w-d-id64079</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e279-x2">
  <m id="m773-d1t286-3">
   <w.rf>
    <LM>w#w-d1t286-3</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t286-4">
   <w.rf>
    <LM>w#w-d1t286-4</LM>
   </w.rf>
   <form>tetou</form>
   <lemma>teta</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m773-d1t286-5">
   <w.rf>
    <LM>w#w-d1t286-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t286-6">
   <w.rf>
    <LM>w#w-d1t286-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m773-d1t286-7">
   <w.rf>
    <LM>w#w-d1t286-7</LM>
   </w.rf>
   <form>strýcem</form>
   <lemma>strýc</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m773-d1t286-8">
   <w.rf>
    <LM>w#w-d1t286-8</LM>
   </w.rf>
   <form>Karlem</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m773-d1t286-9">
   <w.rf>
    <LM>w#w-d1t286-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t286-10">
   <w.rf>
    <LM>w#w-d1t286-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t286-11">
   <w.rf>
    <LM>w#w-d1t286-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t286-12">
   <w.rf>
    <LM>w#w-d1t286-12</LM>
   </w.rf>
   <form>setkala</form>
   <lemma>setkat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d1e279-x2-1046">
   <w.rf>
    <LM>w#w-d1e279-x2-1046</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t286-13">
   <w.rf>
    <LM>w#w-d1t286-13</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m773-d1t286-14">
   <w.rf>
    <LM>w#w-d1t286-14</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m773-d1t286-15">
   <w.rf>
    <LM>w#w-d1t286-15</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t286-16">
   <w.rf>
    <LM>w#w-d1t286-16</LM>
   </w.rf>
   <form>vyprávěl</form>
   <lemma>vyprávět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1e279-x2-1047">
   <w.rf>
    <LM>w#w-d1e279-x2-1047</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t286-17">
   <w.rf>
    <LM>w#w-d1t286-17</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t286-18">
   <w.rf>
    <LM>w#w-d1t286-18</LM>
   </w.rf>
   <form>přežil</form>
   <lemma>přežít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m773-d1t286-19">
   <w.rf>
    <LM>w#w-d1t286-19</LM>
   </w.rf>
   <form>pochod</form>
   <lemma>pochod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m773-d1t286-20">
   <w.rf>
    <LM>w#w-d1t286-20</LM>
   </w.rf>
   <form>smrti</form>
   <lemma>smrt</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m773-d1e279-x2-1048">
   <w.rf>
    <LM>w#w-d1e279-x2-1048</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1049">
  <m id="m773-d1t288-3">
   <w.rf>
    <LM>w#w-d1t288-3</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d-id64526">
   <w.rf>
    <LM>w#w-d-id64526</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t288-5">
   <w.rf>
    <LM>w#w-d1t288-5</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t288-6">
   <w.rf>
    <LM>w#w-d1t288-6</LM>
   </w.rf>
   <form>nějakými</form>
   <lemma>nějaký</lemma>
   <tag>PZXP7----------</tag>
  </m>
  <m id="m773-d1t288-7">
   <w.rf>
    <LM>w#w-d1t288-7</LM>
   </w.rf>
   <form>kameny</form>
   <lemma>kámen</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m773-d-id64582">
   <w.rf>
    <LM>w#w-d-id64582</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t290-1">
   <w.rf>
    <LM>w#w-d1t290-1</LM>
   </w.rf>
   <form>kalhoty</form>
   <lemma>kalhoty</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m773-d1t290-2">
   <w.rf>
    <LM>w#w-d1t290-2</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t290-3">
   <w.rf>
    <LM>w#w-d1t290-3</LM>
   </w.rf>
   <form>pásku</form>
   <lemma>pásek-1_^(opasek;;proužek;_do_stroje;_magnetofonový)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m773-1049-1109">
   <w.rf>
    <LM>w#w-1049-1109</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t290-4">
   <w.rf>
    <LM>w#w-d1t290-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t290-5">
   <w.rf>
    <LM>w#w-d1t290-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t290-6">
   <w.rf>
    <LM>w#w-d1t290-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t290-7">
   <w.rf>
    <LM>w#w-d1t290-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-1049-1110">
   <w.rf>
    <LM>w#w-1049-1110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
