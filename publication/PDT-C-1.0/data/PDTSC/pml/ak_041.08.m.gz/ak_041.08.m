<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_041.08.w.gz" />
  </references>
 </head>
 <s id="m041-409">
  <m id="m041-d1t2651-1">
   <w.rf>
    <LM>w#w-d1t2651-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m041-d1t2651-2">
   <w.rf>
    <LM>w#w-d1t2651-2</LM>
   </w.rf>
   <form>jdete</form>
   <lemma>jít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m041-d1t2651-5">
   <w.rf>
    <LM>w#w-d1t2651-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2651-6">
   <w.rf>
    <LM>w#w-d1t2651-6</LM>
   </w.rf>
   <form>schodů</form>
   <lemma>schod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m041-d-id139279-punct">
   <w.rf>
    <LM>w#w-d-id139279-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2651-8">
   <w.rf>
    <LM>w#w-d1t2651-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m041-d1t2651-9">
   <w.rf>
    <LM>w#w-d1t2651-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2651-10">
   <w.rf>
    <LM>w#w-d1t2651-10</LM>
   </w.rf>
   <form>udýcháte</form>
   <lemma>udýchat</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m041-409-410">
   <w.rf>
    <LM>w#w-409-410</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-411">
  <m id="m041-d1t2651-14">
   <w.rf>
    <LM>w#w-d1t2651-14</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2651-15">
   <w.rf>
    <LM>w#w-d1t2651-15</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m041-d1t2651-13">
   <w.rf>
    <LM>w#w-d1t2651-13</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2651-16">
   <w.rf>
    <LM>w#w-d1t2651-16</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m041-d1t2651-17">
   <w.rf>
    <LM>w#w-d1t2651-17</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m041-411-412">
   <w.rf>
    <LM>w#w-411-412</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-413">
  <m id="m041-d1t2654-4">
   <w.rf>
    <LM>w#w-d1t2654-4</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m041-d1t2654-3">
   <w.rf>
    <LM>w#w-d1t2654-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2654-6">
   <w.rf>
    <LM>w#w-d1t2654-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m041-d1t2654-7">
   <w.rf>
    <LM>w#w-d1t2654-7</LM>
   </w.rf>
   <form>sto</form>
   <lemma>sto-1`100</lemma>
   <tag>CzNS4----------</tag>
  </m>
  <m id="m041-d1t2654-8">
   <w.rf>
    <LM>w#w-d1t2654-8</LM>
   </w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m041-d1t2654-9">
   <w.rf>
    <LM>w#w-d1t2654-9</LM>
   </w.rf>
   <form>dál</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m041-d1t2654-10">
   <w.rf>
    <LM>w#w-d1t2654-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2654-11">
   <w.rf>
    <LM>w#w-d1t2654-11</LM>
   </w.rf>
   <form>jiných</form>
   <lemma>jiný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m041-d1t2654-12">
   <w.rf>
    <LM>w#w-d1t2654-12</LM>
   </w.rf>
   <form>baráků</form>
   <lemma>barák</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m041-d1t2654-13">
   <w.rf>
    <LM>w#w-d1t2654-13</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m041-d1t2654-14">
   <w.rf>
    <LM>w#w-d1t2654-14</LM>
   </w.rf>
   <form>várnice</form>
   <lemma>várnice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m041-d-id139642-punct">
   <w.rf>
    <LM>w#w-d-id139642-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2656-1">
   <w.rf>
    <LM>w#w-d1t2656-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m041-d1t2656-2">
   <w.rf>
    <LM>w#w-d1t2656-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m041-d1t2656-5">
   <w.rf>
    <LM>w#w-d1t2656-5</LM>
   </w.rf>
   <form>ošetřovatelky</form>
   <lemma>ošetřovatelka_^(*2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m041-d1t2656-3">
   <w.rf>
    <LM>w#w-d1t2656-3</LM>
   </w.rf>
   <form>roztřídily</form>
   <lemma>roztřídit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m041-d1t2658-1">
   <w.rf>
    <LM>w#w-d1t2658-1</LM>
   </w.rf>
   <form>večeře</form>
   <lemma>večeře</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m041-413-414">
   <w.rf>
    <LM>w#w-413-414</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-415">
  <m id="m041-d1t2660-2">
   <w.rf>
    <LM>w#w-d1t2660-2</LM>
   </w.rf>
   <form>Kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m041-d1t2660-3">
   <w.rf>
    <LM>w#w-d1t2660-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2660-4">
   <w.rf>
    <LM>w#w-d1t2660-4</LM>
   </w.rf>
   <form>schovávali</form>
   <lemma>schovávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m041-d1t2662-1">
   <w.rf>
    <LM>w#w-d1t2662-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2662-2">
   <w.rf>
    <LM>w#w-d1t2662-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m041-d1t2662-3">
   <w.rf>
    <LM>w#w-d1t2662-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2662-4">
   <w.rf>
    <LM>w#w-d1t2662-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2662-5">
   <w.rf>
    <LM>w#w-d1t2662-5</LM>
   </w.rf>
   <form>hlásil</form>
   <lemma>hlásit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-415-417">
   <w.rf>
    <LM>w#w-415-417</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-415-418">
   <w.rf>
    <LM>w#w-415-418</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2662-8">
   <w.rf>
    <LM>w#w-d1t2662-8</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m041-d1t2662-9">
   <w.rf>
    <LM>w#w-d1t2662-9</LM>
   </w.rf>
   <form>půjdu</form>
   <lemma>jít</lemma>
   <tag>VB-S---1F-AAI--</tag>
  </m>
  <m id="m041-d1e2614-x4-432">
   <w.rf>
    <LM>w#w-d1e2614-x4-432</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1e2614-x4-433">
   <w.rf>
    <LM>w#w-d1e2614-x4-433</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-434">
  <m id="m041-d1t2662-13">
   <w.rf>
    <LM>w#w-d1t2662-13</LM>
   </w.rf>
   <form>Prošel</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m041-d1t2662-11">
   <w.rf>
    <LM>w#w-d1t2662-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2662-12">
   <w.rf>
    <LM>w#w-d1t2662-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-434-449">
   <w.rf>
    <LM>w#w-434-449</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-451">
  <m id="m041-d1t2664-2">
   <w.rf>
    <LM>w#w-d1t2664-2</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2664-3">
   <w.rf>
    <LM>w#w-d1t2664-3</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m041-d1t2664-4">
   <w.rf>
    <LM>w#w-d1t2664-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m041-d1t2664-5">
   <w.rf>
    <LM>w#w-d1t2664-5</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m041-d1t2664-6">
   <w.rf>
    <LM>w#w-d1t2664-6</LM>
   </w.rf>
   <form>udělat</form>
   <lemma>udělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m041-451-452">
   <w.rf>
    <LM>w#w-451-452</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-453">
  <m id="m041-d1t2669-2">
   <w.rf>
    <LM>w#w-d1t2669-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2669-3">
   <w.rf>
    <LM>w#w-d1t2669-3</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2671-1">
   <w.rf>
    <LM>w#w-d1t2671-1</LM>
   </w.rf>
   <form>srovnat</form>
   <lemma>srovnat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m041-d1t2671-2">
   <w.rf>
    <LM>w#w-d1t2671-2</LM>
   </w.rf>
   <form>archiv</form>
   <lemma>archiv</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m041-d-id140326-punct">
   <w.rf>
    <LM>w#w-d-id140326-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2673-3">
   <w.rf>
    <LM>w#w-d1t2673-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2673-4">
   <w.rf>
    <LM>w#w-d1t2673-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2673-5">
   <w.rf>
    <LM>w#w-d1t2673-5</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m041-d1t2673-6">
   <w.rf>
    <LM>w#w-d1t2673-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2673-7">
   <w.rf>
    <LM>w#w-d1t2673-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m041-d1t2673-9">
   <w.rf>
    <LM>w#w-d1t2673-9</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m041-d1t2673-10">
   <w.rf>
    <LM>w#w-d1t2673-10</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m041-d1t2673-11">
   <w.rf>
    <LM>w#w-d1t2673-11</LM>
   </w.rf>
   <form>srovnal</form>
   <lemma>srovnat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m041-d1t2673-13">
   <w.rf>
    <LM>w#w-d1t2673-13</LM>
   </w.rf>
   <form>archiv</form>
   <lemma>archiv</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m041-453-459">
   <w.rf>
    <LM>w#w-453-459</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-460">
  <m id="m041-d1t2675-2">
   <w.rf>
    <LM>w#w-d1t2675-2</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m041-d1t2675-3">
   <w.rf>
    <LM>w#w-d1t2675-3</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2675-5">
   <w.rf>
    <LM>w#w-d1t2675-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2675-6">
   <w.rf>
    <LM>w#w-d1t2675-6</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m041-d1t2675-7">
   <w.rf>
    <LM>w#w-d1t2675-7</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m041-d1t2675-12">
   <w.rf>
    <LM>w#w-d1t2675-12</LM>
   </w.rf>
   <form>hlásil</form>
   <lemma>hlásit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-460-461">
   <w.rf>
    <LM>w#w-460-461</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-462">
  <m id="m041-d1t2680-3">
   <w.rf>
    <LM>w#w-d1t2680-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m041-d1t2680-4">
   <w.rf>
    <LM>w#w-d1t2680-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2680-5">
   <w.rf>
    <LM>w#w-d1t2680-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2680-7">
   <w.rf>
    <LM>w#w-d1t2680-7</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m041-462-463">
   <w.rf>
    <LM>w#w-462-463</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2680-9">
   <w.rf>
    <LM>w#w-d1t2680-9</LM>
   </w.rf>
   <form>povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m041-462-464">
   <w.rf>
    <LM>w#w-462-464</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-462-465">
   <w.rf>
    <LM>w#w-462-465</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2680-10">
   <w.rf>
    <LM>w#w-d1t2680-10</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ty</lemma>
   <tag>PP-S1--2-------</tag>
  </m>
  <m id="m041-d1t2680-11">
   <w.rf>
    <LM>w#w-d1t2680-11</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2682-1">
   <w.rf>
    <LM>w#w-d1t2682-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2682-2">
   <w.rf>
    <LM>w#w-d1t2682-2</LM>
   </w.rf>
   <form>dolu</form>
   <lemma>důl</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m041-d1t2682-3">
   <w.rf>
    <LM>w#w-d1t2682-3</LM>
   </w.rf>
   <form>nepůjdeš</form>
   <lemma>jít</lemma>
   <tag>VB-S---2F-NAI--</tag>
  </m>
  <m id="m041-462-470">
   <w.rf>
    <LM>w#w-462-470</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-468-469">
   <w.rf>
    <LM>w#w-468-469</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ty</lemma>
   <tag>PP-S1--2-------</tag>
  </m>
  <m id="m041-d1t2682-6">
   <w.rf>
    <LM>w#w-d1t2682-6</LM>
   </w.rf>
   <form>máš</form>
   <lemma>mít</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="m041-d1t2682-5">
   <w.rf>
    <LM>w#w-d1t2682-5</LM>
   </w.rf>
   <form>plíce</form>
   <lemma>plíce</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m041-d1t2682-7">
   <w.rf>
    <LM>w#w-d1t2682-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m041-d1t2682-8">
   <w.rf>
    <LM>w#w-d1t2682-8</LM>
   </w.rf>
   <form>trapu</form>
   <lemma>trap-2_,h_^(být_v_trapu,_být_pryč)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m041-468-471">
   <w.rf>
    <LM>w#w-468-471</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-472">
  <m id="m041-d1t2682-11">
   <w.rf>
    <LM>w#w-d1t2682-11</LM>
   </w.rf>
   <form>Kdyby</form>
   <lemma>kdyby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m041-d1t2682-12">
   <w.rf>
    <LM>w#w-d1t2682-12</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="m041-d1t2682-13">
   <w.rf>
    <LM>w#w-d1t2682-13</LM>
   </w.rf>
   <form>nutili</form>
   <lemma>nutit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m041-d-id141050-punct">
   <w.rf>
    <LM>w#w-d-id141050-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2682-16">
   <w.rf>
    <LM>w#w-d1t2682-16</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m041-d1t2682-17">
   <w.rf>
    <LM>w#w-d1t2682-17</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m041-d1e2614-x5-485">
   <w.rf>
    <LM>w#w-d1e2614-x5-485</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1e2614-x5-486">
   <w.rf>
    <LM>w#w-d1e2614-x5-486</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-487">
  <m id="m041-d1t2686-5">
   <w.rf>
    <LM>w#w-d1t2686-5</LM>
   </w.rf>
   <form>Vrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m041-d1t2686-3">
   <w.rf>
    <LM>w#w-d1t2686-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2686-4">
   <w.rf>
    <LM>w#w-d1t2686-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2686-6">
   <w.rf>
    <LM>w#w-d1t2686-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2686-9">
   <w.rf>
    <LM>w#w-d1t2686-9</LM>
   </w.rf>
   <form>Ostravy</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m041-487-495">
   <w.rf>
    <LM>w#w-487-495</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2686-12">
   <w.rf>
    <LM>w#w-d1t2686-12</LM>
   </w.rf>
   <form>Radvanic</form>
   <lemma>Radvanice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m041-487-496">
   <w.rf>
    <LM>w#w-487-496</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-498">
  <m id="m041-d1t2688-9">
   <w.rf>
    <LM>w#w-d1t2688-9</LM>
   </w.rf>
   <form>Náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m041-d1t2690-1">
   <w.rf>
    <LM>w#w-d1t2690-1</LM>
   </w.rf>
   <form>tatíček</form>
   <lemma>tatíček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-d1t2690-3">
   <w.rf>
    <LM>w#w-d1t2690-3</LM>
   </w.rf>
   <form>Sebera</form>
   <lemma>Sebera_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-d1t2688-3">
   <w.rf>
    <LM>w#w-d1t2688-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m041-d1t2688-4">
   <w.rf>
    <LM>w#w-d1t2688-4</LM>
   </w.rf>
   <form>sehnal</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m041-d1t2688-5">
   <w.rf>
    <LM>w#w-d1t2688-5</LM>
   </w.rf>
   <form>podplukovníka</form>
   <lemma>podplukovník</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m041-498-748">
   <w.rf>
    <LM>w#w-498-748</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2688-6">
   <w.rf>
    <LM>w#w-d1t2688-6</LM>
   </w.rf>
   <form>velitele</form>
   <lemma>velitel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m041-d1t2688-7">
   <w.rf>
    <LM>w#w-d1t2688-7</LM>
   </w.rf>
   <form>praporu</form>
   <lemma>prapor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m041-498-499">
   <w.rf>
    <LM>w#w-498-499</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-500">
  <m id="m041-d1t2690-6">
   <w.rf>
    <LM>w#w-d1t2690-6</LM>
   </w.rf>
   <form>Říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-500-502">
   <w.rf>
    <LM>w#w-500-502</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-500-501">
   <w.rf>
    <LM>w#w-500-501</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2690-7">
   <w.rf>
    <LM>w#w-d1t2690-7</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m041-d1t2690-8">
   <w.rf>
    <LM>w#w-d1t2690-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2690-9">
   <w.rf>
    <LM>w#w-d1t2690-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m041-d1t2690-10">
   <w.rf>
    <LM>w#w-d1t2690-10</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m041-d1t2690-11">
   <w.rf>
    <LM>w#w-d1t2690-11</LM>
   </w.rf>
   <form>tatíček</form>
   <lemma>tatíček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-500-503">
   <w.rf>
    <LM>w#w-500-503</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2690-14">
   <w.rf>
    <LM>w#w-d1t2690-14</LM>
   </w.rf>
   <form>musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2690-13">
   <w.rf>
    <LM>w#w-d1t2690-13</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m041-d1t2693-1">
   <w.rf>
    <LM>w#w-d1t2693-1</LM>
   </w.rf>
   <form>převychovat</form>
   <lemma>převychovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m041-500-504">
   <w.rf>
    <LM>w#w-500-504</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-505-506">
   <w.rf>
    <LM>w#w-505-506</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-505">
  <m id="m041-d1t2693-4">
   <w.rf>
    <LM>w#w-d1t2693-4</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2693-5">
   <w.rf>
    <LM>w#w-d1t2693-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m041-d1t2693-6">
   <w.rf>
    <LM>w#w-d1t2693-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2693-3">
   <w.rf>
    <LM>w#w-d1t2693-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2693-7">
   <w.rf>
    <LM>w#w-d1t2693-7</LM>
   </w.rf>
   <form>parchant</form>
   <lemma>parchant_,v</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-505-507">
   <w.rf>
    <LM>w#w-505-507</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2693-9">
   <w.rf>
    <LM>w#w-d1t2693-9</LM>
   </w.rf>
   <form>mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m041-505-508">
   <w.rf>
    <LM>w#w-505-508</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m041-d1t2693-8">
   <w.rf>
    <LM>w#w-d1t2693-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2693-10">
   <w.rf>
    <LM>w#w-d1t2693-10</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m041-d-m-d1e2614-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2614-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-d1e2704-x2">
  <m id="m041-d1t2707-3">
   <w.rf>
    <LM>w#w-d1t2707-3</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m041-d1t2707-4">
   <w.rf>
    <LM>w#w-d1t2707-4</LM>
   </w.rf>
   <form>nějakým</form>
   <lemma>nějaký</lemma>
   <tag>PZZS7----------</tag>
  </m>
  <m id="m041-d1t2707-6">
   <w.rf>
    <LM>w#w-d1t2707-6</LM>
   </w.rf>
   <form>Zajíčkem</form>
   <lemma>Zajíček_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m041-d1t2707-8">
   <w.rf>
    <LM>w#w-d1t2707-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2707-10">
   <w.rf>
    <LM>w#w-d1t2707-10</LM>
   </w.rf>
   <form>Roudnice</form>
   <lemma>Roudnice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m041-d1t2707-12">
   <w.rf>
    <LM>w#w-d1t2707-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2707-13">
   <w.rf>
    <LM>w#w-d1t2707-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2707-14">
   <w.rf>
    <LM>w#w-d1t2707-14</LM>
   </w.rf>
   <form>stáli</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m041-d1t2707-15">
   <w.rf>
    <LM>w#w-d1t2707-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m041-d1t2707-16">
   <w.rf>
    <LM>w#w-d1t2707-16</LM>
   </w.rf>
   <form>pozoru</form>
   <lemma>pozor-2</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m041-d1e2704-x2-521">
   <w.rf>
    <LM>w#w-d1e2704-x2-521</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m041-d1t2709-2">
   <w.rf>
    <LM>w#w-d1t2709-2</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m041-d1t2709-3">
   <w.rf>
    <LM>w#w-d1t2709-3</LM>
   </w.rf>
   <form>hodiny</form>
   <lemma>hodina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m041-d1e2704-x2-522">
   <w.rf>
    <LM>w#w-d1e2704-x2-522</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-524">
  <m id="m041-d1t2709-5">
   <w.rf>
    <LM>w#w-d1t2709-5</LM>
   </w.rf>
   <form>Furt</form>
   <lemma>furt_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-524-525">
   <w.rf>
    <LM>w#w-524-525</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m041-d1t2709-6">
   <w.rf>
    <LM>w#w-d1t2709-6</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m041-524-526">
   <w.rf>
    <LM>w#w-524-526</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-524-527">
   <w.rf>
    <LM>w#w-524-527</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2709-7">
   <w.rf>
    <LM>w#w-d1t2709-7</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m041-d1t2709-8">
   <w.rf>
    <LM>w#w-d1t2709-8</LM>
   </w.rf>
   <form>půjdete</form>
   <lemma>jít</lemma>
   <tag>VB-P---2F-AAI--</tag>
  </m>
  <m id="m041-d1t2709-9">
   <w.rf>
    <LM>w#w-d1t2709-9</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m041-524-528">
   <w.rf>
    <LM>w#w-524-528</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-524-529">
   <w.rf>
    <LM>w#w-524-529</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-530">
  <m id="m041-530-535">
   <w.rf>
    <LM>w#w-530-535</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2711-3">
   <w.rf>
    <LM>w#w-d1t2711-3</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m041-530-531">
   <w.rf>
    <LM>w#w-530-531</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2711-1">
   <w.rf>
    <LM>w#w-d1t2711-1</LM>
   </w.rf>
   <form>nepůjdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1F-NAI--</tag>
  </m>
  <m id="m041-d1t2711-2">
   <w.rf>
    <LM>w#w-d1t2711-2</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m041-530-532">
   <w.rf>
    <LM>w#w-530-532</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-530-534">
   <w.rf>
    <LM>w#w-530-534</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-533">
  <m id="m041-533-544">
   <w.rf>
    <LM>w#w-533-544</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-533-545">
   <w.rf>
    <LM>w#w-533-545</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2713-2">
   <w.rf>
    <LM>w#w-d1t2713-2</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m041-d1t2713-3">
   <w.rf>
    <LM>w#w-d1t2713-3</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m041-d1t2713-4">
   <w.rf>
    <LM>w#w-d1t2713-4</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m041-533-546">
   <w.rf>
    <LM>w#w-533-546</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-533-547">
   <w.rf>
    <LM>w#w-533-547</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2713-5">
   <w.rf>
    <LM>w#w-d1t2713-5</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m041-d1t2713-6">
   <w.rf>
    <LM>w#w-d1t2713-6</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m041-d1t2713-7">
   <w.rf>
    <LM>w#w-d1t2713-7</LM>
   </w.rf>
   <form>podplukovník</form>
   <lemma>podplukovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-533-548">
   <w.rf>
    <LM>w#w-533-548</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-533-549">
   <w.rf>
    <LM>w#w-533-549</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2713-8">
   <w.rf>
    <LM>w#w-d1t2713-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2713-9">
   <w.rf>
    <LM>w#w-d1t2713-9</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m041-533-552">
   <w.rf>
    <LM>w#w-533-552</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2713-10">
   <w.rf>
    <LM>w#w-d1t2713-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m041-d1t2713-11">
   <w.rf>
    <LM>w#w-d1t2713-11</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m041-d1t2713-12">
   <w.rf>
    <LM>w#w-d1t2713-12</LM>
   </w.rf>
   <form>budete</form>
   <lemma>být</lemma>
   <tag>VB-P---2F-AAI--</tag>
  </m>
  <m id="m041-d1t2713-13">
   <w.rf>
    <LM>w#w-d1t2713-13</LM>
   </w.rf>
   <form>koukat</form>
   <lemma>koukat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m041-533-550">
   <w.rf>
    <LM>w#w-533-550</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-533-551">
   <w.rf>
    <LM>w#w-533-551</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-553">
  <m id="m041-553-556">
   <w.rf>
    <LM>w#w-553-556</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2718-2">
   <w.rf>
    <LM>w#w-d1t2718-2</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m041-553-554">
   <w.rf>
    <LM>w#w-553-554</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2718-3">
   <w.rf>
    <LM>w#w-d1t2718-3</LM>
   </w.rf>
   <form>nepůjdu</form>
   <lemma>jít</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m041-d1t2718-4">
   <w.rf>
    <LM>w#w-d1t2718-4</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m041-553-564">
   <w.rf>
    <LM>w#w-553-564</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-565">
  <m id="m041-d1t2718-5">
   <w.rf>
    <LM>w#w-d1t2718-5</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m041-d1t2718-6">
   <w.rf>
    <LM>w#w-d1t2718-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m041-d1t2718-7">
   <w.rf>
    <LM>w#w-d1t2718-7</LM>
   </w.rf>
   <form>doktor</form>
   <lemma>doktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-d1t2718-9">
   <w.rf>
    <LM>w#w-d1t2718-9</LM>
   </w.rf>
   <form>Skopňa</form>
   <lemma>Skopňa_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-d1t2718-11">
   <w.rf>
    <LM>w#w-d1t2718-11</LM>
   </w.rf>
   <form>zakázal</form>
   <lemma>zakázat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m041-553-558">
   <w.rf>
    <LM>w#w-553-558</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-553-560">
   <w.rf>
    <LM>w#w-553-560</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-559">
  <m id="m041-d1t2718-13">
   <w.rf>
    <LM>w#w-d1t2718-13</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m041-d1t2718-14">
   <w.rf>
    <LM>w#w-d1t2718-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2720-1">
   <w.rf>
    <LM>w#w-d1t2720-1</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m041-559-783">
   <w.rf>
    <LM>w#w-559-783</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2720-2">
   <w.rf>
    <LM>w#w-d1t2720-2</LM>
   </w.rf>
   <form>doktor</form>
   <lemma>doktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-d1t2720-4">
   <w.rf>
    <LM>w#w-d1t2720-4</LM>
   </w.rf>
   <form>Skopňa</form>
   <lemma>Skopňa_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-d1t2720-6">
   <w.rf>
    <LM>w#w-d1t2720-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2720-8">
   <w.rf>
    <LM>w#w-d1t2720-8</LM>
   </w.rf>
   <form>Ružomberoku</form>
   <lemma>Ružomberok_;G</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m041-559-784">
   <w.rf>
    <LM>w#w-559-784</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-559-582">
   <w.rf>
    <LM>w#w-559-582</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2720-10">
   <w.rf>
    <LM>w#w-d1t2720-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2720-11">
   <w.rf>
    <LM>w#w-d1t2720-11</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m041-d1t2720-12">
   <w.rf>
    <LM>w#w-d1t2720-12</LM>
   </w.rf>
   <form>řečech</form>
   <lemma>řeč</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m041-559-583">
   <w.rf>
    <LM>w#w-559-583</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-592">
  <m id="m041-d1t2722-1">
   <w.rf>
    <LM>w#w-d1t2722-1</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m041-d1t2722-2">
   <w.rf>
    <LM>w#w-d1t2722-2</LM>
   </w.rf>
   <form>velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-d1t2722-3">
   <w.rf>
    <LM>w#w-d1t2722-3</LM>
   </w.rf>
   <form>praporu</form>
   <lemma>prapor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m041-d1t2722-6">
   <w.rf>
    <LM>w#w-d1t2722-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2722-7">
   <w.rf>
    <LM>w#w-d1t2722-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2722-8">
   <w.rf>
    <LM>w#w-d1t2722-8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m041-d1t2722-9">
   <w.rf>
    <LM>w#w-d1t2722-9</LM>
   </w.rf>
   <form>alkoholik</form>
   <lemma>alkoholik</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-d1t2722-10">
   <w.rf>
    <LM>w#w-d1t2722-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m041-d1t2722-11">
   <w.rf>
    <LM>w#w-d1t2722-11</LM>
   </w.rf>
   <form>léčení</form>
   <lemma>léčení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m041-d1t2724-1">
   <w.rf>
    <LM>w#w-d1t2724-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2724-3">
   <w.rf>
    <LM>w#w-d1t2724-3</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2724-4">
   <w.rf>
    <LM>w#w-d1t2724-4</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m041-d1t2724-7">
   <w.rf>
    <LM>w#w-d1t2724-7</LM>
   </w.rf>
   <form>Skopni</form>
   <lemma>Skopňa_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m041-d1t2724-9">
   <w.rf>
    <LM>w#w-d1t2724-9</LM>
   </w.rf>
   <form>strach</form>
   <lemma>strach</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m041-d-m-d1e2704-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2704-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-d1e2725-x2">
  <m id="m041-d1t2730-1">
   <w.rf>
    <LM>w#w-d1t2730-1</LM>
   </w.rf>
   <form>Otočil</form>
   <lemma>otočit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m041-d1t2730-2">
   <w.rf>
    <LM>w#w-d1t2730-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2730-3">
   <w.rf>
    <LM>w#w-d1t2730-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m041-d1t2730-4">
   <w.rf>
    <LM>w#w-d1t2730-4</LM>
   </w.rf>
   <form>kramfleku</form>
   <lemma>kramflek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m041-d1e2725-x2-607">
   <w.rf>
    <LM>w#w-d1e2725-x2-607</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2730-6">
   <w.rf>
    <LM>w#w-d1t2730-6</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2730-7">
   <w.rf>
    <LM>w#w-d1t2730-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2730-8">
   <w.rf>
    <LM>w#w-d1t2730-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m041-d1t2730-9">
   <w.rf>
    <LM>w#w-d1t2730-9</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m041-d1t2730-10">
   <w.rf>
    <LM>w#w-d1t2730-10</LM>
   </w.rf>
   <form>nebavil</form>
   <lemma>bavit</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m041-d1t2740-1">
   <w.rf>
    <LM>w#w-d1t2740-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2740-2">
   <w.rf>
    <LM>w#w-d1t2740-2</LM>
   </w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2740-3">
   <w.rf>
    <LM>w#w-d1t2740-3</LM>
   </w.rf>
   <form>týdne</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m041-d1t2740-4">
   <w.rf>
    <LM>w#w-d1t2740-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2740-5">
   <w.rf>
    <LM>w#w-d1t2740-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2740-6">
   <w.rf>
    <LM>w#w-d1t2740-6</LM>
   </w.rf>
   <form>stěhoval</form>
   <lemma>stěhovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2742-1">
   <w.rf>
    <LM>w#w-d1t2742-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2742-3">
   <w.rf>
    <LM>w#w-d1t2742-3</LM>
   </w.rf>
   <form>Milovic</form>
   <lemma>Milovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m041-d1e2735-x2-623">
   <w.rf>
    <LM>w#w-d1e2735-x2-623</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-624">
  <m id="m041-d1t2742-6">
   <w.rf>
    <LM>w#w-d1t2742-6</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m041-d1t2742-7">
   <w.rf>
    <LM>w#w-d1t2742-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m041-d1t2742-8">
   <w.rf>
    <LM>w#w-d1t2742-8</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2742-10">
   <w.rf>
    <LM>w#w-d1t2742-10</LM>
   </w.rf>
   <form>Nymburka</form>
   <lemma>Nymburk_;G</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m041-624-625">
   <w.rf>
    <LM>w#w-624-625</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2742-12">
   <w.rf>
    <LM>w#w-d1t2742-12</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2742-14">
   <w.rf>
    <LM>w#w-d1t2742-14</LM>
   </w.rf>
   <form>Lysé</form>
   <lemma>Lysá_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m041-624-626">
   <w.rf>
    <LM>w#w-624-626</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-627">
  <m id="m041-d1t2744-1">
   <w.rf>
    <LM>w#w-d1t2744-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2744-2">
   <w.rf>
    <LM>w#w-d1t2744-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2744-3">
   <w.rf>
    <LM>w#w-d1t2744-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2744-4">
   <w.rf>
    <LM>w#w-d1t2744-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m041-d1t2744-5">
   <w.rf>
    <LM>w#w-d1t2744-5</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m041-d-id143860-punct">
   <w.rf>
    <LM>w#w-d-id143860-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2744-7">
   <w.rf>
    <LM>w#w-d1t2744-7</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m041-d1t2744-8">
   <w.rf>
    <LM>w#w-d1t2744-8</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m041-d1t2749-1">
   <w.rf>
    <LM>w#w-d1t2749-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2749-2">
   <w.rf>
    <LM>w#w-d1t2749-2</LM>
   </w.rf>
   <form>odtamtud</form>
   <lemma>odtamtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2749-4">
   <w.rf>
    <LM>w#w-d1t2749-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m041-d1t2749-5">
   <w.rf>
    <LM>w#w-d1t2749-5</LM>
   </w.rf>
   <form>poslali</form>
   <lemma>poslat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m041-d1t2749-6">
   <w.rf>
    <LM>w#w-d1t2749-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2749-8">
   <w.rf>
    <LM>w#w-d1t2749-8</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m041-d1t2751-2">
   <w.rf>
    <LM>w#w-d1t2751-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2751-4">
   <w.rf>
    <LM>w#w-d1t2751-4</LM>
   </w.rf>
   <form>Bubenče</form>
   <lemma>Bubeneč-1_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m041-d1t2751-6">
   <w.rf>
    <LM>w#w-d1t2751-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2751-7">
   <w.rf>
    <LM>w#w-d1t2751-7</LM>
   </w.rf>
   <form>skladu</form>
   <lemma>sklad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m041-627-628">
   <w.rf>
    <LM>w#w-627-628</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-631">
  <m id="m041-d1t2751-11">
   <w.rf>
    <LM>w#w-d1t2751-11</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2751-12">
   <w.rf>
    <LM>w#w-d1t2751-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2751-13">
   <w.rf>
    <LM>w#w-d1t2751-13</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m041-d1t2751-14">
   <w.rf>
    <LM>w#w-d1t2751-14</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m041-631-830">
   <w.rf>
    <LM>w#w-631-830</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-843">
  <m id="m041-631-831">
   <w.rf>
    <LM>w#w-631-831</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m041-631-832">
   <w.rf>
    <LM>w#w-631-832</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m041-631-833">
   <w.rf>
    <LM>w#w-631-833</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-631-834">
   <w.rf>
    <LM>w#w-631-834</LM>
   </w.rf>
   <form>vzpomene</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m041-631-842">
   <w.rf>
    <LM>w#w-631-842</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-631-835">
   <w.rf>
    <LM>w#w-631-835</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m041-631-836">
   <w.rf>
    <LM>w#w-631-836</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m041-631-837">
   <w.rf>
    <LM>w#w-631-837</LM>
   </w.rf>
   <form>uprostřed</form>
   <lemma>uprostřed-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-631-838">
   <w.rf>
    <LM>w#w-631-838</LM>
   </w.rf>
   <form>polí</form>
   <lemma>pole</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m041-631-839">
   <w.rf>
    <LM>w#w-631-839</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m041-631-840">
   <w.rf>
    <LM>w#w-631-840</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-631-841">
   <w.rf>
    <LM>w#w-631-841</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-631-635">
   <w.rf>
    <LM>w#w-631-635</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-d1e2735-x3">
  <m id="m041-d1t2759-3">
   <w.rf>
    <LM>w#w-d1t2759-3</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m041-d1t2759-4">
   <w.rf>
    <LM>w#w-d1t2759-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m041-d1t2759-5">
   <w.rf>
    <LM>w#w-d1t2759-5</LM>
   </w.rf>
   <form>skladu</form>
   <lemma>sklad</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m041-d1t2759-6">
   <w.rf>
    <LM>w#w-d1t2759-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2759-7">
   <w.rf>
    <LM>w#w-d1t2759-7</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m041-d1t2762-7">
   <w.rf>
    <LM>w#w-d1t2762-7</LM>
   </w.rf>
   <form>kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2762-8">
   <w.rf>
    <LM>w#w-d1t2762-8</LM>
   </w.rf>
   <form>ošacení</form>
   <lemma>ošacení_^(*4tit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m041-d1e2735-x3-664">
   <w.rf>
    <LM>w#w-d1e2735-x3-664</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2762-1">
   <w.rf>
    <LM>w#w-d1t2762-1</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2762-2">
   <w.rf>
    <LM>w#w-d1t2762-2</LM>
   </w.rf>
   <form>cihly</form>
   <lemma>cihla</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m041-d-id144653-punct">
   <w.rf>
    <LM>w#w-d-id144653-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2762-4">
   <w.rf>
    <LM>w#w-d1t2762-4</LM>
   </w.rf>
   <form>cementu</form>
   <lemma>cement</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m041-d1t2762-5">
   <w.rf>
    <LM>w#w-d1t2762-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m041-d1t2762-6">
   <w.rf>
    <LM>w#w-d1t2762-6</LM>
   </w.rf>
   <form>nábytek</form>
   <lemma>nábytek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m041-d1e2735-x3-666">
   <w.rf>
    <LM>w#w-d1e2735-x3-666</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-667">
  <m id="m041-d1t2764-2">
   <w.rf>
    <LM>w#w-d1t2764-2</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m041-d-id144811-punct">
   <w.rf>
    <LM>w#w-d-id144811-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2764-6">
   <w.rf>
    <LM>w#w-d1t2764-6</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m041-d1t2764-7">
   <w.rf>
    <LM>w#w-d1t2764-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2764-8">
   <w.rf>
    <LM>w#w-d1t2764-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2764-9">
   <w.rf>
    <LM>w#w-d1t2764-9</LM>
   </w.rf>
   <form>nastěhoval</form>
   <lemma>nastěhovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m041-667-668">
   <w.rf>
    <LM>w#w-667-668</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2764-3">
   <w.rf>
    <LM>w#w-d1t2764-3</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2764-4">
   <w.rf>
    <LM>w#w-d1t2764-4</LM>
   </w.rf>
   <form>přijít</form>
   <lemma>přijít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m041-d1t2766-1">
   <w.rf>
    <LM>w#w-d1t2766-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m041-d1t2766-2">
   <w.rf>
    <LM>w#w-d1t2766-2</LM>
   </w.rf>
   <form>vlastním</form>
   <lemma>vlastní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m041-d1t2766-3">
   <w.rf>
    <LM>w#w-d1t2766-3</LM>
   </w.rf>
   <form>kabátu</form>
   <lemma>kabát</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m041-667-669">
   <w.rf>
    <LM>w#w-667-669</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-670">
  <m id="m041-d1t2766-4">
   <w.rf>
    <LM>w#w-d1t2766-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m041-d1t2766-5">
   <w.rf>
    <LM>w#w-d1t2766-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2766-6">
   <w.rf>
    <LM>w#w-d1t2766-6</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m041-670-671">
   <w.rf>
    <LM>w#w-670-671</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-672">
  <m id="m041-d1t2766-8">
   <w.rf>
    <LM>w#w-d1t2766-8</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2774-1">
   <w.rf>
    <LM>w#w-d1t2774-1</LM>
   </w.rf>
   <form>lavice</form>
   <lemma>lavice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m041-d1e2779-x2-684">
   <w.rf>
    <LM>w#w-d1e2779-x2-684</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2782-1">
   <w.rf>
    <LM>w#w-d1t2782-1</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m041-d1t2782-2">
   <w.rf>
    <LM>w#w-d1t2782-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2782-4">
   <w.rf>
    <LM>w#w-d1t2782-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m041-d1e2779-x2-685">
   <w.rf>
    <LM>w#w-d1e2779-x2-685</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-686">
  <m id="m041-d1t2784-5">
   <w.rf>
    <LM>w#w-d1t2784-5</LM>
   </w.rf>
   <form>Dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m041-d1t2784-3">
   <w.rf>
    <LM>w#w-d1t2784-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2784-4">
   <w.rf>
    <LM>w#w-d1t2784-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2784-6">
   <w.rf>
    <LM>w#w-d1t2784-6</LM>
   </w.rf>
   <form>skladištní</form>
   <lemma>skladištní</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m041-d1t2784-7">
   <w.rf>
    <LM>w#w-d1t2784-7</LM>
   </w.rf>
   <form>dělníky</form>
   <lemma>dělník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m041-686-690">
   <w.rf>
    <LM>w#w-686-690</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2786-1">
   <w.rf>
    <LM>w#w-d1t2786-1</LM>
   </w.rf>
   <form>skladníky</form>
   <lemma>skladník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m041-d1t2786-2">
   <w.rf>
    <LM>w#w-d1t2786-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2786-3">
   <w.rf>
    <LM>w#w-d1t2786-3</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m041-d1t2788-1">
   <w.rf>
    <LM>w#w-d1t2788-1</LM>
   </w.rf>
   <form>civilní</form>
   <lemma>civilní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m041-d1t2788-2">
   <w.rf>
    <LM>w#w-d1t2788-2</LM>
   </w.rf>
   <form>zaměstnanci</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m041-d1t2788-7">
   <w.rf>
    <LM>w#w-d1t2788-7</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m041-d1t2788-8">
   <w.rf>
    <LM>w#w-d1t2788-8</LM>
   </w.rf>
   <form>vojenskou</form>
   <lemma>vojenský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m041-d1t2788-9">
   <w.rf>
    <LM>w#w-d1t2788-9</LM>
   </w.rf>
   <form>správou</form>
   <lemma>správa</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m041-686-692">
   <w.rf>
    <LM>w#w-686-692</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-693">
  <m id="m041-d1t2790-1">
   <w.rf>
    <LM>w#w-d1t2790-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2790-2">
   <w.rf>
    <LM>w#w-d1t2790-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2790-3">
   <w.rf>
    <LM>w#w-d1t2790-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2790-4">
   <w.rf>
    <LM>w#w-d1t2790-4</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m041-d1t2790-5">
   <w.rf>
    <LM>w#w-d1t2790-5</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m041-693-694">
   <w.rf>
    <LM>w#w-693-694</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-695">
  <m id="m041-d1t2790-9">
   <w.rf>
    <LM>w#w-d1t2790-9</LM>
   </w.rf>
   <form>Odtamtud</form>
   <lemma>odtamtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2790-10">
   <w.rf>
    <LM>w#w-d1t2790-10</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m041-d1t2790-11">
   <w.rf>
    <LM>w#w-d1t2790-11</LM>
   </w.rf>
   <form>přemístili</form>
   <lemma>přemístit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m041-d1t2793-1">
   <w.rf>
    <LM>w#w-d1t2793-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2793-2">
   <w.rf>
    <LM>w#w-d1t2793-2</LM>
   </w.rf>
   <form>kněžské</form>
   <lemma>kněžský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m041-d1t2793-3">
   <w.rf>
    <LM>w#w-d1t2793-3</LM>
   </w.rf>
   <form>roty</form>
   <lemma>rota</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m041-d1t2793-4">
   <w.rf>
    <LM>w#w-d1t2793-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2795-2">
   <w.rf>
    <LM>w#w-d1t2795-2</LM>
   </w.rf>
   <form>Střešovic</form>
   <lemma>Střešovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m041-695-696">
   <w.rf>
    <LM>w#w-695-696</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-697">
  <m id="m041-d1t2797-2">
   <w.rf>
    <LM>w#w-d1t2797-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2797-1">
   <w.rf>
    <LM>w#w-d1t2797-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m041-d1t2797-3">
   <w.rf>
    <LM>w#w-d1t2797-3</LM>
   </w.rf>
   <form>samý</form>
   <lemma>samý</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m041-d1t2797-4">
   <w.rf>
    <LM>w#w-d1t2797-4</LM>
   </w.rf>
   <form>farář</form>
   <lemma>farář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m041-d-m-d1e2779-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2779-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-d1e2798-x2">
  <m id="m041-d1t2805-3">
   <w.rf>
    <LM>w#w-d1t2805-3</LM>
   </w.rf>
   <form>Nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m041-d1t2805-4">
   <w.rf>
    <LM>w#w-d1t2805-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2807-1">
   <w.rf>
    <LM>w#w-d1t2807-1</LM>
   </w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m041-d-id146078-punct">
   <w.rf>
    <LM>w#w-d-id146078-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2807-3">
   <w.rf>
    <LM>w#w-d1t2807-3</LM>
   </w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m041-d1t2807-4">
   <w.rf>
    <LM>w#w-d1t2807-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m041-d-m-d1e2798-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2798-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-d1e2814-x2">
  <m id="m041-d1t2819-2">
   <w.rf>
    <LM>w#w-d1t2819-2</LM>
   </w.rf>
   <form>Nejstaršímu</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS3----3A----</tag>
  </m>
  <m id="m041-d1t2819-3">
   <w.rf>
    <LM>w#w-d1t2819-3</LM>
   </w.rf>
   <form>faráři</form>
   <lemma>farář</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m041-d1t2819-4">
   <w.rf>
    <LM>w#w-d1t2819-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2819-5">
   <w.rf>
    <LM>w#w-d1t2819-5</LM>
   </w.rf>
   <form>padesát</form>
   <lemma>padesát`50</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m041-d1e2814-x2-705">
   <w.rf>
    <LM>w#w-d1e2814-x2-705</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-706">
  <m id="m041-d1t2821-1">
   <w.rf>
    <LM>w#w-d1t2821-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2821-2">
   <w.rf>
    <LM>w#w-d1t2821-2</LM>
   </w.rf>
   <form>staří</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m041-d1t2821-3">
   <w.rf>
    <LM>w#w-d1t2821-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2821-4">
   <w.rf>
    <LM>w#w-d1t2821-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m041-d-m-d1e2814-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2814-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-d1e2824-x3">
  <m id="m041-d1t2831-1">
   <w.rf>
    <LM>w#w-d1t2831-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m041-d1t2831-2">
   <w.rf>
    <LM>w#w-d1t2831-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m041-d1t2831-3">
   <w.rf>
    <LM>w#w-d1t2831-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m041-d-m-d1e2824-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2824-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-d1e2832-x2">
  <m id="m041-d1e2832-x2-864">
   <w.rf>
    <LM>w#w-d1e2832-x2-864</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1e2832-x2-739">
   <w.rf>
    <LM>w#w-d1e2832-x2-739</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ty</lemma>
   <tag>PP-S1--2-------</tag>
  </m>
  <m id="m041-d1t2835-1">
   <w.rf>
    <LM>w#w-d1t2835-1</LM>
   </w.rf>
   <form>nebudeš</form>
   <lemma>být</lemma>
   <tag>VB-S---2F-NAI--</tag>
  </m>
  <m id="m041-d1t2835-2">
   <w.rf>
    <LM>w#w-d1t2835-2</LM>
   </w.rf>
   <form>sloužit</form>
   <lemma>sloužit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m041-d1t2835-3">
   <w.rf>
    <LM>w#w-d1t2835-3</LM>
   </w.rf>
   <form>mši</form>
   <lemma>mše</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m041-d-id146630-punct">
   <w.rf>
    <LM>w#w-d-id146630-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1e2832-x2-865">
   <w.rf>
    <LM>w#w-d1e2832-x2-865</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2837-2">
   <w.rf>
    <LM>w#w-d1t2837-2</LM>
   </w.rf>
   <form>půjdeš</form>
   <lemma>jít</lemma>
   <tag>VB-S---2F-AAI--</tag>
  </m>
  <m id="m041-d1t2837-3">
   <w.rf>
    <LM>w#w-d1t2837-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m041-d1t2837-4">
   <w.rf>
    <LM>w#w-d1t2837-4</LM>
   </w.rf>
   <form>vojnu</form>
   <lemma>vojna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m041-d1e2832-x2-740">
   <w.rf>
    <LM>w#w-d1e2832-x2-740</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1e2832-x2-866">
   <w.rf>
    <LM>w#w-d1e2832-x2-866</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-741">
  <m id="m041-d1t2839-5">
   <w.rf>
    <LM>w#w-d1t2839-5</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m041-d1t2839-3">
   <w.rf>
    <LM>w#w-d1t2839-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2839-4">
   <w.rf>
    <LM>w#w-d1t2839-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2839-6">
   <w.rf>
    <LM>w#w-d1t2839-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m041-d1t2839-7">
   <w.rf>
    <LM>w#w-d1t2839-7</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m041-751-754">
   <w.rf>
    <LM>w#w-751-754</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-751-755">
   <w.rf>
    <LM>w#w-751-755</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2841-1">
   <w.rf>
    <LM>w#w-d1t2841-1</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m041-d1t2841-2">
   <w.rf>
    <LM>w#w-d1t2841-2</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2841-4">
   <w.rf>
    <LM>w#w-d1t2841-4</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2841-5">
   <w.rf>
    <LM>w#w-d1t2841-5</LM>
   </w.rf>
   <form>jinde</form>
   <lemma>jinde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-751-752">
   <w.rf>
    <LM>w#w-751-752</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-753">
  <m id="m041-d1t2848-9">
   <w.rf>
    <LM>w#w-d1t2848-9</LM>
   </w.rf>
   <form>Faráři</form>
   <lemma>farář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m041-d1t2846-3">
   <w.rf>
    <LM>w#w-d1t2846-3</LM>
   </w.rf>
   <form>stavěli</form>
   <lemma>stavět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m041-d1t2846-4">
   <w.rf>
    <LM>w#w-d1t2846-4</LM>
   </w.rf>
   <form>nejdřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m041-d1t2846-5">
   <w.rf>
    <LM>w#w-d1t2846-5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m041-d1t2846-7">
   <w.rf>
    <LM>w#w-d1t2846-7</LM>
   </w.rf>
   <form>Stodůlkách</form>
   <lemma>Stodůlky_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m041-d1t2848-4">
   <w.rf>
    <LM>w#w-d1t2848-4</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m041-d1t2848-2">
   <w.rf>
    <LM>w#w-d1t2848-2</LM>
   </w.rf>
   <form>podzemní</form>
   <lemma>podzemní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m041-d1t2848-6">
   <w.rf>
    <LM>w#w-d1t2848-6</LM>
   </w.rf>
   <form>střelecké</form>
   <lemma>střelecký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m041-753-764">
   <w.rf>
    <LM>w#w-753-764</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m041-753-765">
   <w.rf>
    <LM>w#w-753-765</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-766">
  <m id="m041-766-767">
   <w.rf>
    <LM>w#w-766-767</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m041-d1t2850-3">
   <w.rf>
    <LM>w#w-d1t2850-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2850-4">
   <w.rf>
    <LM>w#w-d1t2850-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m041-766-768">
   <w.rf>
    <LM>w#w-766-768</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2850-5">
   <w.rf>
    <LM>w#w-d1t2850-5</LM>
   </w.rf>
   <form>chvíli</form>
   <lemma>chvíle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m041-766-772">
   <w.rf>
    <LM>w#w-766-772</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-773">
  <m id="m041-d1t2850-7">
   <w.rf>
    <LM>w#w-d1t2850-7</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m041-d1t2850-8">
   <w.rf>
    <LM>w#w-d1t2850-8</LM>
   </w.rf>
   <form>chvíli</form>
   <lemma>chvíle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m041-d1t2852-1">
   <w.rf>
    <LM>w#w-d1t2852-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2852-2">
   <w.rf>
    <LM>w#w-d1t2852-2</LM>
   </w.rf>
   <form>začali</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m041-d1t2852-3">
   <w.rf>
    <LM>w#w-d1t2852-3</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m041-d1t2852-4">
   <w.rf>
    <LM>w#w-d1t2852-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m041-d1t2852-6">
   <w.rf>
    <LM>w#w-d1t2852-6</LM>
   </w.rf>
   <form>Bořislávce</form>
   <lemma>Bořislávka_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m041-766-770">
   <w.rf>
    <LM>w#w-766-770</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-771">
  <m id="m041-d1t2852-9">
   <w.rf>
    <LM>w#w-d1t2852-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m041-d1t2852-8">
   <w.rf>
    <LM>w#w-d1t2852-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m041-d1t2852-11">
   <w.rf>
    <LM>w#w-d1t2852-11</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m041-d1t2852-13">
   <w.rf>
    <LM>w#w-d1t2852-13</LM>
   </w.rf>
   <form>Dejvického</form>
   <lemma>dejvický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m041-d1t2854-1">
   <w.rf>
    <LM>w#w-d1t2854-1</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m041-d1t2852-10">
   <w.rf>
    <LM>w#w-d1t2852-10</LM>
   </w.rf>
   <form>směrem</form>
   <lemma>směr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m041-d1t2856-3">
   <w.rf>
    <LM>w#w-d1t2856-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m041-d1t2856-4">
   <w.rf>
    <LM>w#w-d1t2856-4</LM>
   </w.rf>
   <form>letiště</form>
   <lemma>letiště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m041-d-id147715-punct">
   <w.rf>
    <LM>w#w-d-id147715-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2859-6">
   <w.rf>
    <LM>w#w-d1t2859-6</LM>
   </w.rf>
   <form>Veleslavín</form>
   <lemma>Veleslavín-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m041-d1e2832-x3-792">
   <w.rf>
    <LM>w#w-d1e2832-x3-792</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2859-10">
   <w.rf>
    <LM>w#w-d1t2859-10</LM>
   </w.rf>
   <form>Vokovice</form>
   <lemma>Vokovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m041-d1e2832-x3-793">
   <w.rf>
    <LM>w#w-d1e2832-x3-793</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-794">
  <m id="m041-d1t2863-2">
   <w.rf>
    <LM>w#w-d1t2863-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2863-3">
   <w.rf>
    <LM>w#w-d1t2863-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m041-d1t2863-4">
   <w.rf>
    <LM>w#w-d1t2863-4</LM>
   </w.rf>
   <form>volné</form>
   <lemma>volný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m041-d1t2863-5">
   <w.rf>
    <LM>w#w-d1t2863-5</LM>
   </w.rf>
   <form>prostory</form>
   <lemma>prostor</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m041-794-799">
   <w.rf>
    <LM>w#w-794-799</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-794-800">
   <w.rf>
    <LM>w#w-794-800</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-794-801">
   <w.rf>
    <LM>w#w-794-801</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m041-794-802">
   <w.rf>
    <LM>w#w-794-802</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-803">
  <m id="m041-d1t2867-2">
   <w.rf>
    <LM>w#w-d1t2867-2</LM>
   </w.rf>
   <form>Nedávno</form>
   <lemma>dávno-1</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m041-d1t2865-12">
   <w.rf>
    <LM>w#w-d1t2865-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m041-d1t2865-13">
   <w.rf>
    <LM>w#w-d1t2865-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2865-14">
   <w.rf>
    <LM>w#w-d1t2865-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2867-1">
   <w.rf>
    <LM>w#w-d1t2867-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2867-3">
   <w.rf>
    <LM>w#w-d1t2867-3</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m041-803-804">
   <w.rf>
    <LM>w#w-803-804</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-805">
  <m id="m041-d1t2867-4">
   <w.rf>
    <LM>w#w-d1t2867-4</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2867-5">
   <w.rf>
    <LM>w#w-d1t2867-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m041-d1t2867-6">
   <w.rf>
    <LM>w#w-d1t2867-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m041-d1t2867-7">
   <w.rf>
    <LM>w#w-d1t2867-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m041-d1t2867-8">
   <w.rf>
    <LM>w#w-d1t2867-8</LM>
   </w.rf>
   <form>samá</form>
   <lemma>samý</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m041-d1t2867-9">
   <w.rf>
    <LM>w#w-d1t2867-9</LM>
   </w.rf>
   <form>vilka</form>
   <lemma>vilka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m041-805-891">
   <w.rf>
    <LM>w#w-805-891</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-d1t2869-1">
   <w.rf>
    <LM>w#w-d1t2869-1</LM>
   </w.rf>
   <form>přízemí</form>
   <lemma>přízemí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m041-d1t2869-2">
   <w.rf>
    <LM>w#w-d1t2869-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2869-3">
   <w.rf>
    <LM>w#w-d1t2869-3</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m041-d1t2869-4">
   <w.rf>
    <LM>w#w-d1t2869-4</LM>
   </w.rf>
   <form>patra</form>
   <lemma>patro</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m041-805-807">
   <w.rf>
    <LM>w#w-805-807</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m041-805-892">
   <w.rf>
    <LM>w#w-805-892</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m041-d1t2874-5">
   <w.rf>
    <LM>w#w-d1t2874-5</LM>
   </w.rf>
   <form>šestibytovky</form>
   <lemma>šestibytovka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m041-805-808">
   <w.rf>
    <LM>w#w-805-808</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-809">
  <m id="m041-d1t2874-7">
   <w.rf>
    <LM>w#w-d1t2874-7</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m041-d1t2874-8">
   <w.rf>
    <LM>w#w-d1t2874-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m041-d1t2874-9">
   <w.rf>
    <LM>w#w-d1t2874-9</LM>
   </w.rf>
   <form>stavěly</form>
   <lemma>stavět</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m041-809-810">
   <w.rf>
    <LM>w#w-809-810</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m041-811">
  <m id="m041-d1t2876-1">
   <w.rf>
    <LM>w#w-d1t2876-1</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m041-d1t2876-2">
   <w.rf>
    <LM>w#w-d1t2876-2</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m041-d1t2876-3">
   <w.rf>
    <LM>w#w-d1t2876-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m041-811-812">
   <w.rf>
    <LM>w#w-811-812</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
