<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_054.08.w.gz" />
  </references>
 </head>
 <s id="m054-d1e1745-x5">
  <m id="m054-d1t1804-1">
   <w.rf>
    <LM>w#w-d1t1804-1</LM>
   </w.rf>
   <form>Jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1804-2">
   <w.rf>
    <LM>w#w-d1t1804-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1804-3">
   <w.rf>
    <LM>w#w-d1t1804-3</LM>
   </w.rf>
   <form>lepší</form>
   <lemma>lepší</lemma>
   <tag>AAIS4----2A----</tag>
  </m>
  <m id="m054-d1t1804-4">
   <w.rf>
    <LM>w#w-d1t1804-4</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-d1t1804-5">
   <w.rf>
    <LM>w#w-d1t1804-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1804-6">
   <w.rf>
    <LM>w#w-d1t1804-6</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m054-d1e1745-x5-109">
   <w.rf>
    <LM>w#w-d1e1745-x5-109</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1804-7">
   <w.rf>
    <LM>w#w-d1t1804-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t1804-8">
   <w.rf>
    <LM>w#w-d1t1804-8</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m054-d1e1745-x5-110">
   <w.rf>
    <LM>w#w-d1e1745-x5-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-116">
  <m id="m054-d1t1804-9">
   <w.rf>
    <LM>w#w-d1t1804-9</LM>
   </w.rf>
   <form>Pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t1804-10">
   <w.rf>
    <LM>w#w-d1t1804-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d-id136262-punct">
   <w.rf>
    <LM>w#w-d-id136262-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1804-12">
   <w.rf>
    <LM>w#w-d1t1804-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1804-13">
   <w.rf>
    <LM>w#w-d1t1804-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m054-d1t1804-14">
   <w.rf>
    <LM>w#w-d1t1804-14</LM>
   </w.rf>
   <form>dopřála</form>
   <lemma>dopřát</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m054-d1t1804-15">
   <w.rf>
    <LM>w#w-d1t1804-15</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1804-17">
   <w.rf>
    <LM>w#w-d1t1804-17</LM>
   </w.rf>
   <form>dopřát</form>
   <lemma>dopřát</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-d1t1804-16">
   <w.rf>
    <LM>w#w-d1t1804-16</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-116-117">
   <w.rf>
    <LM>w#w-116-117</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-118">
  <m id="m054-d1t1806-2">
   <w.rf>
    <LM>w#w-d1t1806-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1806-3">
   <w.rf>
    <LM>w#w-d1t1806-3</LM>
   </w.rf>
   <form>magistrou</form>
   <lemma>magistra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m054-d1t1806-4">
   <w.rf>
    <LM>w#w-d1t1806-4</LM>
   </w.rf>
   <form>farmacie</form>
   <lemma>farmacie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d-id136435-punct">
   <w.rf>
    <LM>w#w-d-id136435-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1806-9">
   <w.rf>
    <LM>w#w-d1t1806-9</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1806-10">
   <w.rf>
    <LM>w#w-d1t1806-10</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m054-d1t1806-13">
   <w.rf>
    <LM>w#w-d1t1806-13</LM>
   </w.rf>
   <form>situovaná</form>
   <lemma>situovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-118-119">
   <w.rf>
    <LM>w#w-118-119</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-120">
  <m id="m054-d1t1806-14">
   <w.rf>
    <LM>w#w-d1t1806-14</LM>
   </w.rf>
   <form>Mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1806-15">
   <w.rf>
    <LM>w#w-d1t1806-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m054-d1t1806-16">
   <w.rf>
    <LM>w#w-d1t1806-16</LM>
   </w.rf>
   <form>dopřát</form>
   <lemma>dopřát</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-d1t1806-17">
   <w.rf>
    <LM>w#w-d1t1806-17</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1808-1">
   <w.rf>
    <LM>w#w-d1t1808-1</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m054-120-121">
   <w.rf>
    <LM>w#w-120-121</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1808-4">
   <w.rf>
    <LM>w#w-d1t1808-4</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1808-3">
   <w.rf>
    <LM>w#w-d1t1808-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m054-d1t1808-5">
   <w.rf>
    <LM>w#w-d1t1808-5</LM>
   </w.rf>
   <form>dopřát</form>
   <lemma>dopřát</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-d1t1808-2">
   <w.rf>
    <LM>w#w-d1t1808-2</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m054-120-122">
   <w.rf>
    <LM>w#w-120-122</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-137">
  <m id="m054-d1t1808-6">
   <w.rf>
    <LM>w#w-d1t1808-6</LM>
   </w.rf>
   <form>Ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1808-8">
   <w.rf>
    <LM>w#w-d1t1808-8</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m054-d1t1808-9">
   <w.rf>
    <LM>w#w-d1t1808-9</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1808-7">
   <w.rf>
    <LM>w#w-d1t1808-7</LM>
   </w.rf>
   <form>manžela</form>
   <lemma>manžel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m054-d1t1816-2">
   <w.rf>
    <LM>w#w-d1t1816-2</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1816-1">
   <w.rf>
    <LM>w#w-d1t1816-1</LM>
   </w.rf>
   <form>přítele</form>
   <lemma>přítel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m054-d-m-d1e1745-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1745-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1809-x2">
  <m id="m054-d1t1814-2">
   <w.rf>
    <LM>w#w-d1t1814-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1814-1">
   <w.rf>
    <LM>w#w-d1t1814-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1814-3">
   <w.rf>
    <LM>w#w-d1t1814-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1814-4">
   <w.rf>
    <LM>w#w-d1t1814-4</LM>
   </w.rf>
   <form>smutné</form>
   <lemma>smutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m054-d1e1809-x2-138">
   <w.rf>
    <LM>w#w-d1e1809-x2-138</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1814-5">
   <w.rf>
    <LM>w#w-d1t1814-5</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-d1t1814-6">
   <w.rf>
    <LM>w#w-d1t1814-6</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m054-d-m-d1e1809-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1809-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1817-x2">
  <m id="m054-d1t1820-3">
   <w.rf>
    <LM>w#w-d1t1820-3</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1820-4">
   <w.rf>
    <LM>w#w-d1t1820-4</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m054-d1t1820-5">
   <w.rf>
    <LM>w#w-d1t1820-5</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1820-6">
   <w.rf>
    <LM>w#w-d1t1820-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1820-7">
   <w.rf>
    <LM>w#w-d1t1820-7</LM>
   </w.rf>
   <form>smrti</form>
   <lemma>smrt</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1e1817-x2-145">
   <w.rf>
    <LM>w#w-d1e1817-x2-145</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-146">
  <m id="m054-146-147">
   <w.rf>
    <LM>w#w-146-147</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1826-2">
   <w.rf>
    <LM>w#w-d1t1826-2</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1826-3">
   <w.rf>
    <LM>w#w-d1t1826-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-146-387">
   <w.rf>
    <LM>w#w-146-387</LM>
   </w.rf>
   <form>jejího</form>
   <lemma>jeho</lemma>
   <tag>P9ZS2FS3-------</tag>
  </m>
  <m id="m054-d1t1826-4">
   <w.rf>
    <LM>w#w-d1t1826-4</LM>
   </w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m054-146-385">
   <w.rf>
    <LM>w#w-146-385</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-146-381">
   <w.rf>
    <LM>w#w-146-381</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-146-382">
   <w.rf>
    <LM>w#w-146-382</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-146-383">
   <w.rf>
    <LM>w#w-146-383</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-146-384">
   <w.rf>
    <LM>w#w-146-384</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-146-386">
   <w.rf>
    <LM>w#w-146-386</LM>
   </w.rf>
   <form>dozvěděli</form>
   <lemma>dozvědět</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m054-146-149">
   <w.rf>
    <LM>w#w-146-149</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-150">
  <m id="m054-d1t1826-11">
   <w.rf>
    <LM>w#w-d1t1826-11</LM>
   </w.rf>
   <form>Stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1826-9">
   <w.rf>
    <LM>w#w-d1t1826-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1826-10">
   <w.rf>
    <LM>w#w-d1t1826-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1826-7">
   <w.rf>
    <LM>w#w-d1t1826-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1826-12">
   <w.rf>
    <LM>w#w-d1t1826-12</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-d1t1826-13">
   <w.rf>
    <LM>w#w-d1t1826-13</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m054-d1t1826-14">
   <w.rf>
    <LM>w#w-d1t1826-14</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m054-150-151">
   <w.rf>
    <LM>w#w-150-151</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-152">
  <m id="m054-d1t1826-20">
   <w.rf>
    <LM>w#w-d1t1826-20</LM>
   </w.rf>
   <form>Obstaral</form>
   <lemma>obstarat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1826-21">
   <w.rf>
    <LM>w#w-d1t1826-21</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m054-152-153">
   <w.rf>
    <LM>w#w-152-153</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-155">
  <m id="m054-d1t1831-1">
   <w.rf>
    <LM>w#w-d1t1831-1</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m054-d1t1831-2">
   <w.rf>
    <LM>w#w-d1t1831-2</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1831-3">
   <w.rf>
    <LM>w#w-d1t1831-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1831-4">
   <w.rf>
    <LM>w#w-d1t1831-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1831-5">
   <w.rf>
    <LM>w#w-d1t1831-5</LM>
   </w.rf>
   <form>hodný</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m054-d-id137816-punct">
   <w.rf>
    <LM>w#w-d-id137816-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1831-7">
   <w.rf>
    <LM>w#w-d1t1831-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1833-1">
   <w.rf>
    <LM>w#w-d1t1833-1</LM>
   </w.rf>
   <form>obstaral</form>
   <lemma>obstarat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1833-2">
   <w.rf>
    <LM>w#w-d1t1833-2</LM>
   </w.rf>
   <form>maminku</form>
   <lemma>maminka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m054-d-id137881-punct">
   <w.rf>
    <LM>w#w-d-id137881-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1833-5">
   <w.rf>
    <LM>w#w-d1t1833-5</LM>
   </w.rf>
   <form>sestru</form>
   <lemma>sestra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m054-d1t1835-1">
   <w.rf>
    <LM>w#w-d1t1835-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1835-2">
   <w.rf>
    <LM>w#w-d1t1835-2</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSXP4-S1-------</tag>
  </m>
  <m id="m054-d1t1835-3">
   <w.rf>
    <LM>w#w-d1t1835-3</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m054-155-158">
   <w.rf>
    <LM>w#w-155-158</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-160">
  <m id="m054-d1t1837-1">
   <w.rf>
    <LM>w#w-d1t1837-1</LM>
   </w.rf>
   <form>Mému</form>
   <lemma>můj</lemma>
   <tag>PSZS3-S1-------</tag>
  </m>
  <m id="m054-d1t1837-2">
   <w.rf>
    <LM>w#w-d1t1837-2</LM>
   </w.rf>
   <form>otci</form>
   <lemma>otec</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m054-d1t1837-3">
   <w.rf>
    <LM>w#w-d1t1837-3</LM>
   </w.rf>
   <form>zatlačil</form>
   <lemma>zatlačit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1837-4">
   <w.rf>
    <LM>w#w-d1t1837-4</LM>
   </w.rf>
   <form>oči</form>
   <lemma>oko-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-d1t1837-5">
   <w.rf>
    <LM>w#w-d1t1837-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1837-6">
   <w.rf>
    <LM>w#w-d1t1837-6</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS4-S1------6</tag>
  </m>
  <m id="m054-d1t1837-7">
   <w.rf>
    <LM>w#w-d1t1837-7</LM>
   </w.rf>
   <form>matku</form>
   <lemma>matka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m054-d1t1837-8">
   <w.rf>
    <LM>w#w-d1t1837-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t1837-10">
   <w.rf>
    <LM>w#w-d1t1837-10</LM>
   </w.rf>
   <form>Štědrý</form>
   <lemma>štědrý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m054-d1t1837-11">
   <w.rf>
    <LM>w#w-d1t1837-11</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-d1t1839-1">
   <w.rf>
    <LM>w#w-d1t1839-1</LM>
   </w.rf>
   <form>odvezl</form>
   <lemma>odvézt</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1839-2">
   <w.rf>
    <LM>w#w-d1t1839-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1839-3">
   <w.rf>
    <LM>w#w-d1t1839-3</LM>
   </w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1t1839-4">
   <w.rf>
    <LM>w#w-d1t1839-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1839-5">
   <w.rf>
    <LM>w#w-d1t1839-5</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m054-d1t1839-6">
   <w.rf>
    <LM>w#w-d1t1839-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1839-7">
   <w.rf>
    <LM>w#w-d1t1839-7</LM>
   </w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1839-8">
   <w.rf>
    <LM>w#w-d1t1839-8</LM>
   </w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m054-d1t1839-9">
   <w.rf>
    <LM>w#w-d1t1839-9</LM>
   </w.rf>
   <form>dnů</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m054-d1t1839-10">
   <w.rf>
    <LM>w#w-d1t1839-10</LM>
   </w.rf>
   <form>zemřela</form>
   <lemma>zemřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m054-d1e1817-x3-170">
   <w.rf>
    <LM>w#w-d1e1817-x3-170</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-171">
  <m id="m054-d1t1839-13">
   <w.rf>
    <LM>w#w-d1t1839-13</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1839-14">
   <w.rf>
    <LM>w#w-d1t1839-14</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1839-15">
   <w.rf>
    <LM>w#w-d1t1839-15</LM>
   </w.rf>
   <form>krček</form>
   <lemma>krček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-171-172">
   <w.rf>
    <LM>w#w-171-172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-182">
  <m id="m054-d1t1844-2">
   <w.rf>
    <LM>w#w-d1t1844-2</LM>
   </w.rf>
   <form>Musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1844-3">
   <w.rf>
    <LM>w#w-d1t1844-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m054-d-id138460-punct">
   <w.rf>
    <LM>w#w-d-id138460-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1844-5">
   <w.rf>
    <LM>w#w-d1t1844-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1844-6">
   <w.rf>
    <LM>w#w-d1t1844-6</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m054-d1t1844-7">
   <w.rf>
    <LM>w#w-d1t1844-7</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1844-8">
   <w.rf>
    <LM>w#w-d1t1844-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-182-188">
   <w.rf>
    <LM>w#w-182-188</LM>
   </w.rf>
   <form>postaral</form>
   <lemma>postarat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-182-187">
   <w.rf>
    <LM>w#w-182-187</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t1844-10">
   <w.rf>
    <LM>w#w-d1t1844-10</LM>
   </w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m054-d1t1844-12">
   <w.rf>
    <LM>w#w-d1t1844-12</LM>
   </w.rf>
   <form>rodiny</form>
   <lemma>rodina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-182-189">
   <w.rf>
    <LM>w#w-182-189</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-190">
  <m id="m054-d1t1844-17">
   <w.rf>
    <LM>w#w-d1t1844-17</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t1844-19">
   <w.rf>
    <LM>w#w-d1t1844-19</LM>
   </w.rf>
   <form>nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m054-d1t1844-18">
   <w.rf>
    <LM>w#w-d1t1844-18</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1844-20">
   <w.rf>
    <LM>w#w-d1t1844-20</LM>
   </w.rf>
   <form>zapomenout</form>
   <lemma>zapomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-190-191">
   <w.rf>
    <LM>w#w-190-191</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-192">
  <m id="m054-d1t1844-22">
   <w.rf>
    <LM>w#w-d1t1844-22</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-192-193">
   <w.rf>
    <LM>w#w-192-193</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1844-21">
   <w.rf>
    <LM>w#w-d1t1844-21</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-192-194">
   <w.rf>
    <LM>w#w-192-194</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1847-x2">
  <m id="m054-d1t1852-1">
   <w.rf>
    <LM>w#w-d1t1852-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1852-2">
   <w.rf>
    <LM>w#w-d1t1852-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1852-6">
   <w.rf>
    <LM>w#w-d1t1852-6</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1852-4">
   <w.rf>
    <LM>w#w-d1t1852-4</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1852-5">
   <w.rf>
    <LM>w#w-d1t1852-5</LM>
   </w.rf>
   <form>smutnější</form>
   <lemma>smutný</lemma>
   <tag>AAFP1----2A----</tag>
  </m>
  <m id="m054-d1t1852-7">
   <w.rf>
    <LM>w#w-d1t1852-7</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-d1e1847-x2-205">
   <w.rf>
    <LM>w#w-d1e1847-x2-205</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1e1847-x2-206">
   <w.rf>
    <LM>w#w-d1e1847-x2-206</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1e1847-x2-207">
   <w.rf>
    <LM>w#w-d1e1847-x2-207</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t1858-3">
   <w.rf>
    <LM>w#w-d1t1858-3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1e1847-x2-209">
   <w.rf>
    <LM>w#w-d1e1847-x2-209</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1858-8">
   <w.rf>
    <LM>w#w-d1t1858-8</LM>
   </w.rf>
   <form>dáme</form>
   <lemma>dát-1</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m054-d1t1858-7">
   <w.rf>
    <LM>w#w-d1t1858-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m054-d1t1858-4">
   <w.rf>
    <LM>w#w-d1t1858-4</LM>
   </w.rf>
   <form>radši</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m054-d1t1858-5">
   <w.rf>
    <LM>w#w-d1t1858-5</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m054-d1t1858-6">
   <w.rf>
    <LM>w#w-d1t1858-6</LM>
   </w.rf>
   <form>veselejšího</form>
   <lemma>veselý</lemma>
   <tag>AANS2----2A----</tag>
  </m>
  <m id="m054-d1e1847-x2-208">
   <w.rf>
    <LM>w#w-d1e1847-x2-208</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1847-x3">
  <m id="m054-d1t1854-1">
   <w.rf>
    <LM>w#w-d1t1854-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d-m-d1e1847-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1847-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1861-x3">
  <m id="m054-d1t1868-1">
   <w.rf>
    <LM>w#w-d1t1868-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m054-d1t1868-2">
   <w.rf>
    <LM>w#w-d1t1868-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1868-3">
   <w.rf>
    <LM>w#w-d1t1868-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1868-4">
   <w.rf>
    <LM>w#w-d1t1868-4</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m054-d1e1861-x3-229">
   <w.rf>
    <LM>w#w-d1e1861-x3-229</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1868-5">
   <w.rf>
    <LM>w#w-d1t1868-5</LM>
   </w.rf>
   <form>španělka</form>
   <lemma>španělka_^(kytara)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1e1861-x3-230">
   <w.rf>
    <LM>w#w-d1e1861-x3-230</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d-id139360-punct">
   <w.rf>
    <LM>w#w-d-id139360-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1874-1">
   <w.rf>
    <LM>w#w-d1t1874-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1874-2">
   <w.rf>
    <LM>w#w-d1t1874-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1e1869-x2-221">
   <w.rf>
    <LM>w#w-d1e1869-x2-221</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m054-d1t1874-3">
   <w.rf>
    <LM>w#w-d1t1874-3</LM>
   </w.rf>
   <form>umřel</form>
   <lemma>umřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1874-4">
   <w.rf>
    <LM>w#w-d1t1874-4</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1874-5">
   <w.rf>
    <LM>w#w-d1t1874-5</LM>
   </w.rf>
   <form>vašeho</form>
   <lemma>váš</lemma>
   <tag>PSZS2-P2-------</tag>
  </m>
  <m id="m054-d1t1874-6">
   <w.rf>
    <LM>w#w-d1t1874-6</LM>
   </w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m054-d-id139511-punct">
   <w.rf>
    <LM>w#w-d-id139511-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1869-x4">
  <m id="m054-d1t1876-1">
   <w.rf>
    <LM>w#w-d1t1876-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1876-2">
   <w.rf>
    <LM>w#w-d1t1876-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1876-4">
   <w.rf>
    <LM>w#w-d1t1876-4</LM>
   </w.rf>
   <form>Španělská</form>
   <lemma>španělský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-d1t1876-5">
   <w.rf>
    <LM>w#w-d1t1876-5</LM>
   </w.rf>
   <form>chřipka</form>
   <lemma>chřipka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1e1869-x4-237">
   <w.rf>
    <LM>w#w-d1e1869-x4-237</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-238">
  <m id="m054-d1t1876-8">
   <w.rf>
    <LM>w#w-d1t1876-8</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1876-9">
   <w.rf>
    <LM>w#w-d1t1876-9</LM>
   </w.rf>
   <form>končila</form>
   <lemma>končit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1876-10">
   <w.rf>
    <LM>w#w-d1t1876-10</LM>
   </w.rf>
   <form>válka</form>
   <lemma>válka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d-id139657-punct">
   <w.rf>
    <LM>w#w-d-id139657-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1880-1">
   <w.rf>
    <LM>w#w-d1t1880-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1884-2">
   <w.rf>
    <LM>w#w-d1t1884-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1884-3">
   <w.rf>
    <LM>w#w-d1t1884-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1884-4">
   <w.rf>
    <LM>w#w-d1t1884-4</LM>
   </w.rf>
   <form>objevilo</form>
   <lemma>objevit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1884-5">
   <w.rf>
    <LM>w#w-d1t1884-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1884-6">
   <w.rf>
    <LM>w#w-d1t1884-6</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1884-7">
   <w.rf>
    <LM>w#w-d1t1884-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t1884-8">
   <w.rf>
    <LM>w#w-d1t1884-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t1884-9">
   <w.rf>
    <LM>w#w-d1t1884-9</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m054-d1t1884-10">
   <w.rf>
    <LM>w#w-d1t1884-10</LM>
   </w.rf>
   <form>umírali</form>
   <lemma>umírat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1e1877-x2-249">
   <w.rf>
    <LM>w#w-d1e1877-x2-249</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-251">
  <m id="m054-d1t1886-3">
   <w.rf>
    <LM>w#w-d1t1886-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1886-4">
   <w.rf>
    <LM>w#w-d1t1886-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1886-8">
   <w.rf>
    <LM>w#w-d1t1886-8</LM>
   </w.rf>
   <form>Španělská</form>
   <lemma>španělský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-d1t1886-9">
   <w.rf>
    <LM>w#w-d1t1886-9</LM>
   </w.rf>
   <form>chřipka</form>
   <lemma>chřipka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t1886-11">
   <w.rf>
    <LM>w#w-d1t1886-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1886-12">
   <w.rf>
    <LM>w#w-d1t1886-12</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m054-d1t1886-13">
   <w.rf>
    <LM>w#w-d1t1886-13</LM>
   </w.rf>
   <form>1918</form>
   <lemma>1918</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m054-d-m-d1e1877-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1877-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1893-x2">
  <m id="m054-d1t1896-12">
   <w.rf>
    <LM>w#w-d1t1896-12</LM>
   </w.rf>
   <form>Bacil</form>
   <lemma>bacil-2</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-d1t1896-13">
   <w.rf>
    <LM>w#w-d1t1896-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m054-d1t1896-14">
   <w.rf>
    <LM>w#w-d1t1896-14</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1896-17">
   <w.rf>
    <LM>w#w-d1t1896-17</LM>
   </w.rf>
   <form>holt</form>
   <lemma>holt_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1896-16">
   <w.rf>
    <LM>w#w-d1t1896-16</LM>
   </w.rf>
   <form>přinést</form>
   <lemma>přinést</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-d1t1896-15">
   <w.rf>
    <LM>w#w-d1t1896-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1896-18">
   <w.rf>
    <LM>w#w-d1t1896-18</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1896-20">
   <w.rf>
    <LM>w#w-d1t1896-20</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1e1893-x2-253">
   <w.rf>
    <LM>w#w-d1e1893-x2-253</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1896-22">
   <w.rf>
    <LM>w#w-d1t1896-22</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1896-23">
   <w.rf>
    <LM>w#w-d1t1896-23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t1896-25">
   <w.rf>
    <LM>w#w-d1t1896-25</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1896-24">
   <w.rf>
    <LM>w#w-d1t1896-24</LM>
   </w.rf>
   <form>chytil</form>
   <lemma>chytit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d-m-d1e1893-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1893-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1899-x2">
  <m id="m054-d1t1902-1">
   <w.rf>
    <LM>w#w-d1t1902-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d-m-d1e1899-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1899-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1908-x3">
  <m id="m054-d1t1915-1">
   <w.rf>
    <LM>w#w-d1t1915-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m054-d1t1915-2">
   <w.rf>
    <LM>w#w-d1t1915-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m054-d1t1915-3">
   <w.rf>
    <LM>w#w-d1t1915-3</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-d-id140994-punct">
   <w.rf>
    <LM>w#w-d-id140994-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1916-x2">
  <m id="m054-d1t1919-1">
   <w.rf>
    <LM>w#w-d1t1919-1</LM>
   </w.rf>
   <form>Děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-d1t1919-2">
   <w.rf>
    <LM>w#w-d1t1919-2</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1e1916-x2-259">
   <w.rf>
    <LM>w#w-d1e1916-x2-259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-261">
  <m id="m054-d1t1921-3">
   <w.rf>
    <LM>w#w-d1t1921-3</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1921-2">
   <w.rf>
    <LM>w#w-d1t1921-2</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1921-5">
   <w.rf>
    <LM>w#w-d1t1921-5</LM>
   </w.rf>
   <form>Lukáše</form>
   <lemma>Lukáš_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m054-261-262">
   <w.rf>
    <LM>w#w-261-262</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1921-8">
   <w.rf>
    <LM>w#w-d1t1921-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1921-9">
   <w.rf>
    <LM>w#w-d1t1921-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1921-10">
   <w.rf>
    <LM>w#w-d1t1921-10</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-261-264">
   <w.rf>
    <LM>w#w-261-264</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-267">
  <m id="m054-d1t1921-12">
   <w.rf>
    <LM>w#w-d1t1921-12</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1921-13">
   <w.rf>
    <LM>w#w-d1t1921-13</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m054-d1t1921-14">
   <w.rf>
    <LM>w#w-d1t1921-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1921-15">
   <w.rf>
    <LM>w#w-d1t1921-15</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m054-d-m-d1e1916-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1916-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1922-x2">
  <m id="m054-d1t1927-1">
   <w.rf>
    <LM>w#w-d1t1927-1</LM>
   </w.rf>
   <form>Dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t1927-2">
   <w.rf>
    <LM>w#w-d1t1927-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1927-3">
   <w.rf>
    <LM>w#w-d1t1927-3</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t1927-5">
   <w.rf>
    <LM>w#w-d1t1927-5</LM>
   </w.rf>
   <form>Lukáše</form>
   <lemma>Lukáš_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m054-d-m-d1e1922-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1922-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1932-x2">
  <m id="m054-d1t1935-2">
   <w.rf>
    <LM>w#w-d1t1935-2</LM>
   </w.rf>
   <form>Syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1935-3">
   <w.rf>
    <LM>w#w-d1t1935-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1935-5">
   <w.rf>
    <LM>w#w-d1t1935-5</LM>
   </w.rf>
   <form>Zdeněk</form>
   <lemma>Zdeněk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1935-6">
   <w.rf>
    <LM>w#w-d1t1935-6</LM>
   </w.rf>
   <form>Vaník</form>
   <lemma>Vaník_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1935-9">
   <w.rf>
    <LM>w#w-d1t1935-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1935-11">
   <w.rf>
    <LM>w#w-d1t1935-11</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1935-12">
   <w.rf>
    <LM>w#w-d1t1935-12</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1935-13">
   <w.rf>
    <LM>w#w-d1t1935-13</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-d1e1932-x2-288">
   <w.rf>
    <LM>w#w-d1e1932-x2-288</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-289">
  <m id="m054-d1t1935-16">
   <w.rf>
    <LM>w#w-d1t1935-16</LM>
   </w.rf>
   <form>Lukáš</form>
   <lemma>Lukáš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1935-18">
   <w.rf>
    <LM>w#w-d1t1935-18</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1935-19">
   <w.rf>
    <LM>w#w-d1t1935-19</LM>
   </w.rf>
   <form>sestru</form>
   <lemma>sestra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m054-289-290">
   <w.rf>
    <LM>w#w-289-290</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-291">
  <m id="m054-d1t1935-22">
   <w.rf>
    <LM>w#w-d1t1935-22</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1935-23">
   <w.rf>
    <LM>w#w-d1t1935-23</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1935-24">
   <w.rf>
    <LM>w#w-d1t1935-24</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-291-292">
   <w.rf>
    <LM>w#w-291-292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-293">
  <m id="m054-d1t1937-9">
   <w.rf>
    <LM>w#w-d1t1937-9</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1937-10">
   <w.rf>
    <LM>w#w-d1t1937-10</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m054-293-295">
   <w.rf>
    <LM>w#w-293-295</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1937-3">
   <w.rf>
    <LM>w#w-d1t1937-3</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m054-d1t1937-4">
   <w.rf>
    <LM>w#w-d1t1937-4</LM>
   </w.rf>
   <form>dcery</form>
   <lemma>dcera</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-d1t1937-5">
   <w.rf>
    <LM>w#w-d1t1937-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1937-6">
   <w.rf>
    <LM>w#w-d1t1937-6</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m054-d1t1937-7">
   <w.rf>
    <LM>w#w-d1t1937-7</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-293-296">
   <w.rf>
    <LM>w#w-293-296</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-297">
  <m id="m054-d1t1941-1">
   <w.rf>
    <LM>w#w-d1t1941-1</LM>
   </w.rf>
   <form>Synovi</form>
   <lemma>syn</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m054-d1t1941-2">
   <w.rf>
    <LM>w#w-d1t1941-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1941-3">
   <w.rf>
    <LM>w#w-d1t1941-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1941-5">
   <w.rf>
    <LM>w#w-d1t1941-5</LM>
   </w.rf>
   <form>63</form>
   <lemma>63</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m054-297-298">
   <w.rf>
    <LM>w#w-297-298</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-300">
  <m id="m054-d1t1941-9">
   <w.rf>
    <LM>w#w-d1t1941-9</LM>
   </w.rf>
   <form>Lukášovi</form>
   <lemma>Lukáš_;Y</lemma>
   <tag>NNMS3-----A---1</tag>
  </m>
  <m id="m054-d1t1941-17">
   <w.rf>
    <LM>w#w-d1t1941-17</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m054-d1t1941-19">
   <w.rf>
    <LM>w#w-d1t1941-19</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1941-20">
   <w.rf>
    <LM>w#w-d1t1941-20</LM>
   </w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m054-d1t1943-1">
   <w.rf>
    <LM>w#w-d1t1943-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1943-2">
   <w.rf>
    <LM>w#w-d1t1943-2</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1943-3">
   <w.rf>
    <LM>w#w-d1t1943-3</LM>
   </w.rf>
   <form>sestru</form>
   <lemma>sestra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m054-300-304">
   <w.rf>
    <LM>w#w-300-304</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1946-1">
   <w.rf>
    <LM>w#w-d1t1946-1</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m054-d1t1946-2">
   <w.rf>
    <LM>w#w-d1t1946-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1946-3">
   <w.rf>
    <LM>w#w-d1t1946-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1946-5">
   <w.rf>
    <LM>w#w-d1t1946-5</LM>
   </w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m054-d1t1946-7">
   <w.rf>
    <LM>w#w-d1t1946-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1946-8">
   <w.rf>
    <LM>w#w-d1t1946-8</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m054-d1t1946-9">
   <w.rf>
    <LM>w#w-d1t1946-9</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m054-d1t1946-10">
   <w.rf>
    <LM>w#w-d1t1946-10</LM>
   </w.rf>
   <form>37</form>
   <lemma>37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m054-d-m-d1e1932-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1932-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1947-x2">
  <m id="m054-d1t1952-1">
   <w.rf>
    <LM>w#w-d1t1952-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m054-d-m-d1e1947-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1947-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1957-x2">
  <m id="m054-d1t1960-1">
   <w.rf>
    <LM>w#w-d1t1960-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1960-2">
   <w.rf>
    <LM>w#w-d1t1960-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1960-3">
   <w.rf>
    <LM>w#w-d1t1960-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m054-d1t1960-4">
   <w.rf>
    <LM>w#w-d1t1960-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d1t1960-5">
   <w.rf>
    <LM>w#w-d1t1960-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1960-6">
   <w.rf>
    <LM>w#w-d1t1960-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m054-d1t1960-7">
   <w.rf>
    <LM>w#w-d1t1960-7</LM>
   </w.rf>
   <form>zajímavého</form>
   <lemma>zajímavý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m054-d-id142933-punct">
   <w.rf>
    <LM>w#w-d-id142933-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1961-x2">
  <m id="m054-d1t1966-6">
   <w.rf>
    <LM>w#w-d1t1966-6</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1966-7">
   <w.rf>
    <LM>w#w-d1t1966-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1966-8">
   <w.rf>
    <LM>w#w-d1t1966-8</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m054-d1t1966-9">
   <w.rf>
    <LM>w#w-d1t1966-9</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d-id143167-punct">
   <w.rf>
    <LM>w#w-d-id143167-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1966-11">
   <w.rf>
    <LM>w#w-d1t1966-11</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m054-d1t1966-10">
   <w.rf>
    <LM>w#w-d1t1966-10</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m054-d1e1961-x2-28">
   <w.rf>
    <LM>w#w-d1e1961-x2-28</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1966-14">
   <w.rf>
    <LM>w#w-d1t1966-14</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1966-17">
   <w.rf>
    <LM>w#w-d1t1966-17</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1e1961-x2-29">
   <w.rf>
    <LM>w#w-d1e1961-x2-29</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1966-15">
   <w.rf>
    <LM>w#w-d1t1966-15</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m054-d1t1966-16">
   <w.rf>
    <LM>w#w-d1t1966-16</LM>
   </w.rf>
   <form>zajímavého</form>
   <lemma>zajímavý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m054-d1t1966-18">
   <w.rf>
    <LM>w#w-d1t1966-18</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m054-d1e1961-x2-30">
   <w.rf>
    <LM>w#w-d1e1961-x2-30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-33">
  <m id="m054-d1t1968-1">
   <w.rf>
    <LM>w#w-d1t1968-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1968-2">
   <w.rf>
    <LM>w#w-d1t1968-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1968-3">
   <w.rf>
    <LM>w#w-d1t1968-3</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1968-4">
   <w.rf>
    <LM>w#w-d1t1968-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1968-6">
   <w.rf>
    <LM>w#w-d1t1968-6</LM>
   </w.rf>
   <form>Panny</form>
   <lemma>panna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1t1968-7">
   <w.rf>
    <LM>w#w-d1t1968-7</LM>
   </w.rf>
   <form>Marie</form>
   <lemma>Marie_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1t1968-8">
   <w.rf>
    <LM>w#w-d1t1968-8</LM>
   </w.rf>
   <form>Růžencové</form>
   <lemma>Růžencová_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-33-34">
   <w.rf>
    <LM>w#w-33-34</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-36">
  <m id="m054-d1t1968-11">
   <w.rf>
    <LM>w#w-d1t1968-11</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1968-12">
   <w.rf>
    <LM>w#w-d1t1968-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1968-13">
   <w.rf>
    <LM>w#w-d1t1968-13</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-36-37">
   <w.rf>
    <LM>w#w-36-37</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-38">
  <m id="m054-d1t1970-2">
   <w.rf>
    <LM>w#w-d1t1970-2</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1970-1">
   <w.rf>
    <LM>w#w-d1t1970-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1970-4">
   <w.rf>
    <LM>w#w-d1t1970-4</LM>
   </w.rf>
   <form>uprostřed</form>
   <lemma>uprostřed-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1970-5">
   <w.rf>
    <LM>w#w-d1t1970-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1970-7">
   <w.rf>
    <LM>w#w-d1t1970-7</LM>
   </w.rf>
   <form>náměstíčku</form>
   <lemma>náměstíčko</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m054-d1t1972-1">
   <w.rf>
    <LM>w#w-d1t1972-1</LM>
   </w.rf>
   <form>nestály</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m054-d1t1972-2">
   <w.rf>
    <LM>w#w-d1t1972-2</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m054-d1t1972-3">
   <w.rf>
    <LM>w#w-d1t1972-3</LM>
   </w.rf>
   <form>domy</form>
   <lemma>dům</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m054-d-id143629-punct">
   <w.rf>
    <LM>w#w-d-id143629-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1972-5">
   <w.rf>
    <LM>w#w-d1t1972-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1972-6">
   <w.rf>
    <LM>w#w-d1t1972-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1972-8">
   <w.rf>
    <LM>w#w-d1t1972-8</LM>
   </w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1972-7">
   <w.rf>
    <LM>w#w-d1t1972-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-38-39">
   <w.rf>
    <LM>w#w-38-39</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-43">
  <m id="m054-d1t1972-13">
   <w.rf>
    <LM>w#w-d1t1972-13</LM>
   </w.rf>
   <form>Náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m054-d1t1972-14">
   <w.rf>
    <LM>w#w-d1t1972-14</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1972-15">
   <w.rf>
    <LM>w#w-d1t1972-15</LM>
   </w.rf>
   <form>volné</form>
   <lemma>volný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m054-43-44">
   <w.rf>
    <LM>w#w-43-44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-47">
  <m id="m054-d1t1977-1">
   <w.rf>
    <LM>w#w-d1t1977-1</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1977-2">
   <w.rf>
    <LM>w#w-d1t1977-2</LM>
   </w.rf>
   <form>schodech</form>
   <lemma>schod</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m054-d1t1977-3">
   <w.rf>
    <LM>w#w-d1t1977-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1977-4">
   <w.rf>
    <LM>w#w-d1t1977-4</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1977-5">
   <w.rf>
    <LM>w#w-d1t1977-5</LM>
   </w.rf>
   <form>nahoru</form>
   <lemma>nahoru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1979-1">
   <w.rf>
    <LM>w#w-d1t1979-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1979-3">
   <w.rf>
    <LM>w#w-d1t1979-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1979-2">
   <w.rf>
    <LM>w#w-d1t1979-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1979-5">
   <w.rf>
    <LM>w#w-d1t1979-5</LM>
   </w.rf>
   <form>Dominikánský</form>
   <lemma>dominikánský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m054-d1t1981-1">
   <w.rf>
    <LM>w#w-d1t1981-1</LM>
   </w.rf>
   <form>klášter</form>
   <lemma>klášter</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-47-48">
   <w.rf>
    <LM>w#w-47-48</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-53">
  <m id="m054-d1t1983-14">
   <w.rf>
    <LM>w#w-d1t1983-14</LM>
   </w.rf>
   <form>Kostel</form>
   <lemma>kostel</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-d1t1983-10">
   <w.rf>
    <LM>w#w-d1t1983-10</LM>
   </w.rf>
   <form>Marie</form>
   <lemma>Marie_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1t1983-11">
   <w.rf>
    <LM>w#w-d1t1983-11</LM>
   </w.rf>
   <form>Růžencové</form>
   <lemma>Růžencová_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1t1985-4">
   <w.rf>
    <LM>w#w-d1t1985-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-53-71">
   <w.rf>
    <LM>w#w-53-71</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1983-2">
   <w.rf>
    <LM>w#w-d1t1983-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1983-3">
   <w.rf>
    <LM>w#w-d1t1983-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1983-4">
   <w.rf>
    <LM>w#w-d1t1983-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1983-5">
   <w.rf>
    <LM>w#w-d1t1983-5</LM>
   </w.rf>
   <form>vezme</form>
   <lemma>vzít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m054-d1t1981-5">
   <w.rf>
    <LM>w#w-d1t1981-5</LM>
   </w.rf>
   <form>prakticky</form>
   <lemma>prakticky-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1e1961-x3-73">
   <w.rf>
    <LM>w#w-d1e1961-x3-73</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1985-1">
   <w.rf>
    <LM>w#w-d1t1985-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1985-2">
   <w.rf>
    <LM>w#w-d1t1985-2</LM>
   </w.rf>
   <form>dodnes</form>
   <lemma>dodnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1985-5">
   <w.rf>
    <LM>w#w-d1t1985-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d-id144307-punct">
   <w.rf>
    <LM>w#w-d-id144307-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1985-7">
   <w.rf>
    <LM>w#w-d1t1985-7</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1985-8">
   <w.rf>
    <LM>w#w-d1t1985-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1e1961-x3-74">
   <w.rf>
    <LM>w#w-d1e1961-x3-74</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-75">
  <m id="m054-d1t1992-4">
   <w.rf>
    <LM>w#w-d1t1992-4</LM>
   </w.rf>
   <form>Vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d-id144607-punct">
   <w.rf>
    <LM>w#w-d-id144607-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-75-88">
   <w.rf>
    <LM>w#w-75-88</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1992-7">
   <w.rf>
    <LM>w#w-d1t1992-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1992-8">
   <w.rf>
    <LM>w#w-d1t1992-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1992-9">
   <w.rf>
    <LM>w#w-d1t1992-9</LM>
   </w.rf>
   <form>učila</form>
   <lemma>učit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1992-11">
   <w.rf>
    <LM>w#w-d1t1992-11</LM>
   </w.rf>
   <form>náboženství</form>
   <lemma>náboženství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m054-d-id144702-punct">
   <w.rf>
    <LM>w#w-d-id144702-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1994-1">
   <w.rf>
    <LM>w#w-d1t1994-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1994-2">
   <w.rf>
    <LM>w#w-d1t1994-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1994-6">
   <w.rf>
    <LM>w#w-d1t1994-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t1994-9">
   <w.rf>
    <LM>w#w-d1t1994-9</LM>
   </w.rf>
   <form>Svatodušní</form>
   <lemma>svatodušní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m054-d1t1994-10">
   <w.rf>
    <LM>w#w-d1t1994-10</LM>
   </w.rf>
   <form>svátky</form>
   <lemma>svátek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m054-d1t1994-5">
   <w.rf>
    <LM>w#w-d1t1994-5</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1994-3">
   <w.rf>
    <LM>w#w-d1t1994-3</LM>
   </w.rf>
   <form>vodila</form>
   <lemma>vodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1994-4">
   <w.rf>
    <LM>w#w-d1t1994-4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-d1t1996-2">
   <w.rf>
    <LM>w#w-d1t1996-2</LM>
   </w.rf>
   <form>průvodem</form>
   <lemma>průvod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m054-d1t1996-3">
   <w.rf>
    <LM>w#w-d1t1996-3</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1996-5">
   <w.rf>
    <LM>w#w-d1t1996-5</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m054-75-81">
   <w.rf>
    <LM>w#w-75-81</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-87">
  <m id="m054-d1t1996-12">
   <w.rf>
    <LM>w#w-d1t1996-12</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1996-11">
   <w.rf>
    <LM>w#w-d1t1996-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1996-13">
   <w.rf>
    <LM>w#w-d1t1996-13</LM>
   </w.rf>
   <form>volné</form>
   <lemma>volný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m054-d1t1996-14">
   <w.rf>
    <LM>w#w-d1t1996-14</LM>
   </w.rf>
   <form>prostranství</form>
   <lemma>prostranství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m054-d-m-d1e1961-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1961-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1997-x2">
  <m id="m054-d1t2002-4">
   <w.rf>
    <LM>w#w-d1t2002-4</LM>
   </w.rf>
   <form>Dominikáni</form>
   <lemma>dominikán</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m054-d1t2004-4">
   <w.rf>
    <LM>w#w-d1t2004-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t2004-5">
   <w.rf>
    <LM>w#w-d1t2004-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t2012-1">
   <w.rf>
    <LM>w#w-d1t2012-1</LM>
   </w.rf>
   <form>známí</form>
   <lemma>známý-1_^(potkat_známého_[člověka])</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m054-d1e2009-x2-102">
   <w.rf>
    <LM>w#w-d1e2009-x2-102</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-103">
  <m id="m054-d1t2012-8">
   <w.rf>
    <LM>w#w-d1t2012-8</LM>
   </w.rf>
   <form>Znala</form>
   <lemma>znát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t2012-5">
   <w.rf>
    <LM>w#w-d1t2012-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t2012-6">
   <w.rf>
    <LM>w#w-d1t2012-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t2012-7">
   <w.rf>
    <LM>w#w-d1t2012-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t2012-3">
   <w.rf>
    <LM>w#w-d1t2012-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m054-d1t2012-4">
   <w.rf>
    <LM>w#w-d1t2012-4</LM>
   </w.rf>
   <form>všema</form>
   <lemma>všechen</lemma>
   <tag>PLXP7---------6</tag>
  </m>
  <m id="m054-103-104">
   <w.rf>
    <LM>w#w-103-104</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-117">
  <m id="m054-d1t2014-6">
   <w.rf>
    <LM>w#w-d1t2014-6</LM>
   </w.rf>
   <form>Vodila</form>
   <lemma>vodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t2014-3">
   <w.rf>
    <LM>w#w-d1t2014-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t2014-5">
   <w.rf>
    <LM>w#w-d1t2014-5</LM>
   </w.rf>
   <form>dětičky</form>
   <lemma>dětičky</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-d1t2014-7">
   <w.rf>
    <LM>w#w-d1t2014-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t2014-8">
   <w.rf>
    <LM>w#w-d1t2014-8</LM>
   </w.rf>
   <form>ony</form>
   <lemma>on-1</lemma>
   <tag>PEFP1--3-------</tag>
  </m>
  <m id="m054-d1t2014-9">
   <w.rf>
    <LM>w#w-d1t2014-9</LM>
   </w.rf>
   <form>sypaly</form>
   <lemma>sypat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1t2014-11">
   <w.rf>
    <LM>w#w-d1t2014-11</LM>
   </w.rf>
   <form>kytičky</form>
   <lemma>kytička</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-d1t2016-3">
   <w.rf>
    <LM>w#w-d1t2016-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t2016-5">
   <w.rf>
    <LM>w#w-d1t2016-5</LM>
   </w.rf>
   <form>zem</form>
   <lemma>země</lemma>
   <tag>NNFS4-----A---1</tag>
  </m>
  <m id="m054-117-118">
   <w.rf>
    <LM>w#w-117-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-119">
  <m id="m054-d1t2016-9">
   <w.rf>
    <LM>w#w-d1t2016-9</LM>
   </w.rf>
   <form>Svatodušní</form>
   <lemma>svatodušní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m054-d1t2016-10">
   <w.rf>
    <LM>w#w-d1t2016-10</LM>
   </w.rf>
   <form>svátky</form>
   <lemma>svátek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m054-d1t2016-12">
   <w.rf>
    <LM>w#w-d1t2016-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t2016-13">
   <w.rf>
    <LM>w#w-d1t2016-13</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t2016-14">
   <w.rf>
    <LM>w#w-d1t2016-14</LM>
   </w.rf>
   <form>světily</form>
   <lemma>světit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-119-120">
   <w.rf>
    <LM>w#w-119-120</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
