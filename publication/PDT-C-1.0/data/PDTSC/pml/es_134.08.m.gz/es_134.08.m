<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="es_134.08.w.gz" />
  </references>
 </head>
 <s id="m134-d1e963-x3">
  <m id="m134-d1t970-1">
   <w.rf>
    <LM>w#w-d1t970-1</LM>
   </w.rf>
   <form>Žijete</form>
   <lemma>žít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d1t970-2">
   <w.rf>
    <LM>w#w-d1t970-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t970-3">
   <w.rf>
    <LM>w#w-d1t970-3</LM>
   </w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrMS7----------</tag>
  </m>
  <m id="m134-d1t970-4">
   <w.rf>
    <LM>w#w-d1t970-4</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m134-d1t970-5">
   <w.rf>
    <LM>w#w-d1t970-5</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d-id146803-punct">
   <w.rf>
    <LM>w#w-d-id146803-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e971-x2">
  <m id="m134-d1t974-1">
   <w.rf>
    <LM>w#w-d1t974-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d-id146880-punct">
   <w.rf>
    <LM>w#w-d-id146880-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t974-3">
   <w.rf>
    <LM>w#w-d1t974-3</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t974-4">
   <w.rf>
    <LM>w#w-d1t974-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1e971-x2-1225">
   <w.rf>
    <LM>w#w-d1e971-x2-1225</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m134-d1t974-5">
   <w.rf>
    <LM>w#w-d1t974-5</LM>
   </w.rf>
   <form>1993</form>
   <lemma>1993</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1t974-7">
   <w.rf>
    <LM>w#w-d1t974-7</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d-id146967-punct">
   <w.rf>
    <LM>w#w-d-id146967-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t974-9">
   <w.rf>
    <LM>w#w-d1t974-9</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t974-10">
   <w.rf>
    <LM>w#w-d1t974-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t974-11">
   <w.rf>
    <LM>w#w-d1t974-11</LM>
   </w.rf>
   <form>vdova</form>
   <lemma>vdova</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-m-d1e971-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e971-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e976-x2">
  <m id="m134-d1t979-1">
   <w.rf>
    <LM>w#w-d1t979-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t979-2">
   <w.rf>
    <LM>w#w-d1t979-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t979-3">
   <w.rf>
    <LM>w#w-d1t979-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t979-4">
   <w.rf>
    <LM>w#w-d1t979-4</LM>
   </w.rf>
   <form>líto</form>
   <lemma>líto</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d-m-d1e976-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e976-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e980-x2">
  <m id="m134-d1t983-2">
   <w.rf>
    <LM>w#w-d1t983-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t983-3">
   <w.rf>
    <LM>w#w-d1t983-3</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t983-4">
   <w.rf>
    <LM>w#w-d1t983-4</LM>
   </w.rf>
   <form>pracovitý</form>
   <lemma>pracovitý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m134-d1t983-5">
   <w.rf>
    <LM>w#w-d1t983-5</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t983-6">
   <w.rf>
    <LM>w#w-d1t983-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t983-7">
   <w.rf>
    <LM>w#w-d1t983-7</LM>
   </w.rf>
   <form>nedbal</form>
   <lemma>dbát</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m134-d1t983-8">
   <w.rf>
    <LM>w#w-d1t983-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t983-9">
   <w.rf>
    <LM>w#w-d1t983-9</LM>
   </w.rf>
   <form>svoje</form>
   <lemma>svůj-1</lemma>
   <tag>P8NS4----------</tag>
  </m>
  <m id="m134-d1t983-10">
   <w.rf>
    <LM>w#w-d1t983-10</LM>
   </w.rf>
   <form>zdraví</form>
   <lemma>zdraví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m134-d-id147345-punct">
   <w.rf>
    <LM>w#w-d-id147345-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t983-12">
   <w.rf>
    <LM>w#w-d1t983-12</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t983-13">
   <w.rf>
    <LM>w#w-d1t983-13</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t983-14">
   <w.rf>
    <LM>w#w-d1t983-14</LM>
   </w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m134-d1t983-15">
   <w.rf>
    <LM>w#w-d1t983-15</LM>
   </w.rf>
   <form>infarktů</form>
   <lemma>infarkt</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m134-d1e980-x2-1240">
   <w.rf>
    <LM>w#w-d1e980-x2-1240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-1238">
  <m id="m134-d1t983-18">
   <w.rf>
    <LM>w#w-d1t983-18</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t983-24">
   <w.rf>
    <LM>w#w-d1t983-24</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m134-d1t983-25">
   <w.rf>
    <LM>w#w-d1t983-25</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t983-20">
   <w.rf>
    <LM>w#w-d1t983-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t983-22">
   <w.rf>
    <LM>w#w-d1t983-22</LM>
   </w.rf>
   <form>Bulovce</form>
   <lemma>Bulovka_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t983-26">
   <w.rf>
    <LM>w#w-d1t983-26</LM>
   </w.rf>
   <form>pitvali</form>
   <lemma>pitvat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d-id147566-punct">
   <w.rf>
    <LM>w#w-d-id147566-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t983-30">
   <w.rf>
    <LM>w#w-d1t983-30</LM>
   </w.rf>
   <form>divili</form>
   <lemma>divit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t983-29">
   <w.rf>
    <LM>w#w-d1t983-29</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-1238-1249">
   <w.rf>
    <LM>w#w-1238-1249</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t983-31">
   <w.rf>
    <LM>w#w-d1t983-31</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t983-32">
   <w.rf>
    <LM>w#w-d1t983-32</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t983-33">
   <w.rf>
    <LM>w#w-d1t983-33</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m134-d-id147668-punct">
   <w.rf>
    <LM>w#w-d-id147668-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t983-35">
   <w.rf>
    <LM>w#w-d1t983-35</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t983-37">
   <w.rf>
    <LM>w#w-d1t983-37</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t983-38">
   <w.rf>
    <LM>w#w-d1t983-38</LM>
   </w.rf>
   <form>srdce</form>
   <lemma>srdce</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m134-d1t983-36">
   <w.rf>
    <LM>w#w-d1t983-36</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t983-40">
   <w.rf>
    <LM>w#w-d1t983-40</LM>
   </w.rf>
   <form>zvládlo</form>
   <lemma>zvládnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m134-d-id147785-punct">
   <w.rf>
    <LM>w#w-d-id147785-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t983-43">
   <w.rf>
    <LM>w#w-d1t983-43</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t983-46">
   <w.rf>
    <LM>w#w-d1t983-46</LM>
   </w.rf>
   <form>žil</form>
   <lemma>žít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-1238-314">
   <w.rf>
    <LM>w#w-1238-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-317">
  <m id="m134-d1t983-49">
   <w.rf>
    <LM>w#w-d1t983-49</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t983-50">
   <w.rf>
    <LM>w#w-d1t983-50</LM>
   </w.rf>
   <form>srdce</form>
   <lemma>srdce</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m134-d1t983-51">
   <w.rf>
    <LM>w#w-d1t983-51</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t983-52">
   <w.rf>
    <LM>w#w-d1t983-52</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m134-d1t983-53">
   <w.rf>
    <LM>w#w-d1t983-53</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t983-54">
   <w.rf>
    <LM>w#w-d1t983-54</LM>
   </w.rf>
   <form>špatném</form>
   <lemma>špatný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m134-d1t983-55">
   <w.rf>
    <LM>w#w-d1t983-55</LM>
   </w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-1238-1250">
   <w.rf>
    <LM>w#w-1238-1250</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-1239">
  <m id="m134-d1t985-1">
   <w.rf>
    <LM>w#w-d1t985-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t985-2">
   <w.rf>
    <LM>w#w-d1t985-2</LM>
   </w.rf>
   <form>nemocnou</form>
   <lemma>nemocný-2_^(vlastnost)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m134-d1t985-3">
   <w.rf>
    <LM>w#w-d1t985-3</LM>
   </w.rf>
   <form>slinivku</form>
   <lemma>slinivka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id148051-punct">
   <w.rf>
    <LM>w#w-d-id148051-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t985-5">
   <w.rf>
    <LM>w#w-d1t985-5</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t985-6">
   <w.rf>
    <LM>w#w-d1t985-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t985-7">
   <w.rf>
    <LM>w#w-d1t985-7</LM>
   </w.rf>
   <form>cukrovku</form>
   <lemma>cukrovka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id148106-punct">
   <w.rf>
    <LM>w#w-d-id148106-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t985-9">
   <w.rf>
    <LM>w#w-d1t985-9</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t985-10">
   <w.rf>
    <LM>w#w-d1t985-10</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t985-11">
   <w.rf>
    <LM>w#w-d1t985-11</LM>
   </w.rf>
   <form>zdravotnice</form>
   <lemma>zdravotnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t985-13">
   <w.rf>
    <LM>w#w-d1t985-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t985-14">
   <w.rf>
    <LM>w#w-d1t985-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t985-15">
   <w.rf>
    <LM>w#w-d1t985-15</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t985-16">
   <w.rf>
    <LM>w#w-d1t985-16</LM>
   </w.rf>
   <form>něho</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3------1</tag>
  </m>
  <m id="m134-d1t985-17">
   <w.rf>
    <LM>w#w-d1t985-17</LM>
   </w.rf>
   <form>starala</form>
   <lemma>starat_^(se)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-1239-1267">
   <w.rf>
    <LM>w#w-1239-1267</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-1266">
  <m id="m134-d1t987-2">
   <w.rf>
    <LM>w#w-d1t987-2</LM>
   </w.rf>
   <form>Odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1t987-3">
   <w.rf>
    <LM>w#w-d1t987-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d-id148340-punct">
   <w.rf>
    <LM>w#w-d-id148340-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t987-5">
   <w.rf>
    <LM>w#w-d1t987-5</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t987-6">
   <w.rf>
    <LM>w#w-d1t987-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t987-7">
   <w.rf>
    <LM>w#w-d1t987-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t987-8">
   <w.rf>
    <LM>w#w-d1t987-8</LM>
   </w.rf>
   <form>vdova</form>
   <lemma>vdova</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-m-d1e980-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e980-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e988-x2">
  <m id="m134-d1t991-1">
   <w.rf>
    <LM>w#w-d1t991-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t991-2">
   <w.rf>
    <LM>w#w-d1t991-2</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t991-3">
   <w.rf>
    <LM>w#w-d1t991-3</LM>
   </w.rf>
   <form>žijete</form>
   <lemma>žít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d-id148510-punct">
   <w.rf>
    <LM>w#w-d-id148510-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e992-x2">
  <m id="m134-d1t997-2">
   <w.rf>
    <LM>w#w-d1t997-2</LM>
   </w.rf>
   <form>Odešla</form>
   <lemma>odejít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t997-3">
   <w.rf>
    <LM>w#w-d1t997-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t997-4">
   <w.rf>
    <LM>w#w-d1t997-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t997-6">
   <w.rf>
    <LM>w#w-d1t997-6</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-d-id148676-punct">
   <w.rf>
    <LM>w#w-d-id148676-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t997-9">
   <w.rf>
    <LM>w#w-d1t997-9</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t997-10">
   <w.rf>
    <LM>w#w-d1t997-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t997-11">
   <w.rf>
    <LM>w#w-d1t997-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t997-12">
   <w.rf>
    <LM>w#w-d1t997-12</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m134-d1t997-14">
   <w.rf>
    <LM>w#w-d1t997-14</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t997-16">
   <w.rf>
    <LM>w#w-d1t997-16</LM>
   </w.rf>
   <form>ČKD</form>
   <lemma>ČKD_;m_^(Českomoravská_Kolben-Daněk)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m134-d1t999-1">
   <w.rf>
    <LM>w#w-d1t999-1</LM>
   </w.rf>
   <form>Polovodičů</form>
   <lemma>polovodič</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m134-d1e992-x2-107">
   <w.rf>
    <LM>w#w-d1e992-x2-107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-102">
  <m id="m134-d1t1001-6">
   <w.rf>
    <LM>w#w-d1t1001-6</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1001-7">
   <w.rf>
    <LM>w#w-d1t1001-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1001-8">
   <w.rf>
    <LM>w#w-d1t1001-8</LM>
   </w.rf>
   <form>sestře</form>
   <lemma>sestra</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m134-d1t1001-9">
   <w.rf>
    <LM>w#w-d1t1001-9</LM>
   </w.rf>
   <form>prodala</form>
   <lemma>prodat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t1001-10">
   <w.rf>
    <LM>w#w-d1t1001-10</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t1001-11">
   <w.rf>
    <LM>w#w-d1t1001-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1001-13">
   <w.rf>
    <LM>w#w-d1t1001-13</LM>
   </w.rf>
   <form>Opočně</form>
   <lemma>Opočno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m134-d-id149033-punct">
   <w.rf>
    <LM>w#w-d-id149033-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1001-18">
   <w.rf>
    <LM>w#w-d1t1001-18</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1001-17">
   <w.rf>
    <LM>w#w-d1t1001-17</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1001-19">
   <w.rf>
    <LM>w#w-d1t1001-19</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t1001-20">
   <w.rf>
    <LM>w#w-d1t1001-20</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m134-d1t1001-21">
   <w.rf>
    <LM>w#w-d1t1001-21</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d-id149135-punct">
   <w.rf>
    <LM>w#w-d-id149135-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1001-16">
   <w.rf>
    <LM>w#w-d1t1001-16</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1001-24">
   <w.rf>
    <LM>w#w-d1t1001-24</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1001-25">
   <w.rf>
    <LM>w#w-d1t1001-25</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t1001-23">
   <w.rf>
    <LM>w#w-d1t1001-23</LM>
   </w.rf>
   <form>odstěhovala</form>
   <lemma>odstěhovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t1001-26">
   <w.rf>
    <LM>w#w-d1t1001-26</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t1001-28">
   <w.rf>
    <LM>w#w-d1t1001-28</LM>
   </w.rf>
   <form>Slané</form>
   <lemma>Slaná_;G_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-102-116">
   <w.rf>
    <LM>w#w-102-116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-100">
  <m id="m134-d1t1003-1">
   <w.rf>
    <LM>w#w-d1t1003-1</LM>
   </w.rf>
   <form>Koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t1003-2">
   <w.rf>
    <LM>w#w-d1t1003-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1003-3">
   <w.rf>
    <LM>w#w-d1t1003-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1003-4">
   <w.rf>
    <LM>w#w-d1t1003-4</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t1003-5">
   <w.rf>
    <LM>w#w-d1t1003-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t1003-6">
   <w.rf>
    <LM>w#w-d1t1003-6</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d1t1003-7">
   <w.rf>
    <LM>w#w-d1t1003-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t1003-8">
   <w.rf>
    <LM>w#w-d1t1003-8</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m134-d1t1003-9">
   <w.rf>
    <LM>w#w-d1t1003-9</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d-id149394-punct">
   <w.rf>
    <LM>w#w-d-id149394-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1003-11">
   <w.rf>
    <LM>w#w-d1t1003-11</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1003-12">
   <w.rf>
    <LM>w#w-d1t1003-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1003-15">
   <w.rf>
    <LM>w#w-d1t1003-15</LM>
   </w.rf>
   <form>vzniklo</form>
   <lemma>vzniknout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m134-d1t1003-16">
   <w.rf>
    <LM>w#w-d1t1003-16</LM>
   </w.rf>
   <form>minidružstvo</form>
   <lemma>minidružstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m134-100-345">
   <w.rf>
    <LM>w#w-100-345</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-350">
  <m id="m134-d1t1003-20">
   <w.rf>
    <LM>w#w-d1t1003-20</LM>
   </w.rf>
   <form>Nabídli</form>
   <lemma>nabídnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m134-d1t1003-19">
   <w.rf>
    <LM>w#w-d1t1003-19</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t1003-21">
   <w.rf>
    <LM>w#w-d1t1003-21</LM>
   </w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1003-23">
   <w.rf>
    <LM>w#w-d1t1003-23</LM>
   </w.rf>
   <form>vstoupit</form>
   <lemma>vstoupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d1t1003-24">
   <w.rf>
    <LM>w#w-d1t1003-24</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t1003-25">
   <w.rf>
    <LM>w#w-d1t1003-25</LM>
   </w.rf>
   <form>minidružstva</form>
   <lemma>minidružstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m134-350-353">
   <w.rf>
    <LM>w#w-350-353</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1008-1">
   <w.rf>
    <LM>w#w-d1t1008-1</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1008-2">
   <w.rf>
    <LM>w#w-d1t1008-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m134-d1t1008-3">
   <w.rf>
    <LM>w#w-d1t1008-3</LM>
   </w.rf>
   <form>vložit</form>
   <lemma>vložit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d1t1008-4">
   <w.rf>
    <LM>w#w-d1t1008-4</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d-id149715-punct">
   <w.rf>
    <LM>w#w-d-id149715-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1008-6">
   <w.rf>
    <LM>w#w-d1t1008-6</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m134-d1t1008-7">
   <w.rf>
    <LM>w#w-d1t1008-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1008-8">
   <w.rf>
    <LM>w#w-d1t1008-8</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m134-350-351">
   <w.rf>
    <LM>w#w-350-351</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-352">
  <m id="m134-d1t1010-2">
   <w.rf>
    <LM>w#w-d1t1010-2</LM>
   </w.rf>
   <form>Anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-352-354">
   <w.rf>
    <LM>w#w-352-354</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-100-130">
   <w.rf>
    <LM>w#w-100-130</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m134-352-355">
   <w.rf>
    <LM>w#w-352-355</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1010-3">
   <w.rf>
    <LM>w#w-d1t1010-3</LM>
   </w.rf>
   <form>nabídnout</form>
   <lemma>nabídnout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d1t1010-4">
   <w.rf>
    <LM>w#w-d1t1010-4</LM>
   </w.rf>
   <form>někomu</form>
   <lemma>někdo</lemma>
   <tag>PK--3----------</tag>
  </m>
  <m id="m134-d-id149848-punct">
   <w.rf>
    <LM>w#w-d-id149848-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1010-6">
   <w.rf>
    <LM>w#w-d1t1010-6</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m134-d1t1012-2">
   <w.rf>
    <LM>w#w-d1t1012-2</LM>
   </w.rf>
   <form>uhradí</form>
   <lemma>uhradit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m134-d1t1012-6">
   <w.rf>
    <LM>w#w-d1t1012-6</LM>
   </w.rf>
   <form>vstup</form>
   <lemma>vstup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t1012-7">
   <w.rf>
    <LM>w#w-d1t1012-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t1012-9">
   <w.rf>
    <LM>w#w-d1t1012-9</LM>
   </w.rf>
   <form>minidružstva</form>
   <lemma>minidružstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m134-100-131">
   <w.rf>
    <LM>w#w-100-131</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1012-13">
   <w.rf>
    <LM>w#w-d1t1012-13</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m134-d1t1012-14">
   <w.rf>
    <LM>w#w-d1t1012-14</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t1012-15">
   <w.rf>
    <LM>w#w-d1t1012-15</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m134-d1t1012-16">
   <w.rf>
    <LM>w#w-d1t1012-16</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-100-132">
   <w.rf>
    <LM>w#w-100-132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-69">
  <m id="m134-d1t1012-18">
   <w.rf>
    <LM>w#w-d1t1012-18</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1012-19">
   <w.rf>
    <LM>w#w-d1t1012-19</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1012-20">
   <w.rf>
    <LM>w#w-d1t1012-20</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t1012-21">
   <w.rf>
    <LM>w#w-d1t1012-21</LM>
   </w.rf>
   <form>koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t1012-22">
   <w.rf>
    <LM>w#w-d1t1012-22</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t1012-23">
   <w.rf>
    <LM>w#w-d1t1012-23</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t1012-25">
   <w.rf>
    <LM>w#w-d1t1012-25</LM>
   </w.rf>
   <form>Slaným</form>
   <lemma>Slaný-1_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m134-69-137">
   <w.rf>
    <LM>w#w-69-137</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-68">
  <m id="m134-d1t1014-1">
   <w.rf>
    <LM>w#w-d1t1014-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t1014-2">
   <w.rf>
    <LM>w#w-d1t1014-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1014-4">
   <w.rf>
    <LM>w#w-d1t1014-4</LM>
   </w.rf>
   <form>Křovice</form>
   <lemma>Křovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m134-68-227">
   <w.rf>
    <LM>w#w-68-227</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1014-7">
   <w.rf>
    <LM>w#w-d1t1014-7</LM>
   </w.rf>
   <form>Skůry</form>
   <lemma>Skůry_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m134-68-148">
   <w.rf>
    <LM>w#w-68-148</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-147">
  <m id="m134-d1t1016-1">
   <w.rf>
    <LM>w#w-d1t1016-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t1016-2">
   <w.rf>
    <LM>w#w-d1t1016-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1016-3">
   <w.rf>
    <LM>w#w-d1t1016-3</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m134-d1t1016-4">
   <w.rf>
    <LM>w#w-d1t1016-4</LM>
   </w.rf>
   <form>kilometrů</form>
   <lemma>kilometr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m134-d1t1016-5">
   <w.rf>
    <LM>w#w-d1t1016-5</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t1016-7">
   <w.rf>
    <LM>w#w-d1t1016-7</LM>
   </w.rf>
   <form>Slaného</form>
   <lemma>Slaný-1_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-147-154">
   <w.rf>
    <LM>w#w-147-154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-67">
  <m id="m134-d1t1021-2">
   <w.rf>
    <LM>w#w-d1t1021-2</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1021-3">
   <w.rf>
    <LM>w#w-d1t1021-3</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m134-d1t1021-5">
   <w.rf>
    <LM>w#w-d1t1021-5</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m134-d1t1021-4">
   <w.rf>
    <LM>w#w-d1t1021-4</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t1021-6">
   <w.rf>
    <LM>w#w-d1t1021-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t1021-7">
   <w.rf>
    <LM>w#w-d1t1021-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1021-9">
   <w.rf>
    <LM>w#w-d1t1021-9</LM>
   </w.rf>
   <form>Kladně</form>
   <lemma>Kladno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m134-d-id150686-punct">
   <w.rf>
    <LM>w#w-d-id150686-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1021-14">
   <w.rf>
    <LM>w#w-d1t1021-14</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m134-d1t1021-13">
   <w.rf>
    <LM>w#w-d1t1021-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1021-15">
   <w.rf>
    <LM>w#w-d1t1021-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1021-16">
   <w.rf>
    <LM>w#w-d1t1021-16</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-67-160">
   <w.rf>
    <LM>w#w-67-160</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e992-x4">
  <m id="m134-d1t1023-5">
   <w.rf>
    <LM>w#w-d1t1023-5</LM>
   </w.rf>
   <form>Koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t1023-2">
   <w.rf>
    <LM>w#w-d1t1023-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1023-3">
   <w.rf>
    <LM>w#w-d1t1023-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t1023-4">
   <w.rf>
    <LM>w#w-d1t1023-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1023-6">
   <w.rf>
    <LM>w#w-d1t1023-6</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t1023-7">
   <w.rf>
    <LM>w#w-d1t1023-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1023-8">
   <w.rf>
    <LM>w#w-d1t1023-8</LM>
   </w.rf>
   <form>začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t1023-9">
   <w.rf>
    <LM>w#w-d1t1023-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1023-10">
   <w.rf>
    <LM>w#w-d1t1023-10</LM>
   </w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1023-11">
   <w.rf>
    <LM>w#w-d1t1023-11</LM>
   </w.rf>
   <form>budovat</form>
   <lemma>budovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1e992-x4-181">
   <w.rf>
    <LM>w#w-d1e992-x4-181</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-172">
  <m id="m134-d1t1025-1">
   <w.rf>
    <LM>w#w-d1t1025-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t1025-2">
   <w.rf>
    <LM>w#w-d1t1025-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1025-3">
   <w.rf>
    <LM>w#w-d1t1025-3</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m134-d1t1025-4">
   <w.rf>
    <LM>w#w-d1t1025-4</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-172-186">
   <w.rf>
    <LM>w#w-172-186</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-172-187">
   <w.rf>
    <LM>w#w-172-187</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1027-1">
   <w.rf>
    <LM>w#w-d1t1027-1</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1027-2">
   <w.rf>
    <LM>w#w-d1t1027-2</LM>
   </w.rf>
   <form>studna</form>
   <lemma>studna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id151074-punct">
   <w.rf>
    <LM>w#w-d-id151074-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1027-4">
   <w.rf>
    <LM>w#w-d1t1027-4</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m134-d1t1027-5">
   <w.rf>
    <LM>w#w-d1t1027-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t1027-6">
   <w.rf>
    <LM>w#w-d1t1027-6</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1027-7">
   <w.rf>
    <LM>w#w-d1t1027-7</LM>
   </w.rf>
   <form>prohloubit</form>
   <lemma>prohloubit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-172-379">
   <w.rf>
    <LM>w#w-172-379</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-380">
  <m id="m134-172-189">
   <w.rf>
    <LM>w#w-172-189</LM>
   </w.rf>
   <form>Musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-172-190">
   <w.rf>
    <LM>w#w-172-190</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1029-1">
   <w.rf>
    <LM>w#w-d1t1029-1</LM>
   </w.rf>
   <form>zavést</form>
   <lemma>zavést</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d1t1029-2">
   <w.rf>
    <LM>w#w-d1t1029-2</LM>
   </w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t1029-3">
   <w.rf>
    <LM>w#w-d1t1029-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t1029-4">
   <w.rf>
    <LM>w#w-d1t1029-4</LM>
   </w.rf>
   <form>baráku</form>
   <lemma>barák</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-d-id151222-punct">
   <w.rf>
    <LM>w#w-d-id151222-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1032-1">
   <w.rf>
    <LM>w#w-d1t1032-1</LM>
   </w.rf>
   <form>udělat</form>
   <lemma>udělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d1t1032-2">
   <w.rf>
    <LM>w#w-d1t1032-2</LM>
   </w.rf>
   <form>septik</form>
   <lemma>septik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-380-381">
   <w.rf>
    <LM>w#w-380-381</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-386">
  <m id="m134-d1t1032-4">
   <w.rf>
    <LM>w#w-d1t1032-4</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1032-5">
   <w.rf>
    <LM>w#w-d1t1032-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1032-6">
   <w.rf>
    <LM>w#w-d1t1032-6</LM>
   </w.rf>
   <form>udělala</form>
   <lemma>udělat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t1032-7">
   <w.rf>
    <LM>w#w-d1t1032-7</LM>
   </w.rf>
   <form>přístavbu</form>
   <lemma>přístavba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id151357-punct">
   <w.rf>
    <LM>w#w-d-id151357-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1032-9">
   <w.rf>
    <LM>w#w-d1t1032-9</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1032-10">
   <w.rf>
    <LM>w#w-d1t1032-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1032-11">
   <w.rf>
    <LM>w#w-d1t1032-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t1032-12">
   <w.rf>
    <LM>w#w-d1t1032-12</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t1032-13">
   <w.rf>
    <LM>w#w-d1t1032-13</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m134-d1t1032-14">
   <w.rf>
    <LM>w#w-d1t1032-14</LM>
   </w.rf>
   <form>vytvořila</form>
   <lemma>vytvořit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t1032-15">
   <w.rf>
    <LM>w#w-d1t1032-15</LM>
   </w.rf>
   <form>domeček</form>
   <lemma>domeček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t1032-17">
   <w.rf>
    <LM>w#w-d1t1032-17</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1t1032-18">
   <w.rf>
    <LM>w#w-d1t1032-18</LM>
   </w.rf>
   <form>+</form>
   <lemma>+</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1032-19">
   <w.rf>
    <LM>w#w-d1t1032-19</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-172-191">
   <w.rf>
    <LM>w#w-172-191</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-174">
  <m id="m134-d1t1034-1">
   <w.rf>
    <LM>w#w-d1t1034-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t1034-2">
   <w.rf>
    <LM>w#w-d1t1034-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1034-3">
   <w.rf>
    <LM>w#w-d1t1034-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1034-4">
   <w.rf>
    <LM>w#w-d1t1034-4</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1034-5">
   <w.rf>
    <LM>w#w-d1t1034-5</LM>
   </w.rf>
   <form>letní</form>
   <lemma>letní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m134-d1t1034-6">
   <w.rf>
    <LM>w#w-d1t1034-6</LM>
   </w.rf>
   <form>bydlení</form>
   <lemma>bydlení_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m134-d1t1034-7">
   <w.rf>
    <LM>w#w-d1t1034-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1034-8">
   <w.rf>
    <LM>w#w-d1t1034-8</LM>
   </w.rf>
   <form>dvoře</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d1t1034-9">
   <w.rf>
    <LM>w#w-d1t1034-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1034-10">
   <w.rf>
    <LM>w#w-d1t1034-10</LM>
   </w.rf>
   <form>zahrádka</form>
   <lemma>zahrádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-174-192">
   <w.rf>
    <LM>w#w-174-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-175">
  <m id="m134-d1t1036-2">
   <w.rf>
    <LM>w#w-d1t1036-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1036-3">
   <w.rf>
    <LM>w#w-d1t1036-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1036-6">
   <w.rf>
    <LM>w#w-d1t1036-6</LM>
   </w.rf>
   <form>osada</form>
   <lemma>osada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t1036-7">
   <w.rf>
    <LM>w#w-d1t1036-7</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t1036-8">
   <w.rf>
    <LM>w#w-d1t1036-8</LM>
   </w.rf>
   <form>statku</form>
   <lemma>statek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-175-193">
   <w.rf>
    <LM>w#w-175-193</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-176">
  <m id="m134-d1t1038-3">
   <w.rf>
    <LM>w#w-d1t1038-3</LM>
   </w.rf>
   <form>Patřilo</form>
   <lemma>patřit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t1038-2">
   <w.rf>
    <LM>w#w-d1t1038-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1038-5">
   <w.rf>
    <LM>w#w-d1t1038-5</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t1038-8">
   <w.rf>
    <LM>w#w-d1t1038-8</LM>
   </w.rf>
   <form>Hobšovice</form>
   <lemma>Hobšovice_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-d1t1038-10">
   <w.rf>
    <LM>w#w-d1t1038-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1038-12">
   <w.rf>
    <LM>w#w-d1t1038-12</LM>
   </w.rf>
   <form>Skůry</form>
   <lemma>Skůry_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-d-id152037-punct">
   <w.rf>
    <LM>w#w-d-id152037-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1038-15">
   <w.rf>
    <LM>w#w-d1t1038-15</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t1038-16">
   <w.rf>
    <LM>w#w-d1t1038-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1038-17">
   <w.rf>
    <LM>w#w-d1t1038-17</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1038-18">
   <w.rf>
    <LM>w#w-d1t1038-18</LM>
   </w.rf>
   <form>patnáct</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m134-d1t1038-19">
   <w.rf>
    <LM>w#w-d1t1038-19</LM>
   </w.rf>
   <form>baráků</form>
   <lemma>barák</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m134-176-258">
   <w.rf>
    <LM>w#w-176-258</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-212">
  <m id="m134-d1t1040-1">
   <w.rf>
    <LM>w#w-d1t1040-1</LM>
   </w.rf>
   <form>Žilo</form>
   <lemma>žít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t1040-2">
   <w.rf>
    <LM>w#w-d1t1040-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t1040-3">
   <w.rf>
    <LM>w#w-d1t1040-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t1040-4">
   <w.rf>
    <LM>w#w-d1t1040-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1040-5">
   <w.rf>
    <LM>w#w-d1t1040-5</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1040-6">
   <w.rf>
    <LM>w#w-d1t1040-6</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-212-396">
   <w.rf>
    <LM>w#w-212-396</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-411">
  <m id="m134-d1t1040-9">
   <w.rf>
    <LM>w#w-d1t1040-9</LM>
   </w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m134-d1t1040-10">
   <w.rf>
    <LM>w#w-d1t1040-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m134-d1t1040-11">
   <w.rf>
    <LM>w#w-d1t1040-11</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m134-d-id152302-punct">
   <w.rf>
    <LM>w#w-d-id152302-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1040-13">
   <w.rf>
    <LM>w#w-d1t1040-13</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1040-14">
   <w.rf>
    <LM>w#w-d1t1040-14</LM>
   </w.rf>
   <form>nejsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m134-d1t1040-15">
   <w.rf>
    <LM>w#w-d1t1040-15</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t1040-16">
   <w.rf>
    <LM>w#w-d1t1040-16</LM>
   </w.rf>
   <form>komunikativní</form>
   <lemma>komunikativní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d-id152373-punct">
   <w.rf>
    <LM>w#w-d-id152373-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-411-412">
   <w.rf>
    <LM>w#w-411-412</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t1040-20">
   <w.rf>
    <LM>w#w-d1t1040-20</LM>
   </w.rf>
   <form>netrvalo</form>
   <lemma>trvat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m134-d1t1040-21">
   <w.rf>
    <LM>w#w-d1t1040-21</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t1040-22">
   <w.rf>
    <LM>w#w-d1t1040-22</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1040-23">
   <w.rf>
    <LM>w#w-d1t1040-23</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m134-d1t1040-24">
   <w.rf>
    <LM>w#w-d1t1040-24</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m134-d1t1040-25">
   <w.rf>
    <LM>w#w-d1t1040-25</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m134-d1t1040-26">
   <w.rf>
    <LM>w#w-d1t1040-26</LM>
   </w.rf>
   <form>vesnici</form>
   <lemma>vesnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t1040-27">
   <w.rf>
    <LM>w#w-d1t1040-27</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t1040-28">
   <w.rf>
    <LM>w#w-d1t1040-28</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1040-29">
   <w.rf>
    <LM>w#w-d1t1040-29</LM>
   </w.rf>
   <form>začaly</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m134-d1t1040-30">
   <w.rf>
    <LM>w#w-d1t1040-30</LM>
   </w.rf>
   <form>řikat</form>
   <lemma>řikat_,h_^(^GC**říkat)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-212-264">
   <w.rf>
    <LM>w#w-212-264</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1040-31">
   <w.rf>
    <LM>w#w-d1t1040-31</LM>
   </w.rf>
   <form>babičko</form>
   <lemma>babička</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m134-212-265">
   <w.rf>
    <LM>w#w-212-265</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-212-266">
   <w.rf>
    <LM>w#w-212-266</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-252">
  <m id="m134-d1t1040-35">
   <w.rf>
    <LM>w#w-d1t1040-35</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1040-36">
   <w.rf>
    <LM>w#w-d1t1040-36</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1040-37">
   <w.rf>
    <LM>w#w-d1t1040-37</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1040-38">
   <w.rf>
    <LM>w#w-d1t1040-38</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m134-d-id152701-punct">
   <w.rf>
    <LM>w#w-d-id152701-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1040-40">
   <w.rf>
    <LM>w#w-d1t1040-40</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m134-d1t1040-41">
   <w.rf>
    <LM>w#w-d1t1040-41</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t1040-42">
   <w.rf>
    <LM>w#w-d1t1040-42</LM>
   </w.rf>
   <form>pomáhali</form>
   <lemma>pomáhat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t1040-43">
   <w.rf>
    <LM>w#w-d1t1040-43</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m134-d1t1040-44">
   <w.rf>
    <LM>w#w-d1t1040-44</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t1040-45">
   <w.rf>
    <LM>w#w-d1t1040-45</LM>
   </w.rf>
   <form>budovat</form>
   <lemma>budovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-252-430">
   <w.rf>
    <LM>w#w-252-430</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-431">
  <m id="m134-d1t1040-48">
   <w.rf>
    <LM>w#w-d1t1040-48</LM>
   </w.rf>
   <form>Zjistili</form>
   <lemma>zjistit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m134-d-id152849-punct">
   <w.rf>
    <LM>w#w-d-id152849-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1040-50">
   <w.rf>
    <LM>w#w-d1t1040-50</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1040-51">
   <w.rf>
    <LM>w#w-d1t1040-51</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1042-1">
   <w.rf>
    <LM>w#w-d1t1042-1</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d-id152913-punct">
   <w.rf>
    <LM>w#w-d-id152913-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1042-3">
   <w.rf>
    <LM>w#w-d1t1042-3</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m134-d1t1045-1">
   <w.rf>
    <LM>w#w-d1t1045-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-252-281">
   <w.rf>
    <LM>w#w-252-281</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1045-2">
   <w.rf>
    <LM>w#w-d1t1045-2</LM>
   </w.rf>
   <form>dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m134-252-282">
   <w.rf>
    <LM>w#w-252-282</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-252-283">
   <w.rf>
    <LM>w#w-252-283</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-251">
  <m id="m134-d1t1047-1">
   <w.rf>
    <LM>w#w-d1t1047-1</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m134-d1t1047-2">
   <w.rf>
    <LM>w#w-d1t1047-2</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t1047-3">
   <w.rf>
    <LM>w#w-d1t1047-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1047-5">
   <w.rf>
    <LM>w#w-d1t1047-5</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t1047-7">
   <w.rf>
    <LM>w#w-d1t1047-7</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m134-d1t1047-8">
   <w.rf>
    <LM>w#w-d1t1047-8</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-251-305">
   <w.rf>
    <LM>w#w-251-305</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-251-306">
   <w.rf>
    <LM>w#w-251-306</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1047-10">
   <w.rf>
    <LM>w#w-d1t1047-10</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ty</lemma>
   <tag>PP-S1--2-------</tag>
  </m>
  <m id="m134-d1t1047-11">
   <w.rf>
    <LM>w#w-d1t1047-11</LM>
   </w.rf>
   <form>jsi</form>
   <lemma>být</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="m134-d1t1047-12">
   <w.rf>
    <LM>w#w-d1t1047-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1047-13">
   <w.rf>
    <LM>w#w-d1t1047-13</LM>
   </w.rf>
   <form>hodná</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-251-304">
   <w.rf>
    <LM>w#w-251-304</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1047-14">
   <w.rf>
    <LM>w#w-d1t1047-14</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1047-15">
   <w.rf>
    <LM>w#w-d1t1047-15</LM>
   </w.rf>
   <form>jsi</form>
   <lemma>být</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="m134-d1t1047-16">
   <w.rf>
    <LM>w#w-d1t1047-16</LM>
   </w.rf>
   <form>blbá</form>
   <lemma>blbý_,h</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-251-436">
   <w.rf>
    <LM>w#w-251-436</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-438">
  <m id="m134-d1t1047-18">
   <w.rf>
    <LM>w#w-d1t1047-18</LM>
   </w.rf>
   <form>Víckrát</form>
   <lemma>víckrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m134-d1t1047-19">
   <w.rf>
    <LM>w#w-d1t1047-19</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ty</lemma>
   <tag>PH-S3--2-------</tag>
  </m>
  <m id="m134-d1t1047-20">
   <w.rf>
    <LM>w#w-d1t1047-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m134-d1t1047-21">
   <w.rf>
    <LM>w#w-d1t1047-21</LM>
   </w.rf>
   <form>říkat</form>
   <lemma>říkat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t1047-22">
   <w.rf>
    <LM>w#w-d1t1047-22</LM>
   </w.rf>
   <form>nebudu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m134-251-307">
   <w.rf>
    <LM>w#w-251-307</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-251-308">
   <w.rf>
    <LM>w#w-251-308</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-250">
  <m id="m134-d1t1051-4">
   <w.rf>
    <LM>w#w-d1t1051-4</LM>
   </w.rf>
   <form>Stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m134-d1t1051-2">
   <w.rf>
    <LM>w#w-d1t1051-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t1051-3">
   <w.rf>
    <LM>w#w-d1t1051-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d-id153424-punct">
   <w.rf>
    <LM>w#w-d-id153424-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1051-6">
   <w.rf>
    <LM>w#w-d1t1051-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1051-18">
   <w.rf>
    <LM>w#w-d1t1051-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1051-19">
   <w.rf>
    <LM>w#w-d1t1051-19</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m134-d1t1051-20">
   <w.rf>
    <LM>w#w-d1t1051-20</LM>
   </w.rf>
   <form>lidem</form>
   <lemma>lidé</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m134-d1t1051-21">
   <w.rf>
    <LM>w#w-d1t1051-21</LM>
   </w.rf>
   <form>půjčovala</form>
   <lemma>půjčovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1051-11">
   <w.rf>
    <LM>w#w-d1t1051-11</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d-id153526-punct">
   <w.rf>
    <LM>w#w-d-id153526-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1051-13">
   <w.rf>
    <LM>w#w-d1t1051-13</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m134-d1t1051-14">
   <w.rf>
    <LM>w#w-d1t1051-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1051-15">
   <w.rf>
    <LM>w#w-d1t1051-15</LM>
   </w.rf>
   <form>získala</form>
   <lemma>získat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-250-444">
   <w.rf>
    <LM>w#w-250-444</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-445">
  <m id="m134-d1t1051-24">
   <w.rf>
    <LM>w#w-d1t1051-24</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1051-25">
   <w.rf>
    <LM>w#w-d1t1051-25</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1051-26">
   <w.rf>
    <LM>w#w-d1t1051-26</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t1051-27">
   <w.rf>
    <LM>w#w-d1t1051-27</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1051-28">
   <w.rf>
    <LM>w#w-d1t1051-28</LM>
   </w.rf>
   <form>půjčovat</form>
   <lemma>půjčovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t1053-1">
   <w.rf>
    <LM>w#w-d1t1053-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t1053-2">
   <w.rf>
    <LM>w#w-d1t1053-2</LM>
   </w.rf>
   <form>budování</form>
   <lemma>budování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m134-d1t1053-3">
   <w.rf>
    <LM>w#w-d1t1053-3</LM>
   </w.rf>
   <form>domečku</form>
   <lemma>domeček</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-250-314">
   <w.rf>
    <LM>w#w-250-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-246">
  <m id="m134-d1t1053-7">
   <w.rf>
    <LM>w#w-d1t1053-7</LM>
   </w.rf>
   <form>Došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m134-d1t1053-8">
   <w.rf>
    <LM>w#w-d1t1053-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1053-9">
   <w.rf>
    <LM>w#w-d1t1053-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1053-10">
   <w.rf>
    <LM>w#w-d1t1053-10</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d-id153926-punct">
   <w.rf>
    <LM>w#w-d-id153926-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1053-12">
   <w.rf>
    <LM>w#w-d1t1053-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1053-27">
   <w.rf>
    <LM>w#w-d1t1053-27</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1053-17">
   <w.rf>
    <LM>w#w-d1t1053-17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1053-18">
   <w.rf>
    <LM>w#w-d1t1053-18</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m134-d1t1053-24">
   <w.rf>
    <LM>w#w-d1t1053-24</LM>
   </w.rf>
   <form>2008</form>
   <lemma>2008</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1t1053-28">
   <w.rf>
    <LM>w#w-d1t1053-28</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1053-29">
   <w.rf>
    <LM>w#w-d1t1053-29</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t1053-30">
   <w.rf>
    <LM>w#w-d1t1053-30</LM>
   </w.rf>
   <form>rozhodla</form>
   <lemma>rozhodnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m134-d-id154230-punct">
   <w.rf>
    <LM>w#w-d-id154230-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1053-32">
   <w.rf>
    <LM>w#w-d1t1053-32</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1053-33">
   <w.rf>
    <LM>w#w-d1t1053-33</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t1053-34">
   <w.rf>
    <LM>w#w-d1t1053-34</LM>
   </w.rf>
   <form>prodám</form>
   <lemma>prodat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m134-246-334">
   <w.rf>
    <LM>w#w-246-334</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-333">
  <m id="m134-d1t1055-2">
   <w.rf>
    <LM>w#w-d1t1055-2</LM>
   </w.rf>
   <form>Bydlím</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1055-3">
   <w.rf>
    <LM>w#w-d1t1055-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1055-4">
   <w.rf>
    <LM>w#w-d1t1055-4</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t1055-5">
   <w.rf>
    <LM>w#w-d1t1055-5</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1055-6">
   <w.rf>
    <LM>w#w-d1t1055-6</LM>
   </w.rf>
   <form>jinde</form>
   <lemma>jinde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-333-452">
   <w.rf>
    <LM>w#w-333-452</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1058-2">
   <w.rf>
    <LM>w#w-d1t1058-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t1058-3">
   <w.rf>
    <LM>w#w-d1t1058-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1058-4">
   <w.rf>
    <LM>w#w-d1t1058-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1058-6">
   <w.rf>
    <LM>w#w-d1t1058-6</LM>
   </w.rf>
   <form>Pyšelích</form>
   <lemma>Pyšely_;G</lemma>
   <tag>NNIP6-----A---1</tag>
  </m>
  <m id="m134-333-372">
   <w.rf>
    <LM>w#w-333-372</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-367">
  <m id="m134-d1t1058-10">
   <w.rf>
    <LM>w#w-d1t1058-10</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m134-d1t1058-11">
   <w.rf>
    <LM>w#w-d1t1058-11</LM>
   </w.rf>
   <form>přítelkyně</form>
   <lemma>přítelkyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t1058-12">
   <w.rf>
    <LM>w#w-d1t1058-12</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t1058-13">
   <w.rf>
    <LM>w#w-d1t1058-13</LM>
   </w.rf>
   <form>volala</form>
   <lemma>volat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d-id154591-punct">
   <w.rf>
    <LM>w#w-d-id154591-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1058-15">
   <w.rf>
    <LM>w#w-d1t1058-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1058-16">
   <w.rf>
    <LM>w#w-d1t1058-16</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m134-d1t1058-17">
   <w.rf>
    <LM>w#w-d1t1058-17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1058-18">
   <w.rf>
    <LM>w#w-d1t1058-18</LM>
   </w.rf>
   <form>říjnu</form>
   <lemma>říjen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d1t1058-19">
   <w.rf>
    <LM>w#w-d1t1058-19</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1t1058-20">
   <w.rf>
    <LM>w#w-d1t1058-20</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t1058-21">
   <w.rf>
    <LM>w#w-d1t1058-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1058-22">
   <w.rf>
    <LM>w#w-d1t1058-22</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1058-23">
   <w.rf>
    <LM>w#w-d1t1058-23</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1058-27">
   <w.rf>
    <LM>w#w-d1t1058-27</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d1t1058-24">
   <w.rf>
    <LM>w#w-d1t1058-24</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-367-383">
   <w.rf>
    <LM>w#w-367-383</LM>
   </w.rf>
   <form>+</form>
   <lemma>+</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1058-26">
   <w.rf>
    <LM>w#w-d1t1058-26</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1t1058-28">
   <w.rf>
    <LM>w#w-d1t1058-28</LM>
   </w.rf>
   <form>nechce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m134-d1t1058-29">
   <w.rf>
    <LM>w#w-d1t1058-29</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t1058-30">
   <w.rf>
    <LM>w#w-d1t1058-30</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m134-367-463">
   <w.rf>
    <LM>w#w-367-463</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-464">
  <m id="m134-d1t1058-32">
   <w.rf>
    <LM>w#w-d1t1058-32</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m134-d1t1058-33">
   <w.rf>
    <LM>w#w-d1t1058-33</LM>
   </w.rf>
   <form>dětem</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m134-d-id154888-punct">
   <w.rf>
    <LM>w#w-d-id154888-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1058-35">
   <w.rf>
    <LM>w#w-d1t1058-35</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m134-d1t1058-36">
   <w.rf>
    <LM>w#w-d1t1058-36</LM>
   </w.rf>
   <form>dceři</form>
   <lemma>dcera</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m134-464-465">
   <w.rf>
    <LM>w#w-464-465</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1058-37">
   <w.rf>
    <LM>w#w-d1t1058-37</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t1058-38">
   <w.rf>
    <LM>w#w-d1t1058-38</LM>
   </w.rf>
   <form>stěhovat</form>
   <lemma>stěhovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t1058-39">
   <w.rf>
    <LM>w#w-d1t1058-39</LM>
   </w.rf>
   <form>nechce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m134-d-id154974-punct">
   <w.rf>
    <LM>w#w-d-id154974-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1058-41">
   <w.rf>
    <LM>w#w-d1t1058-41</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1058-42">
   <w.rf>
    <LM>w#w-d1t1058-42</LM>
   </w.rf>
   <form>bydlím</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1058-43">
   <w.rf>
    <LM>w#w-d1t1058-43</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1058-46">
   <w.rf>
    <LM>w#w-d1t1058-46</LM>
   </w.rf>
   <form>Pyšelích</form>
   <lemma>Pyšely_;G</lemma>
   <tag>NNIP6-----A---1</tag>
  </m>
  <m id="m134-d1t1058-50">
   <w.rf>
    <LM>w#w-d1t1058-50</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m134-d1t1058-51">
   <w.rf>
    <LM>w#w-d1t1058-51</LM>
   </w.rf>
   <form>svojí</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS7----------</tag>
  </m>
  <m id="m134-d1t1058-52">
   <w.rf>
    <LM>w#w-d1t1058-52</LM>
   </w.rf>
   <form>kamarádkou</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m134-d-id155127-punct">
   <w.rf>
    <LM>w#w-d-id155127-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1058-54">
   <w.rf>
    <LM>w#w-d1t1058-54</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m134-d1t1058-55">
   <w.rf>
    <LM>w#w-d1t1058-55</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t1058-57">
   <w.rf>
    <LM>w#w-d1t1058-57</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t1058-58">
   <w.rf>
    <LM>w#w-d1t1058-58</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m134-d1t1058-59">
   <w.rf>
    <LM>w#w-d1t1058-59</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m134-d1t1058-60">
   <w.rf>
    <LM>w#w-d1t1058-60</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1058-61">
   <w.rf>
    <LM>w#w-d1t1058-61</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-367-384">
   <w.rf>
    <LM>w#w-367-384</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-366">
  <m id="m134-d1t1062-7">
   <w.rf>
    <LM>w#w-d1t1062-7</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t1062-6">
   <w.rf>
    <LM>w#w-d1t1062-6</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m134-d1t1062-8">
   <w.rf>
    <LM>w#w-d1t1062-8</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1t1062-9">
   <w.rf>
    <LM>w#w-d1t1062-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1062-10">
   <w.rf>
    <LM>w#w-d1t1062-10</LM>
   </w.rf>
   <form>říjnu</form>
   <lemma>říjen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d-id155433-punct">
   <w.rf>
    <LM>w#w-d-id155433-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-366-169">
   <w.rf>
    <LM>w#w-366-169</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-366-170">
   <w.rf>
    <LM>w#w-366-170</LM>
   </w.rf>
   <form>podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m134-366-171">
   <w.rf>
    <LM>w#w-366-171</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-366-172">
   <w.rf>
    <LM>w#w-366-172</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-366-173">
   <w.rf>
    <LM>w#w-366-173</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-366-174">
   <w.rf>
    <LM>w#w-366-174</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1062-12">
   <w.rf>
    <LM>w#w-d1t1062-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t1062-13">
   <w.rf>
    <LM>w#w-d1t1062-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1062-14">
   <w.rf>
    <LM>w#w-d1t1062-14</LM>
   </w.rf>
   <form>psychicky</form>
   <lemma>psychicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t1062-15">
   <w.rf>
    <LM>w#w-d1t1062-15</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1062-16">
   <w.rf>
    <LM>w#w-d1t1062-16</LM>
   </w.rf>
   <form>vyrovnaná</form>
   <lemma>vyrovnaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-366-392">
   <w.rf>
    <LM>w#w-366-392</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-391">
  <m id="m134-d1t1062-22">
   <w.rf>
    <LM>w#w-d1t1062-22</LM>
   </w.rf>
   <form>Provozuji</form>
   <lemma>provozovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m134-d1t1062-19">
   <w.rf>
    <LM>w#w-d1t1062-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1062-20">
   <w.rf>
    <LM>w#w-d1t1062-20</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m134-d1t1062-23">
   <w.rf>
    <LM>w#w-d1t1062-23</LM>
   </w.rf>
   <form>psychoterapii</form>
   <lemma>psychoterapie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t1062-24">
   <w.rf>
    <LM>w#w-d1t1062-24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1062-25">
   <w.rf>
    <LM>w#w-d1t1062-25</LM>
   </w.rf>
   <form>podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m134-d1t1062-26">
   <w.rf>
    <LM>w#w-d1t1062-26</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t1062-27">
   <w.rf>
    <LM>w#w-d1t1062-27</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d-id155683-punct">
   <w.rf>
    <LM>w#w-d-id155683-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1062-29">
   <w.rf>
    <LM>w#w-d1t1062-29</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1062-30">
   <w.rf>
    <LM>w#w-d1t1062-30</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1062-31">
   <w.rf>
    <LM>w#w-d1t1062-31</LM>
   </w.rf>
   <form>začíná</form>
   <lemma>začínat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t1062-32">
   <w.rf>
    <LM>w#w-d1t1062-32</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t1062-33">
   <w.rf>
    <LM>w#w-d1t1062-33</LM>
   </w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1062-34">
   <w.rf>
    <LM>w#w-d1t1062-34</LM>
   </w.rf>
   <form>chuť</form>
   <lemma>chuť</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t1062-35">
   <w.rf>
    <LM>w#w-d1t1062-35</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t1062-36">
   <w.rf>
    <LM>w#w-d1t1062-36</LM>
   </w.rf>
   <form>života</form>
   <lemma>život</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-391-473">
   <w.rf>
    <LM>w#w-391-473</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-474">
  <m id="m134-d1t1062-38">
   <w.rf>
    <LM>w#w-d1t1062-38</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1062-39">
   <w.rf>
    <LM>w#w-d1t1062-39</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t1062-40">
   <w.rf>
    <LM>w#w-d1t1062-40</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t1062-41">
   <w.rf>
    <LM>w#w-d1t1062-41</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m134-d1t1062-42">
   <w.rf>
    <LM>w#w-d1t1062-42</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m134-d1t1062-43">
   <w.rf>
    <LM>w#w-d1t1062-43</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m134-d1t1062-44">
   <w.rf>
    <LM>w#w-d1t1062-44</LM>
   </w.rf>
   <form>zpráva</form>
   <lemma>zpráva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id155933-punct">
   <w.rf>
    <LM>w#w-d-id155933-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1062-46">
   <w.rf>
    <LM>w#w-d1t1062-46</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m134-d1t1062-47">
   <w.rf>
    <LM>w#w-d1t1062-47</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t1062-48">
   <w.rf>
    <LM>w#w-d1t1062-48</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d-m-d1e992-x8-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e992-x8-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e1063-x2">
  <m id="m134-d1t1066-1">
   <w.rf>
    <LM>w#w-d1t1066-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m134-d1t1066-2">
   <w.rf>
    <LM>w#w-d1t1066-2</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1066-3">
   <w.rf>
    <LM>w#w-d1t1066-3</LM>
   </w.rf>
   <form>děláte</form>
   <lemma>dělat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d-id156088-punct">
   <w.rf>
    <LM>w#w-d-id156088-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e1063-x3">
  <m id="m134-d1t1066-5">
   <w.rf>
    <LM>w#w-d1t1066-5</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d1t1066-6">
   <w.rf>
    <LM>w#w-d1t1066-6</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m134-d1t1066-7">
   <w.rf>
    <LM>w#w-d1t1066-7</LM>
   </w.rf>
   <form>koníčky</form>
   <lemma>koníček-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d-id156144-punct">
   <w.rf>
    <LM>w#w-d-id156144-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e1067-x2">
  <m id="m134-d1t1072-1">
   <w.rf>
    <LM>w#w-d1t1072-1</LM>
   </w.rf>
   <form>Tarotové</form>
   <lemma>tarotový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m134-d1t1072-2">
   <w.rf>
    <LM>w#w-d1t1072-2</LM>
   </w.rf>
   <form>karty</form>
   <lemma>karta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-d1t1072-3">
   <w.rf>
    <LM>w#w-d1t1072-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1072-7">
   <w.rf>
    <LM>w#w-d1t1072-7</LM>
   </w.rf>
   <form>nabídla</form>
   <lemma>nabídnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m134-d1t1072-9">
   <w.rf>
    <LM>w#w-d1t1072-9</LM>
   </w.rf>
   <form>Milušce</form>
   <lemma>Miluška_;Y</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m134-d-id156418-punct">
   <w.rf>
    <LM>w#w-d-id156418-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1072-12">
   <w.rf>
    <LM>w#w-d1t1072-12</LM>
   </w.rf>
   <form>začíná</form>
   <lemma>začínat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t1072-13">
   <w.rf>
    <LM>w#w-d1t1072-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t1072-14">
   <w.rf>
    <LM>w#w-d1t1072-14</LM>
   </w.rf>
   <form>věnovat</form>
   <lemma>věnovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t1072-16">
   <w.rf>
    <LM>w#w-d1t1072-16</LM>
   </w.rf>
   <form>kartám</form>
   <lemma>karta</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m134-d1e1067-x2-485">
   <w.rf>
    <LM>w#w-d1e1067-x2-485</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-486">
  <m id="m134-d1t1072-18">
   <w.rf>
    <LM>w#w-d1t1072-18</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-d1t1072-19">
   <w.rf>
    <LM>w#w-d1t1072-19</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1072-20">
   <w.rf>
    <LM>w#w-d1t1072-20</LM>
   </w.rf>
   <form>runové</form>
   <lemma>runový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m134-d1t1072-21">
   <w.rf>
    <LM>w#w-d1t1072-21</LM>
   </w.rf>
   <form>karty</form>
   <lemma>karta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-d-id156575-punct">
   <w.rf>
    <LM>w#w-d-id156575-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1072-23">
   <w.rf>
    <LM>w#w-d1t1072-23</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m134-d1t1072-24">
   <w.rf>
    <LM>w#w-d1t1072-24</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t1072-25">
   <w.rf>
    <LM>w#w-d1t1072-25</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m134-d1t1072-26">
   <w.rf>
    <LM>w#w-d1t1072-26</LM>
   </w.rf>
   <form>vykládám</form>
   <lemma>vykládat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1e1067-x2-456">
   <w.rf>
    <LM>w#w-d1e1067-x2-456</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-419">
  <m id="m134-d1t1074-1">
   <w.rf>
    <LM>w#w-d1t1074-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t1074-2">
   <w.rf>
    <LM>w#w-d1t1074-2</LM>
   </w.rf>
   <form>dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m134-d-id156693-punct">
   <w.rf>
    <LM>w#w-d-id156693-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1074-4">
   <w.rf>
    <LM>w#w-d1t1074-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1074-5">
   <w.rf>
    <LM>w#w-d1t1074-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1074-6">
   <w.rf>
    <LM>w#w-d1t1074-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1074-7">
   <w.rf>
    <LM>w#w-d1t1074-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1074-10">
   <w.rf>
    <LM>w#w-d1t1074-10</LM>
   </w.rf>
   <form>Křovicích</form>
   <lemma>Křovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m134-d-id156812-punct">
   <w.rf>
    <LM>w#w-d-id156812-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1074-14">
   <w.rf>
    <LM>w#w-d1t1074-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1074-15">
   <w.rf>
    <LM>w#w-d1t1074-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t1074-16">
   <w.rf>
    <LM>w#w-d1t1074-16</LM>
   </w.rf>
   <form>zajímala</form>
   <lemma>zajímat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1074-17">
   <w.rf>
    <LM>w#w-d1t1074-17</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t1074-18">
   <w.rf>
    <LM>w#w-d1t1074-18</LM>
   </w.rf>
   <form>numerologii</form>
   <lemma>numerologie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-419-494">
   <w.rf>
    <LM>w#w-419-494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-497">
  <m id="m134-d1t1076-1">
   <w.rf>
    <LM>w#w-d1t1076-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1076-2">
   <w.rf>
    <LM>w#w-d1t1076-2</LM>
   </w.rf>
   <form>numerologie</form>
   <lemma>numerologie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id156960-punct">
   <w.rf>
    <LM>w#w-d-id156960-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1076-6">
   <w.rf>
    <LM>w#w-d1t1076-6</LM>
   </w.rf>
   <form>vykládám</form>
   <lemma>vykládat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1076-5">
   <w.rf>
    <LM>w#w-d1t1076-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t1076-4">
   <w.rf>
    <LM>w#w-d1t1076-4</LM>
   </w.rf>
   <form>karty</form>
   <lemma>karta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-419-472">
   <w.rf>
    <LM>w#w-419-472</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t1076-16">
   <w.rf>
    <LM>w#w-d1t1076-16</LM>
   </w.rf>
   <form>domnívám</form>
   <lemma>domnívat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1076-15">
   <w.rf>
    <LM>w#w-d1t1076-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d-id157164-punct">
   <w.rf>
    <LM>w#w-d-id157164-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1076-18">
   <w.rf>
    <LM>w#w-d1t1076-18</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t1076-19">
   <w.rf>
    <LM>w#w-d1t1076-19</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1076-20">
   <w.rf>
    <LM>w#w-d1t1076-20</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t1076-22">
   <w.rf>
    <LM>w#w-d1t1076-22</LM>
   </w.rf>
   <form>zkušeností</form>
   <lemma>zkušenost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m134-419-470">
   <w.rf>
    <LM>w#w-419-470</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t1076-14">
   <w.rf>
    <LM>w#w-d1t1076-14</LM>
   </w.rf>
   <form>zdravotnickou</form>
   <lemma>zdravotnický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m134-d1t1076-13">
   <w.rf>
    <LM>w#w-d1t1076-13</LM>
   </w.rf>
   <form>psychoterapii</form>
   <lemma>psychoterapie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-419-471">
   <w.rf>
    <LM>w#w-419-471</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-422">
  <m id="m134-d1t1076-23">
   <w.rf>
    <LM>w#w-d1t1076-23</LM>
   </w.rf>
   <form>Přečetla</form>
   <lemma>přečíst</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t1076-24">
   <w.rf>
    <LM>w#w-d1t1076-24</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1076-25">
   <w.rf>
    <LM>w#w-d1t1076-25</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t1076-26">
   <w.rf>
    <LM>w#w-d1t1076-26</LM>
   </w.rf>
   <form>moudrých</form>
   <lemma>moudrý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m134-d1t1076-27">
   <w.rf>
    <LM>w#w-d1t1076-27</LM>
   </w.rf>
   <form>knížek</form>
   <lemma>knížka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m134-422-473">
   <w.rf>
    <LM>w#w-422-473</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e1067-x3">
  <m id="m134-d1t1078-1">
   <w.rf>
    <LM>w#w-d1t1078-1</LM>
   </w.rf>
   <form>Studovala</form>
   <lemma>studovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1078-2">
   <w.rf>
    <LM>w#w-d1t1078-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t1078-4">
   <w.rf>
    <LM>w#w-d1t1078-4</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t1081-2">
   <w.rf>
    <LM>w#w-d1t1081-2</LM>
   </w.rf>
   <form>Akademii</form>
   <lemma>akademie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t1081-3">
   <w.rf>
    <LM>w#w-d1t1081-3</LM>
   </w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m134-d1t1081-4">
   <w.rf>
    <LM>w#w-d1t1081-4</LM>
   </w.rf>
   <form>slovanské</form>
   <lemma>slovanský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m134-d1t1081-5">
   <w.rf>
    <LM>w#w-d1t1081-5</LM>
   </w.rf>
   <form>spirituality</form>
   <lemma>spiritualita</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-d1t1081-6">
   <w.rf>
    <LM>w#w-d1t1081-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1081-7">
   <w.rf>
    <LM>w#w-d1t1081-7</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1e1067-x3-476">
   <w.rf>
    <LM>w#w-d1e1067-x3-476</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-443">
  <m id="m134-d1t1083-1">
   <w.rf>
    <LM>w#w-d1t1083-1</LM>
   </w.rf>
   <form>No</form>
   <lemma>no</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-443-480">
   <w.rf>
    <LM>w#w-443-480</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1083-2">
   <w.rf>
    <LM>w#w-d1t1083-2</LM>
   </w.rf>
   <form>studovala</form>
   <lemma>studovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-443-481">
   <w.rf>
    <LM>w#w-443-481</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1083-4">
   <w.rf>
    <LM>w#w-d1t1083-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t1083-5">
   <w.rf>
    <LM>w#w-d1t1083-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1083-6">
   <w.rf>
    <LM>w#w-d1t1083-6</LM>
   </w.rf>
   <form>semináře</form>
   <lemma>seminář</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m134-443-508">
   <w.rf>
    <LM>w#w-443-508</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-509">
  <m id="m134-d1t1083-8">
   <w.rf>
    <LM>w#w-d1t1083-8</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t1083-9">
   <w.rf>
    <LM>w#w-d1t1083-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t1083-11">
   <w.rf>
    <LM>w#w-d1t1083-11</LM>
   </w.rf>
   <form>konfrontace</form>
   <lemma>konfrontace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t1083-12">
   <w.rf>
    <LM>w#w-d1t1083-12</LM>
   </w.rf>
   <form>mých</form>
   <lemma>můj</lemma>
   <tag>PSXP2-S1-------</tag>
  </m>
  <m id="m134-d1t1083-13">
   <w.rf>
    <LM>w#w-d1t1083-13</LM>
   </w.rf>
   <form>životních</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m134-d1t1083-14">
   <w.rf>
    <LM>w#w-d1t1083-14</LM>
   </w.rf>
   <form>zkušeností</form>
   <lemma>zkušenost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m134-d1t1083-15">
   <w.rf>
    <LM>w#w-d1t1083-15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t1083-16">
   <w.rf>
    <LM>w#w-d1t1083-16</LM>
   </w.rf>
   <form>lektory</form>
   <lemma>lektor</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m134-d-id157789-punct">
   <w.rf>
    <LM>w#w-d-id157789-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1083-18">
   <w.rf>
    <LM>w#w-d1t1083-18</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m134-d1t1083-19">
   <w.rf>
    <LM>w#w-d1t1083-19</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m134-d1t1083-21">
   <w.rf>
    <LM>w#w-d1t1083-21</LM>
   </w.rf>
   <form>přednášeli</form>
   <lemma>přednášet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t1083-22">
   <w.rf>
    <LM>w#w-d1t1083-22</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t1083-23">
   <w.rf>
    <LM>w#w-d1t1083-23</LM>
   </w.rf>
   <form>numerologii</form>
   <lemma>numerologie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d-id157891-punct">
   <w.rf>
    <LM>w#w-d-id157891-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t1083-25">
   <w.rf>
    <LM>w#w-d1t1083-25</LM>
   </w.rf>
   <form>astrologii</form>
   <lemma>astrologie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-443-483">
   <w.rf>
    <LM>w#w-443-483</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
