<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="es_127.09.w.gz" />
  </references>
 </head>
 <s id="m127-352">
  <m id="m127-352-356">
   <w.rf>
    <LM>w#w-352-356</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t1992-1">
   <w.rf>
    <LM>w#w-d1t1992-1</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t1994-2">
   <w.rf>
    <LM>w#w-d1t1994-2</LM>
   </w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m127-d1t1994-4">
   <w.rf>
    <LM>w#w-d1t1994-4</LM>
   </w.rf>
   <form>takovéhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m127-d1t1994-3">
   <w.rf>
    <LM>w#w-d1t1994-3</LM>
   </w.rf>
   <form>houby</form>
   <lemma>houba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m127-d1t1994-5">
   <w.rf>
    <LM>w#w-d1t1994-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t1994-6">
   <w.rf>
    <LM>w#w-d1t1994-6</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d1t1994-7">
   <w.rf>
    <LM>w#w-d1t1994-7</LM>
   </w.rf>
   <form>žampióny</form>
   <lemma>žampión</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m127-d-id163913-punct">
   <w.rf>
    <LM>w#w-d-id163913-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t1994-9">
   <w.rf>
    <LM>w#w-d1t1994-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t1997-1">
   <w.rf>
    <LM>w#w-d1t1997-1</LM>
   </w.rf>
   <form>udělá</form>
   <lemma>udělat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m127-d1t1997-5">
   <w.rf>
    <LM>w#w-d1t1997-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t1997-7">
   <w.rf>
    <LM>w#w-d1t1997-7</LM>
   </w.rf>
   <form>nožiček</form>
   <lemma>nožička</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m127-d1t1997-9">
   <w.rf>
    <LM>w#w-d1t1997-9</LM>
   </w.rf>
   <form>narychlo</form>
   <lemma>narychlo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t1997-14">
   <w.rf>
    <LM>w#w-d1t1997-14</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m127-d1t1997-13">
   <w.rf>
    <LM>w#w-d1t1997-13</LM>
   </w.rf>
   <form>přílohu</form>
   <lemma>příloha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-352-89">
   <w.rf>
    <LM>w#w-352-89</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-111">
  <m id="m127-d1t1999-1">
   <w.rf>
    <LM>w#w-d1t1999-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t1999-6">
   <w.rf>
    <LM>w#w-d1t1999-6</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m127-d1t1999-4">
   <w.rf>
    <LM>w#w-d1t1999-4</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m127-d1t1999-5">
   <w.rf>
    <LM>w#w-d1t1999-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t1999-7">
   <w.rf>
    <LM>w#w-d1t1999-7</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m127-d-id164283-punct">
   <w.rf>
    <LM>w#w-d-id164283-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t1999-9">
   <w.rf>
    <LM>w#w-d1t1999-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t1999-2">
   <w.rf>
    <LM>w#w-d1t1999-2</LM>
   </w.rf>
   <form>vlastní</form>
   <lemma>vlastní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m127-d1t1999-3">
   <w.rf>
    <LM>w#w-d1t1999-3</LM>
   </w.rf>
   <form>recept</form>
   <lemma>recept</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d1t1999-10">
   <w.rf>
    <LM>w#w-d1t1999-10</LM>
   </w.rf>
   <form>nemáme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m127-d-m-d1e1983-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1983-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2001-x3">
  <m id="m127-d1t2012-1">
   <w.rf>
    <LM>w#w-d1t2012-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m127-d1t2012-2">
   <w.rf>
    <LM>w#w-d1t2012-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2012-3">
   <w.rf>
    <LM>w#w-d1t2012-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2012-4">
   <w.rf>
    <LM>w#w-d1t2012-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m127-d1t2012-5">
   <w.rf>
    <LM>w#w-d1t2012-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d1e2001-x3-182">
   <w.rf>
    <LM>w#w-d1e2001-x3-182</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2013-x2">
  <m id="m127-d1t2016-1">
   <w.rf>
    <LM>w#w-d1t2016-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2016-2">
   <w.rf>
    <LM>w#w-d1t2016-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2016-3">
   <w.rf>
    <LM>w#w-d1t2016-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2016-4">
   <w.rf>
    <LM>w#w-d1t2016-4</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS7-P1-------</tag>
  </m>
  <m id="m127-d1t2016-5">
   <w.rf>
    <LM>w#w-d1t2016-5</LM>
   </w.rf>
   <form>maminečkou</form>
   <lemma>maminečka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m127-d1t2016-7">
   <w.rf>
    <LM>w#w-d1t2016-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2016-8">
   <w.rf>
    <LM>w#w-d1t2016-8</LM>
   </w.rf>
   <form>květnu</form>
   <lemma>květen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m127-d1t2016-9">
   <w.rf>
    <LM>w#w-d1t2016-9</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2016-10">
   <w.rf>
    <LM>w#w-d1t2016-10</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>jejích</form>
   <lemma>jeho</lemma>
   <tag>P9XP6FS3-------</tag>
  </m>
  <m id="m127-d1t2016-11">
   <w.rf>
    <LM>w#w-d1t2016-11</LM>
   </w.rf>
   <form>narozeninách</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m127-d-id164757-punct">
   <w.rf>
    <LM>w#w-d-id164757-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2016-17">
   <w.rf>
    <LM>w#w-d1t2016-17</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2016-18">
   <w.rf>
    <LM>w#w-d1t2016-18</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m127-d1t2016-19">
   <w.rf>
    <LM>w#w-d1t2016-19</LM>
   </w.rf>
   <form>mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2016-20">
   <w.rf>
    <LM>w#w-d1t2016-20</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1t2016-23">
   <w.rf>
    <LM>w#w-d1t2016-23</LM>
   </w.rf>
   <form>93</form>
   <lemma>93</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m127-d1e2013-x2-22">
   <w.rf>
    <LM>w#w-d1e2013-x2-22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-21">
  <m id="m127-d1t2016-26">
   <w.rf>
    <LM>w#w-d1t2016-26</LM>
   </w.rf>
   <form>Vidím</form>
   <lemma>vidět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d-id164976-punct">
   <w.rf>
    <LM>w#w-d-id164976-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2016-28">
   <w.rf>
    <LM>w#w-d1t2016-28</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2016-29">
   <w.rf>
    <LM>w#w-d1t2016-29</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2016-30">
   <w.rf>
    <LM>w#w-d1t2016-30</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2018-1">
   <w.rf>
    <LM>w#w-d1t2018-1</LM>
   </w.rf>
   <form>šeřík</form>
   <lemma>šeřík</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d-id165056-punct">
   <w.rf>
    <LM>w#w-d-id165056-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2018-3">
   <w.rf>
    <LM>w#w-d1t2018-3</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2018-4">
   <w.rf>
    <LM>w#w-d1t2018-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2018-5">
   <w.rf>
    <LM>w#w-d1t2018-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2018-6">
   <w.rf>
    <LM>w#w-d1t2018-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2018-7">
   <w.rf>
    <LM>w#w-d1t2018-7</LM>
   </w.rf>
   <form>květnu</form>
   <lemma>květen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m127-21-122">
   <w.rf>
    <LM>w#w-21-122</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-138">
  <m id="m127-d1t2020-1">
   <w.rf>
    <LM>w#w-d1t2020-1</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d1t2020-2">
   <w.rf>
    <LM>w#w-d1t2020-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m127-d1t2020-3">
   <w.rf>
    <LM>w#w-d1t2020-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2020-4">
   <w.rf>
    <LM>w#w-d1t2020-4</LM>
   </w.rf>
   <form>květnu</form>
   <lemma>květen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m127-d1t2020-5">
   <w.rf>
    <LM>w#w-d1t2020-5</LM>
   </w.rf>
   <form>narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m127-d-id165244-punct">
   <w.rf>
    <LM>w#w-d-id165244-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2020-7">
   <w.rf>
    <LM>w#w-d1t2020-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2020-8">
   <w.rf>
    <LM>w#w-d1t2020-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2020-9">
   <w.rf>
    <LM>w#w-d1t2020-9</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m127-d1t2020-10">
   <w.rf>
    <LM>w#w-d1t2020-10</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2020-11">
   <w.rf>
    <LM>w#w-d1t2020-11</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m127-d1t2022-2">
   <w.rf>
    <LM>w#w-d1t2022-2</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m127-d1t2022-3">
   <w.rf>
    <LM>w#w-d1t2022-3</LM>
   </w.rf>
   <form>dožité</form>
   <lemma>dožitý_^(*3ít)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m127-d1t2022-4">
   <w.rf>
    <LM>w#w-d1t2022-4</LM>
   </w.rf>
   <form>narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m127-21-24">
   <w.rf>
    <LM>w#w-21-24</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2024-10">
   <w.rf>
    <LM>w#w-d1t2024-10</LM>
   </w.rf>
   <form>93</form>
   <lemma>93</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m127-d1t2024-11">
   <w.rf>
    <LM>w#w-d1t2024-11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2024-13">
   <w.rf>
    <LM>w#w-d1t2024-13</LM>
   </w.rf>
   <form>narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2013-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2013-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2025-x2">
  <m id="m127-d1t2028-1">
   <w.rf>
    <LM>w#w-d1t2028-1</LM>
   </w.rf>
   <form>Navštěvoval</form>
   <lemma>navštěvovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2028-2">
   <w.rf>
    <LM>w#w-d1t2028-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m127-d1t2028-3">
   <w.rf>
    <LM>w#w-d1t2028-3</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m127-d1t2028-4">
   <w.rf>
    <LM>w#w-d1t2028-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d-id165735-punct">
   <w.rf>
    <LM>w#w-d-id165735-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2029-x2">
  <m id="m127-d1t2034-1">
   <w.rf>
    <LM>w#w-d1t2034-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d-id165821-punct">
   <w.rf>
    <LM>w#w-d-id165821-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2034-11">
   <w.rf>
    <LM>w#w-d1t2034-11</LM>
   </w.rf>
   <form>nepotřebovali</form>
   <lemma>potřebovat</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m127-d1t2034-9">
   <w.rf>
    <LM>w#w-d1t2034-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2034-10">
   <w.rf>
    <LM>w#w-d1t2034-10</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m127-d1t2034-12">
   <w.rf>
    <LM>w#w-d1t2034-12</LM>
   </w.rf>
   <form>navštěvovat</form>
   <lemma>navštěvovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1e2029-x2-39">
   <w.rf>
    <LM>w#w-d1e2029-x2-39</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2034-6">
   <w.rf>
    <LM>w#w-d1t2034-6</LM>
   </w.rf>
   <form>bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m127-d1t2034-4">
   <w.rf>
    <LM>w#w-d1t2034-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2034-5">
   <w.rf>
    <LM>w#w-d1t2034-5</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m127-d1e2029-x2-38">
   <w.rf>
    <LM>w#w-d1e2029-x2-38</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-37">
  <m id="m127-d1t2036-4">
   <w.rf>
    <LM>w#w-d1t2036-4</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2036-2">
   <w.rf>
    <LM>w#w-d1t2036-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2036-3">
   <w.rf>
    <LM>w#w-d1t2036-3</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m127-d1t2036-5">
   <w.rf>
    <LM>w#w-d1t2036-5</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d-id166104-punct">
   <w.rf>
    <LM>w#w-d-id166104-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2036-11">
   <w.rf>
    <LM>w#w-d1t2036-11</LM>
   </w.rf>
   <form>nikomu</form>
   <lemma>nikdo</lemma>
   <tag>PY--3----------</tag>
  </m>
  <m id="m127-d1t2036-8">
   <w.rf>
    <LM>w#w-d1t2036-8</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m127-d1t2036-10">
   <w.rf>
    <LM>w#w-d1t2036-10</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m127-d1t2036-12">
   <w.rf>
    <LM>w#w-d1t2036-12</LM>
   </w.rf>
   <form>nedali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-NAP--</tag>
  </m>
  <m id="m127-d-m-d1e2029-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2029-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2043-x2">
  <m id="m127-d1t2050-1">
   <w.rf>
    <LM>w#w-d1t2050-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2050-2">
   <w.rf>
    <LM>w#w-d1t2050-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m127-d1t2050-3">
   <w.rf>
    <LM>w#w-d1t2050-3</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m127-d1t2050-4">
   <w.rf>
    <LM>w#w-d1t2050-4</LM>
   </w.rf>
   <form>dobrá</form>
   <lemma>dobrý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m127-d1t2050-5">
   <w.rf>
    <LM>w#w-d1t2050-5</LM>
   </w.rf>
   <form>víla</form>
   <lemma>víla</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2043-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2043-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2058-x2">
  <m id="m127-d1t2061-1">
   <w.rf>
    <LM>w#w-d1t2061-1</LM>
   </w.rf>
   <form>Starali</form>
   <lemma>starat_^(se)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2061-2">
   <w.rf>
    <LM>w#w-d1t2061-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m127-d1t2061-3">
   <w.rf>
    <LM>w#w-d1t2061-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2061-4">
   <w.rf>
    <LM>w#w-d1t2061-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2061-5">
   <w.rf>
    <LM>w#w-d1t2061-5</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m127-d-id166561-punct">
   <w.rf>
    <LM>w#w-d-id166561-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2062-x2">
  <m id="m127-d1t2065-1">
   <w.rf>
    <LM>w#w-d1t2065-1</LM>
   </w.rf>
   <form>Myslíme</form>
   <lemma>myslit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2065-2">
   <w.rf>
    <LM>w#w-d1t2065-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m127-d1e2062-x2-57">
   <w.rf>
    <LM>w#w-d1e2062-x2-57</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2065-3">
   <w.rf>
    <LM>w#w-d1t2065-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2065-4">
   <w.rf>
    <LM>w#w-d1t2065-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2065-5">
   <w.rf>
    <LM>w#w-d1t2065-5</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m127-d1t2065-6">
   <w.rf>
    <LM>w#w-d1t2065-6</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m127-d1t2065-7">
   <w.rf>
    <LM>w#w-d1t2065-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m127-d1t2065-8">
   <w.rf>
    <LM>w#w-d1t2065-8</LM>
   </w.rf>
   <form>potvrzují</form>
   <lemma>potvrzovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d-id166746-punct">
   <w.rf>
    <LM>w#w-d-id166746-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2065-10">
   <w.rf>
    <LM>w#w-d1t2065-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2065-11">
   <w.rf>
    <LM>w#w-d1t2065-11</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2065-12">
   <w.rf>
    <LM>w#w-d1t2065-12</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1e2062-x2-58">
   <w.rf>
    <LM>w#w-d1e2062-x2-58</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-55">
  <m id="m127-d1t2067-2">
   <w.rf>
    <LM>w#w-d1t2067-2</LM>
   </w.rf>
   <form>Ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m127-d1t2067-3">
   <w.rf>
    <LM>w#w-d1t2067-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2067-4">
   <w.rf>
    <LM>w#w-d1t2067-4</LM>
   </w.rf>
   <form>kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2067-5">
   <w.rf>
    <LM>w#w-d1t2067-5</LM>
   </w.rf>
   <form>dávno</form>
   <lemma>dávno-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-55-67">
   <w.rf>
    <LM>w#w-55-67</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2069-2">
   <w.rf>
    <LM>w#w-d1t2069-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2069-3">
   <w.rf>
    <LM>w#w-d1t2069-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m127-d1t2069-5">
   <w.rf>
    <LM>w#w-d1t2069-5</LM>
   </w.rf>
   <form>Věruška</form>
   <lemma>Věruška_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d1t2069-7">
   <w.rf>
    <LM>w#w-d1t2069-7</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m127-55-66">
   <w.rf>
    <LM>w#w-55-66</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2067-6">
   <w.rf>
    <LM>w#w-d1t2067-6</LM>
   </w.rf>
   <form>starala</form>
   <lemma>starat_^(se)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m127-d1t2067-7">
   <w.rf>
    <LM>w#w-d1t2067-7</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2067-8">
   <w.rf>
    <LM>w#w-d1t2067-8</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m127-d-id166935-punct">
   <w.rf>
    <LM>w#w-d-id166935-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2069-15">
   <w.rf>
    <LM>w#w-d1t2069-15</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2069-16">
   <w.rf>
    <LM>w#w-d1t2069-16</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m127-d1t2069-17">
   <w.rf>
    <LM>w#w-d1t2069-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2069-18">
   <w.rf>
    <LM>w#w-d1t2069-18</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2069-19">
   <w.rf>
    <LM>w#w-d1t2069-19</LM>
   </w.rf>
   <form>povinni</form>
   <lemma>povinný</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m127-d1t2069-21">
   <w.rf>
    <LM>w#w-d1t2069-21</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2071-7">
   <w.rf>
    <LM>w#w-d1t2071-7</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m127-d1t2071-1">
   <w.rf>
    <LM>w#w-d1t2071-1</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m127-d1t2071-3">
   <w.rf>
    <LM>w#w-d1t2071-3</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9IS4FS3-------</tag>
  </m>
  <m id="m127-d1t2071-2">
   <w.rf>
    <LM>w#w-d1t2071-2</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d1t2071-4">
   <w.rf>
    <LM>w#w-d1t2071-4</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2071-5">
   <w.rf>
    <LM>w#w-d1t2071-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2071-6">
   <w.rf>
    <LM>w#w-d1t2071-6</LM>
   </w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m127-d1t2071-8">
   <w.rf>
    <LM>w#w-d1t2071-8</LM>
   </w.rf>
   <form>udělat</form>
   <lemma>udělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m127-d1t2071-9">
   <w.rf>
    <LM>w#w-d1t2071-9</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-5_^(př._co_nejméně,_co_nevidět_atd.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2071-10">
   <w.rf>
    <LM>w#w-d1t2071-10</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m127-55-153">
   <w.rf>
    <LM>w#w-55-153</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-160">
  <m id="m127-d1t2071-12">
   <w.rf>
    <LM>w#w-d1t2071-12</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2071-13">
   <w.rf>
    <LM>w#w-d1t2071-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m127-d-id167508-punct">
   <w.rf>
    <LM>w#w-d-id167508-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2071-15">
   <w.rf>
    <LM>w#w-d1t2071-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2071-16">
   <w.rf>
    <LM>w#w-d1t2071-16</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m127-d1t2071-17">
   <w.rf>
    <LM>w#w-d1t2071-17</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m127-d1t2071-18">
   <w.rf>
    <LM>w#w-d1t2071-18</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2071-19">
   <w.rf>
    <LM>w#w-d1t2071-19</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m127-d1t2071-20">
   <w.rf>
    <LM>w#w-d1t2071-20</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2071-21">
   <w.rf>
    <LM>w#w-d1t2071-21</LM>
   </w.rf>
   <form>dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m127-55-69">
   <w.rf>
    <LM>w#w-55-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-56">
  <m id="m127-d1t2073-6">
   <w.rf>
    <LM>w#w-d1t2073-6</LM>
   </w.rf>
   <form>Vozili</form>
   <lemma>vozit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2073-4">
   <w.rf>
    <LM>w#w-d1t2073-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2073-5">
   <w.rf>
    <LM>w#w-d1t2073-5</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m127-d1t2073-2">
   <w.rf>
    <LM>w#w-d1t2073-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2073-3">
   <w.rf>
    <LM>w#w-d1t2073-3</LM>
   </w.rf>
   <form>výlety</form>
   <lemma>výlet</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m127-d-id167811-punct">
   <w.rf>
    <LM>w#w-d-id167811-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2073-13">
   <w.rf>
    <LM>w#w-d1t2073-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2073-14">
   <w.rf>
    <LM>w#w-d1t2073-14</LM>
   </w.rf>
   <form>restaurace</form>
   <lemma>restaurace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-d-id167850-punct">
   <w.rf>
    <LM>w#w-d-id167850-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2073-16">
   <w.rf>
    <LM>w#w-d1t2073-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2073-17">
   <w.rf>
    <LM>w#w-d1t2073-17</LM>
   </w.rf>
   <form>večeři</form>
   <lemma>večeře</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-d-id167890-punct">
   <w.rf>
    <LM>w#w-d-id167890-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2073-19">
   <w.rf>
    <LM>w#w-d1t2073-19</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2073-20">
   <w.rf>
    <LM>w#w-d1t2073-20</LM>
   </w.rf>
   <form>číny</form>
   <lemma>čína</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-56-172">
   <w.rf>
    <LM>w#w-56-172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-182">
  <m id="m127-d1t2073-11">
   <w.rf>
    <LM>w#w-d1t2073-11</LM>
   </w.rf>
   <form>Třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2073-10">
   <w.rf>
    <LM>w#w-d1t2073-10</LM>
   </w.rf>
   <form>nechtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m127-d1t2073-21">
   <w.rf>
    <LM>w#w-d1t2073-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2073-26">
   <w.rf>
    <LM>w#w-d1t2073-26</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2073-27">
   <w.rf>
    <LM>w#w-d1t2073-27</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m127-d1e2062-x3-76">
   <w.rf>
    <LM>w#w-d1e2062-x3-76</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1e2062-x3-77">
   <w.rf>
    <LM>w#w-d1e2062-x3-77</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2073-22">
   <w.rf>
    <LM>w#w-d1t2073-22</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m127-d1t2073-23">
   <w.rf>
    <LM>w#w-d1t2073-23</LM>
   </w.rf>
   <form>nikam</form>
   <lemma>nikam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2073-24">
   <w.rf>
    <LM>w#w-d1t2073-24</LM>
   </w.rf>
   <form>nepůjdu</form>
   <lemma>jít</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m127-182-193">
   <w.rf>
    <LM>w#w-182-193</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1e2062-x3-78">
   <w.rf>
    <LM>w#w-d1e2062-x3-78</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-194">
  <m id="m127-d1t2073-29">
   <w.rf>
    <LM>w#w-d1t2073-29</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m127-d1t2073-30">
   <w.rf>
    <LM>w#w-d1t2073-30</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2073-31">
   <w.rf>
    <LM>w#w-d1t2073-31</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1e2062-x3-80">
   <w.rf>
    <LM>w#w-d1e2062-x3-80</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-56-90">
   <w.rf>
    <LM>w#w-56-90</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2073-33">
   <w.rf>
    <LM>w#w-d1t2073-33</LM>
   </w.rf>
   <form>Jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2073-34">
   <w.rf>
    <LM>w#w-d1t2073-34</LM>
   </w.rf>
   <form>pojď</form>
   <lemma>jít</lemma>
   <tag>Vi-S---2--A-I-1</tag>
  </m>
  <m id="m127-56-91">
   <w.rf>
    <LM>w#w-56-91</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2073-35">
   <w.rf>
    <LM>w#w-d1t2073-35</LM>
   </w.rf>
   <form>prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2073-36">
   <w.rf>
    <LM>w#w-d1t2073-36</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="m127-56-92">
   <w.rf>
    <LM>w#w-56-92</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1e2062-x3-81">
   <w.rf>
    <LM>w#w-d1e2062-x3-81</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-88">
  <m id="m127-d1t2076-5">
   <w.rf>
    <LM>w#w-d1t2076-5</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2076-6">
   <w.rf>
    <LM>w#w-d1t2076-6</LM>
   </w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d1t2076-3">
   <w.rf>
    <LM>w#w-d1t2076-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2076-4">
   <w.rf>
    <LM>w#w-d1t2076-4</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2076-7">
   <w.rf>
    <LM>w#w-d1t2076-7</LM>
   </w.rf>
   <form>pili</form>
   <lemma>pít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2076-2">
   <w.rf>
    <LM>w#w-d1t2076-2</LM>
   </w.rf>
   <form>kafe</form>
   <lemma>kafe_,h</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m127-d1t2076-8">
   <w.rf>
    <LM>w#w-d1t2076-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2076-9">
   <w.rf>
    <LM>w#w-d1t2076-9</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m127-88-94">
   <w.rf>
    <LM>w#w-88-94</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-93">
  <m id="m127-93-95">
   <w.rf>
    <LM>w#w-93-95</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2076-11">
   <w.rf>
    <LM>w#w-d1t2076-11</LM>
   </w.rf>
   <form>maminkou</form>
   <lemma>maminka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m127-d1t2076-12">
   <w.rf>
    <LM>w#w-d1t2076-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2076-13">
   <w.rf>
    <LM>w#w-d1t2076-13</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2076-14">
   <w.rf>
    <LM>w#w-d1t2076-14</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m127-d-m-d1e2062-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2062-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2077-x2">
  <m id="m127-d1t2080-1">
   <w.rf>
    <LM>w#w-d1t2080-1</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m127-d1t2080-2">
   <w.rf>
    <LM>w#w-d1t2080-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m127-d1t2080-3">
   <w.rf>
    <LM>w#w-d1t2080-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2080-4">
   <w.rf>
    <LM>w#w-d1t2080-4</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m127-d1t2080-5">
   <w.rf>
    <LM>w#w-d1t2080-5</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2080-6">
   <w.rf>
    <LM>w#w-d1t2080-6</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2080-7">
   <w.rf>
    <LM>w#w-d1t2080-7</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2080-8">
   <w.rf>
    <LM>w#w-d1t2080-8</LM>
   </w.rf>
   <form>hodní</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m127-d-m-d1e2077-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2077-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2081-x2">
  <m id="m127-d1t2084-1">
   <w.rf>
    <LM>w#w-d1t2084-1</LM>
   </w.rf>
   <form>Tvrdí</form>
   <lemma>tvrdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2084-2">
   <w.rf>
    <LM>w#w-d1t2084-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m127-d1t2084-3">
   <w.rf>
    <LM>w#w-d1t2084-3</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m127-d1t2084-4">
   <w.rf>
    <LM>w#w-d1t2084-4</LM>
   </w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2084-5">
   <w.rf>
    <LM>w#w-d1t2084-5</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m127-d1e2081-x2-107">
   <w.rf>
    <LM>w#w-d1e2081-x2-107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-106">
  <m id="m127-d1t2086-1">
   <w.rf>
    <LM>w#w-d1t2086-1</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2086-2">
   <w.rf>
    <LM>w#w-d1t2086-2</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2086-6">
   <w.rf>
    <LM>w#w-d1t2086-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2086-7">
   <w.rf>
    <LM>w#w-d1t2086-7</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m127-d1t2086-3">
   <w.rf>
    <LM>w#w-d1t2086-3</LM>
   </w.rf>
   <form>náhradní</form>
   <lemma>náhradní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m127-d1t2086-4">
   <w.rf>
    <LM>w#w-d1t2086-4</LM>
   </w.rf>
   <form>babičku</form>
   <lemma>babička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-106-109">
   <w.rf>
    <LM>w#w-106-109</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2086-5">
   <w.rf>
    <LM>w#w-d1t2086-5</LM>
   </w.rf>
   <form>sousedku</form>
   <lemma>sousedka_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-d-id168853-punct">
   <w.rf>
    <LM>w#w-d-id168853-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2086-9">
   <w.rf>
    <LM>w#w-d1t2086-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2086-10">
   <w.rf>
    <LM>w#w-d1t2086-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2086-11">
   <w.rf>
    <LM>w#w-d1t2086-11</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m127-d1t2086-12">
   <w.rf>
    <LM>w#w-d1t2086-12</LM>
   </w.rf>
   <form>snažíme</form>
   <lemma>snažit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2086-13">
   <w.rf>
    <LM>w#w-d1t2086-13</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2086-14">
   <w.rf>
    <LM>w#w-d1t2086-14</LM>
   </w.rf>
   <form>pomáhat</form>
   <lemma>pomáhat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d-m-d1e2081-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2081-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2087-x2">
  <m id="m127-d1t2090-1">
   <w.rf>
    <LM>w#w-d1t2090-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m127-d1t2090-2">
   <w.rf>
    <LM>w#w-d1t2090-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2090-3">
   <w.rf>
    <LM>w#w-d1t2090-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2090-4">
   <w.rf>
    <LM>w#w-d1t2090-4</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m127-d1t2090-5">
   <w.rf>
    <LM>w#w-d1t2090-5</LM>
   </w.rf>
   <form>snímku</form>
   <lemma>snímek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m127-d-id169100-punct">
   <w.rf>
    <LM>w#w-d-id169100-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2091-x2">
  <m id="m127-d1e2091-x2-170">
   <w.rf>
    <LM>w#w-d1e2091-x2-170</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-169">
   <w.rf>
    <LM>w#w-d1e2091-x2-169</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d1e2091-x2-168">
   <w.rf>
    <LM>w#w-d1e2091-x2-168</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-167">
   <w.rf>
    <LM>w#w-d1e2091-x2-167</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-166">
   <w.rf>
    <LM>w#w-d1e2091-x2-166</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-165">
   <w.rf>
    <LM>w#w-d1e2091-x2-165</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-164">
   <w.rf>
    <LM>w#w-d1e2091-x2-164</LM>
   </w.rf>
   <form>naši</form>
   <lemma>náš</lemma>
   <tag>PSMP1-P1-------</tag>
  </m>
  <m id="m127-d1e2091-x2-163">
   <w.rf>
    <LM>w#w-d1e2091-x2-163</LM>
   </w.rf>
   <form>přátelé</form>
   <lemma>přítel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m127-d1e2091-x2-162">
   <w.rf>
    <LM>w#w-d1e2091-x2-162</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1e2091-x2-161">
   <w.rf>
    <LM>w#w-d1e2091-x2-161</LM>
   </w.rf>
   <form>Hradce</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m127-d1e2091-x2-160">
   <w.rf>
    <LM>w#w-d1e2091-x2-160</LM>
   </w.rf>
   <form>Králové</form>
   <lemma>Králové_;G_^(Dvůr_Králové)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-d1e2091-x2-204">
   <w.rf>
    <LM>w#w-d1e2091-x2-204</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-206">
  <m id="m127-d1e2091-x2-157">
   <w.rf>
    <LM>w#w-d1e2091-x2-157</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m127-d1e2091-x2-156">
   <w.rf>
    <LM>w#w-d1e2091-x2-156</LM>
   </w.rf>
   <form>pán</form>
   <lemma>pán</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m127-d1e2091-x2-155">
   <w.rf>
    <LM>w#w-d1e2091-x2-155</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-154">
   <w.rf>
    <LM>w#w-d1e2091-x2-154</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m127-d1e2091-x2-153">
   <w.rf>
    <LM>w#w-d1e2091-x2-153</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1e2091-x2-152">
   <w.rf>
    <LM>w#w-d1e2091-x2-152</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1e2091-x2-151">
   <w.rf>
    <LM>w#w-d1e2091-x2-151</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m127-d1e2091-x2-150">
   <w.rf>
    <LM>w#w-d1e2091-x2-150</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-149">
   <w.rf>
    <LM>w#w-d1e2091-x2-149</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d1e2091-x2-148">
   <w.rf>
    <LM>w#w-d1e2091-x2-148</LM>
   </w.rf>
   <form>kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-147">
   <w.rf>
    <LM>w#w-d1e2091-x2-147</LM>
   </w.rf>
   <form>dávno</form>
   <lemma>dávno-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1e2091-x2-146">
   <w.rf>
    <LM>w#w-d1e2091-x2-146</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m127-d1e2091-x2-145">
   <w.rf>
    <LM>w#w-d1e2091-x2-145</LM>
   </w.rf>
   <form>sestřenice</form>
   <lemma>sestřenice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-d1e2091-x2-144">
   <w.rf>
    <LM>w#w-d1e2091-x2-144</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1------1</tag>
  </m>
  <m id="m127-d1e2091-x2-143">
   <w.rf>
    <LM>w#w-d1e2091-x2-143</LM>
   </w.rf>
   <form>manželky</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-206-207">
   <w.rf>
    <LM>w#w-206-207</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-208">
  <m id="m127-d1e2091-x2-138">
   <w.rf>
    <LM>w#w-d1e2091-x2-138</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-139">
   <w.rf>
    <LM>w#w-d1e2091-x2-139</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d1e2091-x2-137">
   <w.rf>
    <LM>w#w-d1e2091-x2-137</LM>
   </w.rf>
   <form>rozvedení</form>
   <lemma>rozvedený_^(*5ést)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m127-d1e2091-x2-136">
   <w.rf>
    <LM>w#w-d1e2091-x2-136</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-135">
   <w.rf>
    <LM>w#w-d1e2091-x2-135</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-134">
   <w.rf>
    <LM>w#w-d1e2091-x2-134</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1e2091-x2-133">
   <w.rf>
    <LM>w#w-d1e2091-x2-133</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1e2091-x2-132">
   <w.rf>
    <LM>w#w-d1e2091-x2-132</LM>
   </w.rf>
   <form>stýkáme</form>
   <lemma>stýkat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-208-209">
   <w.rf>
    <LM>w#w-208-209</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-210">
  <m id="m127-d1e2091-x2-130">
   <w.rf>
    <LM>w#w-d1e2091-x2-130</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1e2091-x2-129">
   <w.rf>
    <LM>w#w-d1e2091-x2-129</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1e2091-x2-128">
   <w.rf>
    <LM>w#w-d1e2091-x2-128</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m127-d1e2091-x2-127">
   <w.rf>
    <LM>w#w-d1e2091-x2-127</LM>
   </w.rf>
   <form>nová</form>
   <lemma>nový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m127-d1e2091-x2-126">
   <w.rf>
    <LM>w#w-d1e2091-x2-126</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d1e2091-x2-125">
   <w.rf>
    <LM>w#w-d1e2091-x2-125</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-121">
  <m id="m127-d1t2102-13">
   <w.rf>
    <LM>w#w-d1t2102-13</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2102-14">
   <w.rf>
    <LM>w#w-d1t2102-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2102-16">
   <w.rf>
    <LM>w#w-d1t2102-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-121-192">
   <w.rf>
    <LM>w#w-121-192</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-176">
  <m id="m127-d1t2105-2">
   <w.rf>
    <LM>w#w-d1t2105-2</LM>
   </w.rf>
   <form>Jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2105-3">
   <w.rf>
    <LM>w#w-d1t2105-3</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2105-4">
   <w.rf>
    <LM>w#w-d1t2105-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2105-5">
   <w.rf>
    <LM>w#w-d1t2105-5</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m127-d-id170298-punct">
   <w.rf>
    <LM>w#w-d-id170298-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2105-7">
   <w.rf>
    <LM>w#w-d1t2105-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2105-8">
   <w.rf>
    <LM>w#w-d1t2105-8</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2105-9">
   <w.rf>
    <LM>w#w-d1t2105-9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m127-d1t2105-10">
   <w.rf>
    <LM>w#w-d1t2105-10</LM>
   </w.rf>
   <form>neuvědomuju</form>
   <lemma>uvědomovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m127-d-id170369-punct">
   <w.rf>
    <LM>w#w-d-id170369-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2105-12">
   <w.rf>
    <LM>w#w-d1t2105-12</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2105-13">
   <w.rf>
    <LM>w#w-d1t2105-13</LM>
   </w.rf>
   <form>tenhle</form>
   <lemma>tenhle</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m127-d1t2105-15">
   <w.rf>
    <LM>w#w-d1t2105-15</LM>
   </w.rf>
   <form>bazilíšek</form>
   <lemma>bazilíšek_,h_^(^GC**bazilišek)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m127-d1t2105-17">
   <w.rf>
    <LM>w#w-d1t2105-17</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2105-19">
   <w.rf>
    <LM>w#w-d1t2105-19</LM>
   </w.rf>
   <form>opicí</form>
   <lemma>opice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m127-d1t2105-16">
   <w.rf>
    <LM>w#w-d1t2105-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-176-220">
   <w.rf>
    <LM>w#w-176-220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-228">
  <m id="m127-d1t2105-24">
   <w.rf>
    <LM>w#w-d1t2105-24</LM>
   </w.rf>
   <form>Musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2105-22">
   <w.rf>
    <LM>w#w-d1t2105-22</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m127-d1t2105-23">
   <w.rf>
    <LM>w#w-d1t2105-23</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2105-25">
   <w.rf>
    <LM>w#w-d1t2105-25</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m127-d1t2105-28">
   <w.rf>
    <LM>w#w-d1t2105-28</LM>
   </w.rf>
   <form>dozadu</form>
   <lemma>dozadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2105-26">
   <w.rf>
    <LM>w#w-d1t2105-26</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2105-27">
   <w.rf>
    <LM>w#w-d1t2105-27</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-228-229">
   <w.rf>
    <LM>w#w-228-229</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-231">
  <m id="m127-d1t2105-32">
   <w.rf>
    <LM>w#w-d1t2105-32</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2105-34">
   <w.rf>
    <LM>w#w-d1t2105-34</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m127-d1t2105-35">
   <w.rf>
    <LM>w#w-d1t2105-35</LM>
   </w.rf>
   <form>výletů</form>
   <lemma>výlet</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m127-d1t2105-33">
   <w.rf>
    <LM>w#w-d1t2105-33</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-1</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m127-176-191">
   <w.rf>
    <LM>w#w-176-191</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-190">
  <m id="m127-d1t2107-7">
   <w.rf>
    <LM>w#w-d1t2107-7</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2107-6">
   <w.rf>
    <LM>w#w-d1t2107-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2107-8">
   <w.rf>
    <LM>w#w-d1t2107-8</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2107-1">
   <w.rf>
    <LM>w#w-d1t2107-1</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2107-2">
   <w.rf>
    <LM>w#w-d1t2107-2</LM>
   </w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2107-4">
   <w.rf>
    <LM>w#w-d1t2107-4</LM>
   </w.rf>
   <form>Hradce</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m127-190-239">
   <w.rf>
    <LM>w#w-190-239</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-240">
  <m id="m127-d1t2107-10">
   <w.rf>
    <LM>w#w-d1t2107-10</LM>
   </w.rf>
   <form>Možná</form>
   <lemma>možná-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-190-197">
   <w.rf>
    <LM>w#w-190-197</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2107-11">
   <w.rf>
    <LM>w#w-d1t2107-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2107-12">
   <w.rf>
    <LM>w#w-d1t2107-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2107-13">
   <w.rf>
    <LM>w#w-d1t2107-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-190-199">
   <w.rf>
    <LM>w#w-190-199</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2109-4">
   <w.rf>
    <LM>w#w-d1t2109-4</LM>
   </w.rf>
   <form>Jaroměři</form>
   <lemma>Jaroměř_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d1t2109-6">
   <w.rf>
    <LM>w#w-d1t2109-6</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2109-8">
   <w.rf>
    <LM>w#w-d1t2109-8</LM>
   </w.rf>
   <form>pevnosti</form>
   <lemma>pevnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-190-198">
   <w.rf>
    <LM>w#w-190-198</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2111-3">
   <w.rf>
    <LM>w#w-d1t2111-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2111-4">
   <w.rf>
    <LM>w#w-d1t2111-4</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m127-190-200">
   <w.rf>
    <LM>w#w-190-200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-199">
  <m id="m127-d1t2111-9">
   <w.rf>
    <LM>w#w-d1t2111-9</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2111-10">
   <w.rf>
    <LM>w#w-d1t2111-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2111-7">
   <w.rf>
    <LM>w#w-d1t2111-7</LM>
   </w.rf>
   <form>naši</form>
   <lemma>náš</lemma>
   <tag>PSMP1-P1-------</tag>
  </m>
  <m id="m127-d1t2111-8">
   <w.rf>
    <LM>w#w-d1t2111-8</LM>
   </w.rf>
   <form>přátelé</form>
   <lemma>přítel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m127-d1t2113-1">
   <w.rf>
    <LM>w#w-d1t2113-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2113-2">
   <w.rf>
    <LM>w#w-d1t2113-2</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m127-d1t2113-3">
   <w.rf>
    <LM>w#w-d1t2113-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2113-4">
   <w.rf>
    <LM>w#w-d1t2113-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2113-5">
   <w.rf>
    <LM>w#w-d1t2113-5</LM>
   </w.rf>
   <form>starý</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m127-d1t2113-6">
   <w.rf>
    <LM>w#w-d1t2113-6</LM>
   </w.rf>
   <form>snímek</form>
   <lemma>snímek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2091-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2091-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2114-x2">
  <m id="m127-d1t2117-1">
   <w.rf>
    <LM>w#w-d1t2117-1</LM>
   </w.rf>
   <form>Chodíte</form>
   <lemma>chodit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m127-d1t2117-2">
   <w.rf>
    <LM>w#w-d1t2117-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2117-3">
   <w.rf>
    <LM>w#w-d1t2117-3</LM>
   </w.rf>
   <form>těmito</form>
   <lemma>tento</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m127-d1t2117-4">
   <w.rf>
    <LM>w#w-d1t2117-4</LM>
   </w.rf>
   <form>přáteli</form>
   <lemma>přítel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m127-d1t2117-5">
   <w.rf>
    <LM>w#w-d1t2117-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2117-6">
   <w.rf>
    <LM>w#w-d1t2117-6</LM>
   </w.rf>
   <form>výlety</form>
   <lemma>výlet</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m127-d1t2117-7">
   <w.rf>
    <LM>w#w-d1t2117-7</LM>
   </w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d-id171543-punct">
   <w.rf>
    <LM>w#w-d-id171543-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2118-x2">
  <m id="m127-d1t2121-1">
   <w.rf>
    <LM>w#w-d1t2121-1</LM>
   </w.rf>
   <form>Dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1t2121-2">
   <w.rf>
    <LM>w#w-d1t2121-2</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d-id171636-punct">
   <w.rf>
    <LM>w#w-d-id171636-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2121-4">
   <w.rf>
    <LM>w#w-d1t2121-4</LM>
   </w.rf>
   <form>nechci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m127-d1t2121-5">
   <w.rf>
    <LM>w#w-d1t2121-5</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m127-d1t2121-6">
   <w.rf>
    <LM>w#w-d1t2121-6</LM>
   </w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d-id171691-punct">
   <w.rf>
    <LM>w#w-d-id171691-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2121-8">
   <w.rf>
    <LM>w#w-d1t2121-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2121-9">
   <w.rf>
    <LM>w#w-d1t2121-9</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1t2121-10">
   <w.rf>
    <LM>w#w-d1t2121-10</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1e2118-x2-241">
   <w.rf>
    <LM>w#w-d1e2118-x2-241</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-217">
  <m id="m127-d1t2123-1">
   <w.rf>
    <LM>w#w-d1t2123-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2123-2">
   <w.rf>
    <LM>w#w-d1t2123-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2123-3">
   <w.rf>
    <LM>w#w-d1t2123-3</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2123-4">
   <w.rf>
    <LM>w#w-d1t2123-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2123-6">
   <w.rf>
    <LM>w#w-d1t2123-6</LM>
   </w.rf>
   <form>Paříži</form>
   <lemma>Paříž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d-id171906-punct">
   <w.rf>
    <LM>w#w-d-id171906-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2123-9">
   <w.rf>
    <LM>w#w-d1t2123-9</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2123-12">
   <w.rf>
    <LM>w#w-d1t2123-12</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2123-10">
   <w.rf>
    <LM>w#w-d1t2123-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m127-d1t2123-11">
   <w.rf>
    <LM>w#w-d1t2123-11</LM>
   </w.rf>
   <form>našim</form>
   <lemma>náš</lemma>
   <tag>PSXP3-P1-------</tag>
  </m>
  <m id="m127-d1t2123-13">
   <w.rf>
    <LM>w#w-d1t2123-13</LM>
   </w.rf>
   <form>dalším</form>
   <lemma>další</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m127-d1t2123-14">
   <w.rf>
    <LM>w#w-d1t2123-14</LM>
   </w.rf>
   <form>známým</form>
   <lemma>známý-1_^(potkat_známého_[člověka])</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m127-d1t2123-15">
   <w.rf>
    <LM>w#w-d1t2123-15</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2123-17">
   <w.rf>
    <LM>w#w-d1t2123-17</LM>
   </w.rf>
   <form>Berlína</form>
   <lemma>Berlín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m127-217-249">
   <w.rf>
    <LM>w#w-217-249</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-218">
  <m id="m127-d1t2125-3">
   <w.rf>
    <LM>w#w-d1t2125-3</LM>
   </w.rf>
   <form>Oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m127-d1t2125-4">
   <w.rf>
    <LM>w#w-d1t2125-4</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2125-5">
   <w.rf>
    <LM>w#w-d1t2125-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m127-d1t2125-6">
   <w.rf>
    <LM>w#w-d1t2125-6</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m127-d-id172174-punct">
   <w.rf>
    <LM>w#w-d-id172174-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-218-255">
   <w.rf>
    <LM>w#w-218-255</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m127-d1t2125-8">
   <w.rf>
    <LM>w#w-d1t2125-8</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2125-9">
   <w.rf>
    <LM>w#w-d1t2125-9</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m127-d1t2125-10">
   <w.rf>
    <LM>w#w-d1t2125-10</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m127-218-265">
   <w.rf>
    <LM>w#w-218-265</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-266">
  <m id="m127-d1t2127-2">
   <w.rf>
    <LM>w#w-d1t2127-2</LM>
   </w.rf>
   <form>Dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m127-d1t2127-3">
   <w.rf>
    <LM>w#w-d1t2127-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2127-4">
   <w.rf>
    <LM>w#w-d1t2127-4</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m127-d-id172300-punct">
   <w.rf>
    <LM>w#w-d-id172300-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2127-6">
   <w.rf>
    <LM>w#w-d1t2127-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2127-7">
   <w.rf>
    <LM>w#w-d1t2127-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2127-8">
   <w.rf>
    <LM>w#w-d1t2127-8</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2127-13">
   <w.rf>
    <LM>w#w-d1t2127-13</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2127-9">
   <w.rf>
    <LM>w#w-d1t2127-9</LM>
   </w.rf>
   <form>pětkrát</form>
   <lemma>pětkrát`5</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m127-218-256">
   <w.rf>
    <LM>w#w-218-256</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2127-10">
   <w.rf>
    <LM>w#w-d1t2127-10</LM>
   </w.rf>
   <form>šestkrát</form>
   <lemma>šestkrát`6_^(*4)</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m127-d1t2127-11">
   <w.rf>
    <LM>w#w-d1t2127-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2127-12">
   <w.rf>
    <LM>w#w-d1t2127-12</LM>
   </w.rf>
   <form>roka</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m127-218-257">
   <w.rf>
    <LM>w#w-218-257</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-219">
  <m id="m127-d1t2129-4">
   <w.rf>
    <LM>w#w-d1t2129-4</LM>
   </w.rf>
   <form>Jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2129-2">
   <w.rf>
    <LM>w#w-d1t2129-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2129-3">
   <w.rf>
    <LM>w#w-d1t2129-3</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m127-d1t2129-1">
   <w.rf>
    <LM>w#w-d1t2129-1</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2129-7">
   <w.rf>
    <LM>w#w-d1t2129-7</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d-id172557-punct">
   <w.rf>
    <LM>w#w-d-id172557-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2129-9">
   <w.rf>
    <LM>w#w-d1t2129-9</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m127-d1t2129-10">
   <w.rf>
    <LM>w#w-d1t2129-10</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2129-11">
   <w.rf>
    <LM>w#w-d1t2129-11</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2129-12">
   <w.rf>
    <LM>w#w-d1t2129-12</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m127-d1t2129-13">
   <w.rf>
    <LM>w#w-d1t2129-13</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m127-d1t2129-14">
   <w.rf>
    <LM>w#w-d1t2129-14</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m127-d1t2129-15">
   <w.rf>
    <LM>w#w-d1t2129-15</LM>
   </w.rf>
   <form>dni</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP4-----A---1</tag>
  </m>
  <m id="m127-d-id172675-punct">
   <w.rf>
    <LM>w#w-d-id172675-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2129-17">
   <w.rf>
    <LM>w#w-d1t2129-17</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2129-18">
   <w.rf>
    <LM>w#w-d1t2129-18</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m127-219-263">
   <w.rf>
    <LM>w#w-219-263</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2129-19">
   <w.rf>
    <LM>w#w-d1t2129-19</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2129-20">
   <w.rf>
    <LM>w#w-d1t2129-20</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m127-d1t2129-21">
   <w.rf>
    <LM>w#w-d1t2129-21</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2129-22">
   <w.rf>
    <LM>w#w-d1t2129-22</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-219-271">
   <w.rf>
    <LM>w#w-219-271</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-274">
  <m id="m127-d1t2132-1">
   <w.rf>
    <LM>w#w-d1t2132-1</LM>
   </w.rf>
   <form>Přestože</form>
   <lemma>přestože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2132-2">
   <w.rf>
    <LM>w#w-d1t2132-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2132-3">
   <w.rf>
    <LM>w#w-d1t2132-3</LM>
   </w.rf>
   <form>penzisti</form>
   <lemma>penzista</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m127-d-id172872-punct">
   <w.rf>
    <LM>w#w-d-id172872-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2132-5">
   <w.rf>
    <LM>w#w-d1t2132-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2132-6">
   <w.rf>
    <LM>w#w-d1t2132-6</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m127-d1t2132-7">
   <w.rf>
    <LM>w#w-d1t2132-7</LM>
   </w.rf>
   <form>času</form>
   <lemma>čas</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m127-d1t2132-8">
   <w.rf>
    <LM>w#w-d1t2132-8</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m127-d1t2132-10">
   <w.rf>
    <LM>w#w-d1t2132-10</LM>
   </w.rf>
   <form>nazbyt</form>
   <lemma>nazbyt</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d-m-d1e2118-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2118-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2133-x2">
  <m id="m127-d1t2136-1">
   <w.rf>
    <LM>w#w-d1t2136-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m127-d1e2133-x2-269">
   <w.rf>
    <LM>w#w-d1e2133-x2-269</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-268">
  <m id="m127-d1t2136-3">
   <w.rf>
    <LM>w#w-d1t2136-3</LM>
   </w.rf>
   <form>Koho</form>
   <lemma>kdo</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m127-d1t2136-4">
   <w.rf>
    <LM>w#w-d1t2136-4</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2136-5">
   <w.rf>
    <LM>w#w-d1t2136-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2136-6">
   <w.rf>
    <LM>w#w-d1t2136-6</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m127-d1t2136-7">
   <w.rf>
    <LM>w#w-d1t2136-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d-id173128-punct">
   <w.rf>
    <LM>w#w-d-id173128-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2137-x2">
  <m id="m127-d1t2142-2">
   <w.rf>
    <LM>w#w-d1t2142-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2142-3">
   <w.rf>
    <LM>w#w-d1t2142-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2142-4">
   <w.rf>
    <LM>w#w-d1t2142-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2142-5">
   <w.rf>
    <LM>w#w-d1t2142-5</LM>
   </w.rf>
   <form>našimi</form>
   <lemma>náš</lemma>
   <tag>PSXP7-P1-------</tag>
  </m>
  <m id="m127-d1t2144-1">
   <w.rf>
    <LM>w#w-d1t2144-1</LM>
   </w.rf>
   <form>třemi</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m127-d1t2142-6">
   <w.rf>
    <LM>w#w-d1t2142-6</LM>
   </w.rf>
   <form>vnoučky</form>
   <lemma>vnouček</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m127-d1e2137-x2-335">
   <w.rf>
    <LM>w#w-d1e2137-x2-335</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-280">
  <m id="m127-d1t2144-5">
   <w.rf>
    <LM>w#w-d1t2144-5</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m127-d1t2144-6">
   <w.rf>
    <LM>w#w-d1t2144-6</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m127-d-id173387-punct">
   <w.rf>
    <LM>w#w-d-id173387-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2144-8">
   <w.rf>
    <LM>w#w-d1t2144-8</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2144-9">
   <w.rf>
    <LM>w#w-d1t2144-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2144-10">
   <w.rf>
    <LM>w#w-d1t2144-10</LM>
   </w.rf>
   <form>mračí</form>
   <lemma>mračit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d-id173442-punct">
   <w.rf>
    <LM>w#w-d-id173442-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2144-13">
   <w.rf>
    <LM>w#w-d1t2144-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2144-14">
   <w.rf>
    <LM>w#w-d1t2144-14</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1t2144-15">
   <w.rf>
    <LM>w#w-d1t2144-15</LM>
   </w.rf>
   <form>nerad</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------N----</tag>
  </m>
  <m id="m127-d1t2144-16">
   <w.rf>
    <LM>w#w-d1t2144-16</LM>
   </w.rf>
   <form>fotografuje</form>
   <lemma>fotografovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d-id173528-punct">
   <w.rf>
    <LM>w#w-d-id173528-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2146-1">
   <w.rf>
    <LM>w#w-d1t2146-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2146-2">
   <w.rf>
    <LM>w#w-d1t2146-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2146-3">
   <w.rf>
    <LM>w#w-d1t2146-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2146-4">
   <w.rf>
    <LM>w#w-d1t2146-4</LM>
   </w.rf>
   <form>donutí</form>
   <lemma>donutit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m127-d1t2146-5">
   <w.rf>
    <LM>w#w-d1t2146-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m127-d1t2146-6">
   <w.rf>
    <LM>w#w-d1t2146-6</LM>
   </w.rf>
   <form>fotografování</form>
   <lemma>fotografování_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m127-d-id173639-punct">
   <w.rf>
    <LM>w#w-d-id173639-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2146-8">
   <w.rf>
    <LM>w#w-d1t2146-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2148-1">
   <w.rf>
    <LM>w#w-d1t2148-1</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2148-5">
   <w.rf>
    <LM>w#w-d1t2148-5</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2148-2">
   <w.rf>
    <LM>w#w-d1t2148-2</LM>
   </w.rf>
   <form>takovýhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m127-d1t2148-4">
   <w.rf>
    <LM>w#w-d1t2148-4</LM>
   </w.rf>
   <form>výraz</form>
   <lemma>výraz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-280-341">
   <w.rf>
    <LM>w#w-280-341</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-281">
  <m id="m127-d1t2155-2">
   <w.rf>
    <LM>w#w-d1t2155-2</LM>
   </w.rf>
   <form>Jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2155-3">
   <w.rf>
    <LM>w#w-d1t2155-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2155-4">
   <w.rf>
    <LM>w#w-d1t2155-4</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m127-d1t2155-8">
   <w.rf>
    <LM>w#w-d1t2155-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2155-9">
   <w.rf>
    <LM>w#w-d1t2155-9</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m127-d1t2155-5">
   <w.rf>
    <LM>w#w-d1t2155-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2155-6">
   <w.rf>
    <LM>w#w-d1t2155-6</LM>
   </w.rf>
   <form>zoologické</form>
   <lemma>zoologický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m127-d1t2155-7">
   <w.rf>
    <LM>w#w-d1t2155-7</LM>
   </w.rf>
   <form>zahradě</form>
   <lemma>zahrada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-281-343">
   <w.rf>
    <LM>w#w-281-343</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-282">
  <m id="m127-d1t2157-2">
   <w.rf>
    <LM>w#w-d1t2157-2</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2157-5">
   <w.rf>
    <LM>w#w-d1t2157-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2157-6">
   <w.rf>
    <LM>w#w-d1t2157-6</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d1t2157-7">
   <w.rf>
    <LM>w#w-d1t2157-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2157-8">
   <w.rf>
    <LM>w#w-d1t2157-8</LM>
   </w.rf>
   <form>prázdninách</form>
   <lemma>prázdniny</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m127-d1t2157-3">
   <w.rf>
    <LM>w#w-d1t2157-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2157-4">
   <w.rf>
    <LM>w#w-d1t2157-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m127-d1t2159-2">
   <w.rf>
    <LM>w#w-d1t2159-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2159-4">
   <w.rf>
    <LM>w#w-d1t2159-4</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-282-289">
   <w.rf>
    <LM>w#w-282-289</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-291">
  <m id="m127-d1t2159-9">
   <w.rf>
    <LM>w#w-d1t2159-9</LM>
   </w.rf>
   <form>Bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m127-d1t2159-10">
   <w.rf>
    <LM>w#w-d1t2159-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2159-11">
   <w.rf>
    <LM>w#w-d1t2159-11</LM>
   </w.rf>
   <form>rodiči</form>
   <lemma>rodič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m127-d1t2159-12">
   <w.rf>
    <LM>w#w-d1t2159-12</LM>
   </w.rf>
   <form>kousek</form>
   <lemma>kousek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d1t2159-13">
   <w.rf>
    <LM>w#w-d1t2159-13</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2159-15">
   <w.rf>
    <LM>w#w-d1t2159-15</LM>
   </w.rf>
   <form>Prahou</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m127-282-350">
   <w.rf>
    <LM>w#w-282-350</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-303">
  <m id="m127-d1t2166-2">
   <w.rf>
    <LM>w#w-d1t2166-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2166-3">
   <w.rf>
    <LM>w#w-d1t2166-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2166-4">
   <w.rf>
    <LM>w#w-d1t2166-4</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2166-8">
   <w.rf>
    <LM>w#w-d1t2166-8</LM>
   </w.rf>
   <form>loňský</form>
   <lemma>loňský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m127-d1t2166-9">
   <w.rf>
    <LM>w#w-d1t2166-9</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m127-303-358">
   <w.rf>
    <LM>w#w-303-358</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2166-10">
   <w.rf>
    <LM>w#w-d1t2166-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2166-11">
   <w.rf>
    <LM>w#w-d1t2166-11</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2166-12">
   <w.rf>
    <LM>w#w-d1t2166-12</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m127-303-295">
   <w.rf>
    <LM>w#w-303-295</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2166-13">
   <w.rf>
    <LM>w#w-d1t2166-13</LM>
   </w.rf>
   <form>cvikýř</form>
   <lemma>cvikýř_^(označení_pro_hermafrodita)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m127-303-296">
   <w.rf>
    <LM>w#w-303-296</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d-id174684-punct">
   <w.rf>
    <LM>w#w-d-id174684-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2168-2">
   <w.rf>
    <LM>w#w-d1t2168-2</LM>
   </w.rf>
   <form>Ondrášek</form>
   <lemma>Ondrášek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m127-303-355">
   <w.rf>
    <LM>w#w-303-355</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2166-18">
   <w.rf>
    <LM>w#w-d1t2166-18</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m127-d1t2166-16">
   <w.rf>
    <LM>w#w-d1t2166-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2166-17">
   <w.rf>
    <LM>w#w-d1t2166-17</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m127-303-356">
   <w.rf>
    <LM>w#w-303-356</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2168-4">
   <w.rf>
    <LM>w#w-d1t2168-4</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2168-5">
   <w.rf>
    <LM>w#w-d1t2168-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2168-6">
   <w.rf>
    <LM>w#w-d1t2168-6</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-303-357">
   <w.rf>
    <LM>w#w-303-357</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-313">
  <m id="m127-d1t2170-3">
   <w.rf>
    <LM>w#w-d1t2170-3</LM>
   </w.rf>
   <form>Vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2170-5">
   <w.rf>
    <LM>w#w-d1t2170-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2170-6">
   <w.rf>
    <LM>w#w-d1t2170-6</LM>
   </w.rf>
   <form>nejstarší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m127-d1t2170-11">
   <w.rf>
    <LM>w#w-d1t2170-11</LM>
   </w.rf>
   <form>Domča</form>
   <lemma>Domča-2_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m127-d-id175032-punct">
   <w.rf>
    <LM>w#w-d-id175032-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2170-14">
   <w.rf>
    <LM>w#w-d1t2170-14</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m127-d1t2170-15">
   <w.rf>
    <LM>w#w-d1t2170-15</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m127-d1t2170-16">
   <w.rf>
    <LM>w#w-d1t2170-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2170-18">
   <w.rf>
    <LM>w#w-d1t2170-18</LM>
   </w.rf>
   <form>Marek</form>
   <lemma>Marek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m127-313-304">
   <w.rf>
    <LM>w#w-313-304</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
