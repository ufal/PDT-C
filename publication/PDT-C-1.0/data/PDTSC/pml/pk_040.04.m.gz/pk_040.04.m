<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pk_040.04.w.gz" />
  </references>
 </head>
 <s id="m040-190">
  <m id="m040-d1t1005-12">
   <w.rf>
    <LM>w#w-d1t1005-12</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1005-14">
   <w.rf>
    <LM>w#w-d1t1005-14</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m040-d1t1005-15">
   <w.rf>
    <LM>w#w-d1t1005-15</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m040-d1t1005-13">
   <w.rf>
    <LM>w#w-d1t1005-13</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-190-192">
   <w.rf>
    <LM>w#w-190-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-193">
  <m id="m040-d1t1005-16">
   <w.rf>
    <LM>w#w-d1t1005-16</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1005-17">
   <w.rf>
    <LM>w#w-d1t1005-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1005-18">
   <w.rf>
    <LM>w#w-d1t1005-18</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m040-d1t1005-20">
   <w.rf>
    <LM>w#w-d1t1005-20</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m040-d1t1005-19">
   <w.rf>
    <LM>w#w-d1t1005-19</LM>
   </w.rf>
   <form>dcery</form>
   <lemma>dcera</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m040-d-m-d1e998-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e998-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1012-x2">
  <m id="m040-d1t1015-1">
   <w.rf>
    <LM>w#w-d1t1015-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1015-2">
   <w.rf>
    <LM>w#w-d1t1015-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m040-d1t1015-3">
   <w.rf>
    <LM>w#w-d1t1015-3</LM>
   </w.rf>
   <form>vezmu</form>
   <lemma>vzít</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m040-d1t1015-9">
   <w.rf>
    <LM>w#w-d1t1015-9</LM>
   </w.rf>
   <form>zleva</form>
   <lemma>zleva</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1e1012-x2-456">
   <w.rf>
    <LM>w#w-d1e1012-x2-456</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1015-10">
   <w.rf>
    <LM>w#w-d1t1015-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1e1012-x2-457">
   <w.rf>
    <LM>w#w-d1e1012-x2-457</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1e1012-x2-426">
   <w.rf>
    <LM>w#w-d1e1012-x2-426</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1015-11">
   <w.rf>
    <LM>w#w-d1t1015-11</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d-id88104-punct">
   <w.rf>
    <LM>w#w-d-id88104-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1015-13">
   <w.rf>
    <LM>w#w-d1t1015-13</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m040-d1t1015-14">
   <w.rf>
    <LM>w#w-d1t1015-14</LM>
   </w.rf>
   <form>nejstarší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m040-d1t1015-15">
   <w.rf>
    <LM>w#w-d1t1015-15</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d-id88152-punct">
   <w.rf>
    <LM>w#w-d-id88152-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1015-17">
   <w.rf>
    <LM>w#w-d1t1015-17</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m040-d-id88177-punct">
   <w.rf>
    <LM>w#w-d-id88177-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1015-19">
   <w.rf>
    <LM>w#w-d1t1015-19</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m040-d1t1015-20">
   <w.rf>
    <LM>w#w-d1t1015-20</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m040-d1t1015-21">
   <w.rf>
    <LM>w#w-d1t1015-21</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1t1015-22">
   <w.rf>
    <LM>w#w-d1t1015-22</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1015-23">
   <w.rf>
    <LM>w#w-d1t1015-23</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1e1012-x2-210">
   <w.rf>
    <LM>w#w-d1e1012-x2-210</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-211">
  <m id="m040-d1t1015-28">
   <w.rf>
    <LM>w#w-d1t1015-28</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t1015-26">
   <w.rf>
    <LM>w#w-d1t1015-26</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1017-5">
   <w.rf>
    <LM>w#w-d1t1017-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1015-27">
   <w.rf>
    <LM>w#w-d1t1015-27</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1017-6">
   <w.rf>
    <LM>w#w-d1t1017-6</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d1t1017-1">
   <w.rf>
    <LM>w#w-d1t1017-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t1017-3">
   <w.rf>
    <LM>w#w-d1t1017-3</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m040-211-212">
   <w.rf>
    <LM>w#w-211-212</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-213">
  <m id="m040-d1t1017-11">
   <w.rf>
    <LM>w#w-d1t1017-11</LM>
   </w.rf>
   <form>Nebydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m040-d1t1017-12">
   <w.rf>
    <LM>w#w-d1t1017-12</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1017-13">
   <w.rf>
    <LM>w#w-d1t1017-13</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1017-14">
   <w.rf>
    <LM>w#w-d1t1017-14</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m040-d1t1017-15">
   <w.rf>
    <LM>w#w-d1t1017-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1017-17">
   <w.rf>
    <LM>w#w-d1t1017-17</LM>
   </w.rf>
   <form>Nepomuku</form>
   <lemma>Nepomuk-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m040-213-214">
   <w.rf>
    <LM>w#w-213-214</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-215">
  <m id="m040-d1t1017-20">
   <w.rf>
    <LM>w#w-d1t1017-20</LM>
   </w.rf>
   <form>Bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t1017-21">
   <w.rf>
    <LM>w#w-d1t1017-21</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1017-23">
   <w.rf>
    <LM>w#w-d1t1017-23</LM>
   </w.rf>
   <form>Klatovech</form>
   <lemma>Klatovy_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m040-d-id88641-punct">
   <w.rf>
    <LM>w#w-d-id88641-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1019-1">
   <w.rf>
    <LM>w#w-d1t1019-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1019-2">
   <w.rf>
    <LM>w#w-d1t1019-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1019-3">
   <w.rf>
    <LM>w#w-d1t1019-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1019-4">
   <w.rf>
    <LM>w#w-d1t1019-4</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1019-5">
   <w.rf>
    <LM>w#w-d1t1019-5</LM>
   </w.rf>
   <form>navštěvovali</form>
   <lemma>navštěvovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-215-216">
   <w.rf>
    <LM>w#w-215-216</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-217">
  <m id="m040-d1t1019-11">
   <w.rf>
    <LM>w#w-d1t1019-11</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t1019-8">
   <w.rf>
    <LM>w#w-d1t1019-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1019-9">
   <w.rf>
    <LM>w#w-d1t1019-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1019-10">
   <w.rf>
    <LM>w#w-d1t1019-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1019-12">
   <w.rf>
    <LM>w#w-d1t1019-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t1019-13">
   <w.rf>
    <LM>w#w-d1t1019-13</LM>
   </w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3------1</tag>
  </m>
  <m id="m040-d1t1019-14">
   <w.rf>
    <LM>w#w-d1t1019-14</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d-m-d1e1012-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1012-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1032-x2">
  <m id="m040-d1t1035-1">
   <w.rf>
    <LM>w#w-d1t1035-1</LM>
   </w.rf>
   <form>Trávíte</form>
   <lemma>trávit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m040-d1t1035-3">
   <w.rf>
    <LM>w#w-d1t1035-3</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m040-d1t1035-5">
   <w.rf>
    <LM>w#w-d1t1035-5</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1035-6">
   <w.rf>
    <LM>w#w-d1t1035-6</LM>
   </w.rf>
   <form>pohromadě</form>
   <lemma>pohromadě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d-id89043-punct">
   <w.rf>
    <LM>w#w-d-id89043-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1036-x2">
  <m id="m040-d1t1043-2">
   <w.rf>
    <LM>w#w-d1t1043-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1043-7">
   <w.rf>
    <LM>w#w-d1t1043-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1043-8">
   <w.rf>
    <LM>w#w-d1t1043-8</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m040-d1t1043-9">
   <w.rf>
    <LM>w#w-d1t1043-9</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1043-10">
   <w.rf>
    <LM>w#w-d1t1043-10</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1043-11">
   <w.rf>
    <LM>w#w-d1t1043-11</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m040-d1e1036-x2-232">
   <w.rf>
    <LM>w#w-d1e1036-x2-232</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1043-12">
   <w.rf>
    <LM>w#w-d1t1043-12</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1043-13">
   <w.rf>
    <LM>w#w-d1t1043-13</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m040-d1t1043-16">
   <w.rf>
    <LM>w#w-d1t1043-16</LM>
   </w.rf>
   <form>Dvorci</form>
   <lemma>Dvorec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m040-d1e1036-x2-230">
   <w.rf>
    <LM>w#w-d1e1036-x2-230</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-231">
  <m id="m040-d1t1045-3">
   <w.rf>
    <LM>w#w-d1t1045-3</LM>
   </w.rf>
   <form>Nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m040-d1t1045-4">
   <w.rf>
    <LM>w#w-d1t1045-4</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1t1045-5">
   <w.rf>
    <LM>w#w-d1t1045-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m040-d1t1045-6">
   <w.rf>
    <LM>w#w-d1t1045-6</LM>
   </w.rf>
   <form>postavila</form>
   <lemma>postavit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m040-d1t1045-7">
   <w.rf>
    <LM>w#w-d1t1045-7</LM>
   </w.rf>
   <form>domeček</form>
   <lemma>domeček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m040-d-id89457-punct">
   <w.rf>
    <LM>w#w-d-id89457-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1047-1">
   <w.rf>
    <LM>w#w-d1t1047-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1047-3">
   <w.rf>
    <LM>w#w-d1t1047-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1047-2">
   <w.rf>
    <LM>w#w-d1t1047-2</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1047-4">
   <w.rf>
    <LM>w#w-d1t1047-4</LM>
   </w.rf>
   <form>scházíme</form>
   <lemma>scházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1047-7">
   <w.rf>
    <LM>w#w-d1t1047-7</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m040-d1t1047-5">
   <w.rf>
    <LM>w#w-d1t1047-5</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1047-6">
   <w.rf>
    <LM>w#w-d1t1047-6</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m040-231-233">
   <w.rf>
    <LM>w#w-231-233</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-234">
  <m id="m040-d1t1047-10">
   <w.rf>
    <LM>w#w-d1t1047-10</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1047-11">
   <w.rf>
    <LM>w#w-d1t1047-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t1047-13">
   <w.rf>
    <LM>w#w-d1t1047-13</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1047-14">
   <w.rf>
    <LM>w#w-d1t1047-14</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m040-d-id89678-punct">
   <w.rf>
    <LM>w#w-d-id89678-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1047-16">
   <w.rf>
    <LM>w#w-d1t1047-16</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1047-17">
   <w.rf>
    <LM>w#w-d1t1047-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1047-18">
   <w.rf>
    <LM>w#w-d1t1047-18</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m040-d1t1047-19">
   <w.rf>
    <LM>w#w-d1t1047-19</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1047-20">
   <w.rf>
    <LM>w#w-d1t1047-20</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-234-235">
   <w.rf>
    <LM>w#w-234-235</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-236">
  <m id="m040-d1t1050-1">
   <w.rf>
    <LM>w#w-d1t1050-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1050-2">
   <w.rf>
    <LM>w#w-d1t1050-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t1050-4">
   <w.rf>
    <LM>w#w-d1t1050-4</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m040-236-237">
   <w.rf>
    <LM>w#w-236-237</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-239">
  <m id="m040-d1t1050-6">
   <w.rf>
    <LM>w#w-d1t1050-6</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1050-7">
   <w.rf>
    <LM>w#w-d1t1050-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m040-d1t1050-8">
   <w.rf>
    <LM>w#w-d1t1050-8</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1050-10">
   <w.rf>
    <LM>w#w-d1t1050-10</LM>
   </w.rf>
   <form>dodržujeme</form>
   <lemma>dodržovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1052-1">
   <w.rf>
    <LM>w#w-d1t1052-1</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m040-d1t1052-2">
   <w.rf>
    <LM>w#w-d1t1052-2</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m040-239-240">
   <w.rf>
    <LM>w#w-239-240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-241">
  <m id="m040-d1t1052-4">
   <w.rf>
    <LM>w#w-d1t1052-4</LM>
   </w.rf>
   <form>Děláme</form>
   <lemma>dělat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1052-7">
   <w.rf>
    <LM>w#w-d1t1052-7</LM>
   </w.rf>
   <form>Štědrý</form>
   <lemma>štědrý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m040-d1t1052-8">
   <w.rf>
    <LM>w#w-d1t1052-8</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m040-d1t1052-10">
   <w.rf>
    <LM>w#w-d1t1052-10</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1052-11">
   <w.rf>
    <LM>w#w-d1t1052-11</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m040-d-m-d1e1036-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1036-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1053-x3">
  <m id="m040-d1t1060-1">
   <w.rf>
    <LM>w#w-d1t1060-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t1060-2">
   <w.rf>
    <LM>w#w-d1t1060-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1060-3">
   <w.rf>
    <LM>w#w-d1t1060-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m040-d-m-d1e1053-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1053-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1061-x2">
  <m id="m040-d1t1064-1">
   <w.rf>
    <LM>w#w-d1t1064-1</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1064-2">
   <w.rf>
    <LM>w#w-d1t1064-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t1064-3">
   <w.rf>
    <LM>w#w-d1t1064-3</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m040-d1t1064-4">
   <w.rf>
    <LM>w#w-d1t1064-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1064-5">
   <w.rf>
    <LM>w#w-d1t1064-5</LM>
   </w.rf>
   <form>lepší</form>
   <lemma>lepší</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m040-d1e1061-x2-254">
   <w.rf>
    <LM>w#w-d1e1061-x2-254</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-255">
  <m id="m040-d1t1064-7">
   <w.rf>
    <LM>w#w-d1t1064-7</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1064-16">
   <w.rf>
    <LM>w#w-d1t1064-16</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1064-9">
   <w.rf>
    <LM>w#w-d1t1064-9</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1064-12">
   <w.rf>
    <LM>w#w-d1t1064-12</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m040-d1t1064-13">
   <w.rf>
    <LM>w#w-d1t1064-13</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1t1064-14">
   <w.rf>
    <LM>w#w-d1t1064-14</LM>
   </w.rf>
   <form>osmiměsíční</form>
   <lemma>osmiměsíční</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m040-d1t1064-15">
   <w.rf>
    <LM>w#w-d1t1064-15</LM>
   </w.rf>
   <form>vnučku</form>
   <lemma>vnučka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m040-d-id90475-punct">
   <w.rf>
    <LM>w#w-d-id90475-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1066-1">
   <w.rf>
    <LM>w#w-d1t1066-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1066-2">
   <w.rf>
    <LM>w#w-d1t1066-2</LM>
   </w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1066-3">
   <w.rf>
    <LM>w#w-d1t1066-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1066-4">
   <w.rf>
    <LM>w#w-d1t1066-4</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m040-d1t1066-6">
   <w.rf>
    <LM>w#w-d1t1066-6</LM>
   </w.rf>
   <form>stromečku</form>
   <lemma>stromeček</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m040-d1t1066-7">
   <w.rf>
    <LM>w#w-d1t1066-7</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m040-d1t1066-8">
   <w.rf>
    <LM>w#w-d1t1066-8</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m040-d1t1066-9">
   <w.rf>
    <LM>w#w-d1t1066-9</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m040-255-256">
   <w.rf>
    <LM>w#w-255-256</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-257">
  <m id="m040-d1t1066-13">
   <w.rf>
    <LM>w#w-d1t1066-13</LM>
   </w.rf>
   <form>Bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m040-d1t1066-12">
   <w.rf>
    <LM>w#w-d1t1066-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t1066-14">
   <w.rf>
    <LM>w#w-d1t1066-14</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1066-15">
   <w.rf>
    <LM>w#w-d1t1066-15</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1066-16">
   <w.rf>
    <LM>w#w-d1t1066-16</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1066-17">
   <w.rf>
    <LM>w#w-d1t1066-17</LM>
   </w.rf>
   <form>hezčí</form>
   <lemma>hezký</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m040-d-m-d1e1061-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1061-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1069-x2">
  <m id="m040-d1t1072-1">
   <w.rf>
    <LM>w#w-d1t1072-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t1072-2">
   <w.rf>
    <LM>w#w-d1t1072-2</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1072-3">
   <w.rf>
    <LM>w#w-d1t1072-3</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d1t1072-4">
   <w.rf>
    <LM>w#w-d1t1072-4</LM>
   </w.rf>
   <form>veselo</form>
   <lemma>veselo-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d-id90843-punct">
   <w.rf>
    <LM>w#w-d-id90843-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1072-6">
   <w.rf>
    <LM>w#w-d1t1072-6</LM>
   </w.rf>
   <form>viďte</form>
   <lemma>viďte</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d-id90868-punct">
   <w.rf>
    <LM>w#w-d-id90868-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1073-x2">
  <m id="m040-d1t1076-2">
   <w.rf>
    <LM>w#w-d1t1076-2</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d-m-d1e1073-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1073-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1085-x2">
  <m id="m040-d1t1090-3">
   <w.rf>
    <LM>w#w-d1t1090-3</LM>
   </w.rf>
   <form>Chodíme</form>
   <lemma>chodit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1090-4">
   <w.rf>
    <LM>w#w-d1t1090-4</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m040-d1t1090-5">
   <w.rf>
    <LM>w#w-d1t1090-5</LM>
   </w.rf>
   <form>pomáhat</form>
   <lemma>pomáhat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m040-d-m-d1e1085-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1085-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1085-x3">
  <m id="m040-d1t1092-1">
   <w.rf>
    <LM>w#w-d1t1092-1</LM>
   </w.rf>
   <form>Vzpomenete</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m040-d1t1092-2">
   <w.rf>
    <LM>w#w-d1t1092-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m040-d1t1092-3">
   <w.rf>
    <LM>w#w-d1t1092-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t1092-4">
   <w.rf>
    <LM>w#w-d1t1092-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m040-d1t1092-5">
   <w.rf>
    <LM>w#w-d1t1092-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1092-6">
   <w.rf>
    <LM>w#w-d1t1092-6</LM>
   </w.rf>
   <form>těchhle</form>
   <lemma>tenhle</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m040-d1t1092-8">
   <w.rf>
    <LM>w#w-d1t1092-8</LM>
   </w.rf>
   <form>Vánoc</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m040-d-id91288-punct">
   <w.rf>
    <LM>w#w-d-id91288-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1093-x2">
  <m id="m040-d1e1093-x2-275">
   <w.rf>
    <LM>w#w-d1e1093-x2-275</LM>
   </w.rf>
   <form>Probíhají</form>
   <lemma>probíhat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1098-4">
   <w.rf>
    <LM>w#w-d1t1098-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1098-9">
   <w.rf>
    <LM>w#w-d1t1098-9</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1098-13">
   <w.rf>
    <LM>w#w-d1t1098-13</LM>
   </w.rf>
   <form>klasicky</form>
   <lemma>klasicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d1e1093-x2-276">
   <w.rf>
    <LM>w#w-d1e1093-x2-276</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1098-14">
   <w.rf>
    <LM>w#w-d1t1098-14</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1098-15">
   <w.rf>
    <LM>w#w-d1t1098-15</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m040-d1e1093-x2-271">
   <w.rf>
    <LM>w#w-d1e1093-x2-271</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-272">
  <m id="m040-d1t1100-3">
   <w.rf>
    <LM>w#w-d1t1100-3</LM>
   </w.rf>
   <form>Nejezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m040-d1t1100-2">
   <w.rf>
    <LM>w#w-d1t1100-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1100-1">
   <w.rf>
    <LM>w#w-d1t1100-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1100-4">
   <w.rf>
    <LM>w#w-d1t1100-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1100-5">
   <w.rf>
    <LM>w#w-d1t1100-5</LM>
   </w.rf>
   <form>večeři</form>
   <lemma>večeře</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-272-273">
   <w.rf>
    <LM>w#w-272-273</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-274">
  <m id="m040-d1t1102-4">
   <w.rf>
    <LM>w#w-d1t1102-4</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t1102-3">
   <w.rf>
    <LM>w#w-d1t1102-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1102-1">
   <w.rf>
    <LM>w#w-d1t1102-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1102-2">
   <w.rf>
    <LM>w#w-d1t1102-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1102-6">
   <w.rf>
    <LM>w#w-d1t1102-6</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1102-9">
   <w.rf>
    <LM>w#w-d1t1102-9</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m040-d1t1102-12">
   <w.rf>
    <LM>w#w-d1t1102-12</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1102-13">
   <w.rf>
    <LM>w#w-d1t1102-13</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m040-d1t1102-10">
   <w.rf>
    <LM>w#w-d1t1102-10</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m040-d1t1102-11">
   <w.rf>
    <LM>w#w-d1t1102-11</LM>
   </w.rf>
   <form>sváteční</form>
   <lemma>sváteční</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m040-d-m-d1e1093-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1093-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1105-x2">
  <m id="m040-d1t1110-1">
   <w.rf>
    <LM>w#w-d1t1110-1</LM>
   </w.rf>
   <form>Jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1110-2">
   <w.rf>
    <LM>w#w-d1t1110-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1110-3">
   <w.rf>
    <LM>w#w-d1t1110-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t1110-4">
   <w.rf>
    <LM>w#w-d1t1110-4</LM>
   </w.rf>
   <form>návštěvu</form>
   <lemma>návštěva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m040-d1t1110-5">
   <w.rf>
    <LM>w#w-d1t1110-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1110-6">
   <w.rf>
    <LM>w#w-d1t1110-6</LM>
   </w.rf>
   <form>odvézt</form>
   <lemma>odvézt</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d1t1110-7">
   <w.rf>
    <LM>w#w-d1t1110-7</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m040-d1t1110-8">
   <w.rf>
    <LM>w#w-d1t1110-8</LM>
   </w.rf>
   <form>dárky</form>
   <lemma>dárek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m040-d1e1105-x2-279">
   <w.rf>
    <LM>w#w-d1e1105-x2-279</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1118-3">
   <w.rf>
    <LM>w#w-d1t1118-3</LM>
   </w.rf>
   <form>odvézt</form>
   <lemma>odvézt</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d1t1118-4">
   <w.rf>
    <LM>w#w-d1t1118-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m040-d1t1118-5">
   <w.rf>
    <LM>w#w-d1t1118-5</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1118-6">
   <w.rf>
    <LM>w#w-d1t1118-6</LM>
   </w.rf>
   <form>dárky</form>
   <lemma>dárek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m040-d1t1118-7">
   <w.rf>
    <LM>w#w-d1t1118-7</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1118-8">
   <w.rf>
    <LM>w#w-d1t1118-8</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m040-d-m-d1e1115-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1115-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1122-x2">
  <m id="m040-d1t1125-1">
   <w.rf>
    <LM>w#w-d1t1125-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m040-d1t1125-2">
   <w.rf>
    <LM>w#w-d1t1125-2</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m040-d1t1125-4">
   <w.rf>
    <LM>w#w-d1t1125-4</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m040-d-id92390-punct">
   <w.rf>
    <LM>w#w-d-id92390-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1126-x2">
  <m id="m040-d1t1133-1">
   <w.rf>
    <LM>w#w-d1t1133-1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1133-2">
   <w.rf>
    <LM>w#w-d1t1133-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m040-d1t1133-3">
   <w.rf>
    <LM>w#w-d1t1133-3</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m040-d1e1126-x2-532">
   <w.rf>
    <LM>w#w-d1e1126-x2-532</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-533">
  <m id="m040-d1t1133-5">
   <w.rf>
    <LM>w#w-d1t1133-5</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1135-5">
   <w.rf>
    <LM>w#w-d1t1135-5</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m040-d1t1135-4">
   <w.rf>
    <LM>w#w-d1t1135-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1135-3">
   <w.rf>
    <LM>w#w-d1t1135-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m040-d-id92659-punct">
   <w.rf>
    <LM>w#w-d-id92659-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1135-7">
   <w.rf>
    <LM>w#w-d1t1135-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1135-8">
   <w.rf>
    <LM>w#w-d1t1135-8</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m040-d1t1135-9">
   <w.rf>
    <LM>w#w-d1t1135-9</LM>
   </w.rf>
   <form>zemřela</form>
   <lemma>zemřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m040-d1t1135-10">
   <w.rf>
    <LM>w#w-d1t1135-10</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d-id92724-punct">
   <w.rf>
    <LM>w#w-d-id92724-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1137-1">
   <w.rf>
    <LM>w#w-d1t1137-1</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS3----------</tag>
  </m>
  <m id="m040-d1t1137-2">
   <w.rf>
    <LM>w#w-d1t1137-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m040-d1t1137-3">
   <w.rf>
    <LM>w#w-d1t1137-3</LM>
   </w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m040-d1t1137-4">
   <w.rf>
    <LM>w#w-d1t1137-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m040-d-m-d1e1126-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1126-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1138-x2">
  <m id="m040-d1t1141-1">
   <w.rf>
    <LM>w#w-d1t1141-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t1141-2">
   <w.rf>
    <LM>w#w-d1t1141-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m040-d1t1141-3">
   <w.rf>
    <LM>w#w-d1t1141-3</LM>
   </w.rf>
   <form>mrzí</form>
   <lemma>mrzet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d-m-d1e1138-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1138-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1142-x2">
  <m id="m040-d1t1145-6">
   <w.rf>
    <LM>w#w-d1t1145-6</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1145-7">
   <w.rf>
    <LM>w#w-d1t1145-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1145-8">
   <w.rf>
    <LM>w#w-d1t1145-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t1145-9">
   <w.rf>
    <LM>w#w-d1t1145-9</LM>
   </w.rf>
   <form>osmnáct</form>
   <lemma>osmnáct`18</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m040-d1t1145-10">
   <w.rf>
    <LM>w#w-d1t1145-10</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m040-d-id93090-punct">
   <w.rf>
    <LM>w#w-d-id93090-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1145-12">
   <w.rf>
    <LM>w#w-d1t1145-12</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1145-13">
   <w.rf>
    <LM>w#w-d1t1145-13</LM>
   </w.rf>
   <form>přesto</form>
   <lemma>přesto-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1145-14">
   <w.rf>
    <LM>w#w-d1t1145-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t1145-15">
   <w.rf>
    <LM>w#w-d1t1145-15</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m040-d1t1145-16">
   <w.rf>
    <LM>w#w-d1t1145-16</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1t1145-17">
   <w.rf>
    <LM>w#w-d1t1145-17</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m040-d1t1145-18">
   <w.rf>
    <LM>w#w-d1t1145-18</LM>
   </w.rf>
   <form>zapomenout</form>
   <lemma>zapomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d1e1142-x2-293">
   <w.rf>
    <LM>w#w-d1e1142-x2-293</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-294">
  <m id="m040-d1t1145-21">
   <w.rf>
    <LM>w#w-d1t1145-21</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1145-22">
   <w.rf>
    <LM>w#w-d1t1145-22</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1145-23">
   <w.rf>
    <LM>w#w-d1t1145-23</LM>
   </w.rf>
   <form>takovéhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m040-d1t1145-24">
   <w.rf>
    <LM>w#w-d1t1145-24</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZIP1----------</tag>
  </m>
  <m id="m040-d1t1145-26">
   <w.rf>
    <LM>w#w-d1t1145-26</LM>
   </w.rf>
   <form>svátky</form>
   <lemma>svátek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m040-d-id93305-punct">
   <w.rf>
    <LM>w#w-d-id93305-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1145-28">
   <w.rf>
    <LM>w#w-d1t1145-28</LM>
   </w.rf>
   <form>oslavy</form>
   <lemma>oslava</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m040-d-id93329-punct">
   <w.rf>
    <LM>w#w-d-id93329-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1147-5">
   <w.rf>
    <LM>w#w-d1t1147-5</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1t1147-2">
   <w.rf>
    <LM>w#w-d1t1147-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m040-d1t1147-3">
   <w.rf>
    <LM>w#w-d1t1147-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t1147-4">
   <w.rf>
    <LM>w#w-d1t1147-4</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m040-d1t1147-8">
   <w.rf>
    <LM>w#w-d1t1147-8</LM>
   </w.rf>
   <form>vzpomene</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m040-294-295">
   <w.rf>
    <LM>w#w-294-295</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-296">
  <m id="m040-d1t1147-15">
   <w.rf>
    <LM>w#w-d1t1147-15</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1147-16">
   <w.rf>
    <LM>w#w-d1t1147-16</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m040-d1t1147-17">
   <w.rf>
    <LM>w#w-d1t1147-17</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d1t1147-19">
   <w.rf>
    <LM>w#w-d1t1147-19</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1147-20">
   <w.rf>
    <LM>w#w-d1t1147-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t1147-18">
   <w.rf>
    <LM>w#w-d1t1147-18</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1147-10">
   <w.rf>
    <LM>w#w-d1t1147-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1147-22">
   <w.rf>
    <LM>w#w-d1t1147-22</LM>
   </w.rf>
   <form>lepší</form>
   <lemma>lepší</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m040-d-m-d1e1142-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1142-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1148-x2">
  <m id="m040-d1e1148-x2-510">
   <w.rf>
    <LM>w#w-d1e1148-x2-510</LM>
   </w.rf>
   <form>Rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m040-d1e1148-x2-511">
   <w.rf>
    <LM>w#w-d1e1148-x2-511</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m040-d1t1153-3">
   <w.rf>
    <LM>w#w-d1t1153-3</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m040-d1t1153-4">
   <w.rf>
    <LM>w#w-d1t1153-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1e1148-x2-512">
   <w.rf>
    <LM>w#w-d1e1148-x2-512</LM>
   </w.rf>
   <form>viděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m040-d1t1153-6">
   <w.rf>
    <LM>w#w-d1t1153-6</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d-m-d1e1148-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1148-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1148-x3">
  <m id="m040-d1t1155-1">
   <w.rf>
    <LM>w#w-d1t1155-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d-m-d1e1148-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1148-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1162-x2">
  <m id="m040-d1t1165-1">
   <w.rf>
    <LM>w#w-d1t1165-1</LM>
   </w.rf>
   <form>Dodržujete</form>
   <lemma>dodržovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m040-d1t1165-2">
   <w.rf>
    <LM>w#w-d1t1165-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m040-d1t1165-3">
   <w.rf>
    <LM>w#w-d1t1165-3</LM>
   </w.rf>
   <form>vánoční</form>
   <lemma>vánoční</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m040-d1t1165-4">
   <w.rf>
    <LM>w#w-d1t1165-4</LM>
   </w.rf>
   <form>zvyky</form>
   <lemma>zvyk</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m040-d-id93912-punct">
   <w.rf>
    <LM>w#w-d-id93912-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1166-x2">
  <m id="m040-d1t1171-4">
   <w.rf>
    <LM>w#w-d1t1171-4</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1171-1">
   <w.rf>
    <LM>w#w-d1t1171-1</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1e1166-x2-301">
   <w.rf>
    <LM>w#w-d1e1166-x2-301</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-303">
  <m id="m040-303-528">
   <w.rf>
    <LM>w#w-303-528</LM>
   </w.rf>
   <form>Jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1173-2">
   <w.rf>
    <LM>w#w-d1t1173-2</LM>
   </w.rf>
   <form>kapra</form>
   <lemma>kapr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m040-d-id94070-punct">
   <w.rf>
    <LM>w#w-d-id94070-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1173-5">
   <w.rf>
    <LM>w#w-d1t1173-5</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1173-7">
   <w.rf>
    <LM>w#w-d1t1173-7</LM>
   </w.rf>
   <form>řízky</form>
   <lemma>řízek-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m040-d1t1173-8">
   <w.rf>
    <LM>w#w-d1t1173-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1173-9">
   <w.rf>
    <LM>w#w-d1t1173-9</LM>
   </w.rf>
   <form>kapra</form>
   <lemma>kapr</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m040-303-304">
   <w.rf>
    <LM>w#w-303-304</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1173-10">
   <w.rf>
    <LM>w#w-d1t1173-10</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1173-13">
   <w.rf>
    <LM>w#w-d1t1173-13</LM>
   </w.rf>
   <form>stromeček</form>
   <lemma>stromeček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m040-d1t1173-14">
   <w.rf>
    <LM>w#w-d1t1173-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1187-3">
   <w.rf>
    <LM>w#w-d1t1187-3</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1187-4">
   <w.rf>
    <LM>w#w-d1t1187-4</LM>
   </w.rf>
   <form>jdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1187-5">
   <w.rf>
    <LM>w#w-d1t1187-5</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1187-6">
   <w.rf>
    <LM>w#w-d1t1187-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t1187-8">
   <w.rf>
    <LM>w#w-d1t1187-8</LM>
   </w.rf>
   <form>půlnoční</form>
   <lemma>půlnoční-1</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m040-d1t1187-9">
   <w.rf>
    <LM>w#w-d1t1187-9</LM>
   </w.rf>
   <form>mši</form>
   <lemma>mše</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m040-d-id94508-punct">
   <w.rf>
    <LM>w#w-d-id94508-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1187-11">
   <w.rf>
    <LM>w#w-d1t1187-11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1187-13">
   <w.rf>
    <LM>w#w-d1t1187-13</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1187-14">
   <w.rf>
    <LM>w#w-d1t1187-14</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m040-d1t1187-15">
   <w.rf>
    <LM>w#w-d1t1187-15</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m040-303-314">
   <w.rf>
    <LM>w#w-303-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1190-x2">
  <m id="m040-d1t1193-1">
   <w.rf>
    <LM>w#w-d1t1193-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m040-d1t1193-2">
   <w.rf>
    <LM>w#w-d1t1193-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m040-d1t1193-3">
   <w.rf>
    <LM>w#w-d1t1193-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m040-d1t1193-4">
   <w.rf>
    <LM>w#w-d1t1193-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1193-5">
   <w.rf>
    <LM>w#w-d1t1193-5</LM>
   </w.rf>
   <form>vaší</form>
   <lemma>váš</lemma>
   <tag>PSFS6-P2-------</tag>
  </m>
  <m id="m040-d1t1193-6">
   <w.rf>
    <LM>w#w-d1t1193-6</LM>
   </w.rf>
   <form>nejstarší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS6----3A----</tag>
  </m>
  <m id="m040-d1t1193-7">
   <w.rf>
    <LM>w#w-d1t1193-7</LM>
   </w.rf>
   <form>dceři</form>
   <lemma>dcera</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d-id94813-punct">
   <w.rf>
    <LM>w#w-d-id94813-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1194-x2">
  <m id="m040-d1t1203-6">
   <w.rf>
    <LM>w#w-d1t1203-6</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1203-7">
   <w.rf>
    <LM>w#w-d1t1203-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1203-8">
   <w.rf>
    <LM>w#w-d1t1203-8</LM>
   </w.rf>
   <form>vdaná</form>
   <lemma>vdaný_^(*3át)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m040-d1t1203-9">
   <w.rf>
    <LM>w#w-d1t1203-9</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1203-11">
   <w.rf>
    <LM>w#w-d1t1203-11</LM>
   </w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m040-d1t1203-12">
   <w.rf>
    <LM>w#w-d1t1203-12</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m040-d-m-d1e1194-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1194-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1204-x2">
  <m id="m040-d1t1211-1">
   <w.rf>
    <LM>w#w-d1t1211-1</LM>
   </w.rf>
   <form>Nejdřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m040-d1t1211-2">
   <w.rf>
    <LM>w#w-d1t1211-2</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t1211-3">
   <w.rf>
    <LM>w#w-d1t1211-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1211-4">
   <w.rf>
    <LM>w#w-d1t1211-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1211-6">
   <w.rf>
    <LM>w#w-d1t1211-6</LM>
   </w.rf>
   <form>Nepomuku</form>
   <lemma>Nepomuk-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m040-d-m-d1e1204-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1204-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1216-x2">
  <m id="m040-d1t1219-1">
   <w.rf>
    <LM>w#w-d1t1219-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1219-2">
   <w.rf>
    <LM>w#w-d1t1219-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1219-3">
   <w.rf>
    <LM>w#w-d1t1219-3</LM>
   </w.rf>
   <form>odstěhovali</form>
   <lemma>odstěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m040-d1t1219-4">
   <w.rf>
    <LM>w#w-d1t1219-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1219-7">
   <w.rf>
    <LM>w#w-d1t1219-7</LM>
   </w.rf>
   <form>Klatov</form>
   <lemma>Klatovy_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m040-d1t1219-9">
   <w.rf>
    <LM>w#w-d1t1219-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1219-12">
   <w.rf>
    <LM>w#w-d1t1219-12</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1219-13">
   <w.rf>
    <LM>w#w-d1t1219-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1219-14">
   <w.rf>
    <LM>w#w-d1t1219-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1219-15">
   <w.rf>
    <LM>w#w-d1t1219-15</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1219-16">
   <w.rf>
    <LM>w#w-d1t1219-16</LM>
   </w.rf>
   <form>vrátili</form>
   <lemma>vrátit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m040-d1t1219-17">
   <w.rf>
    <LM>w#w-d1t1219-17</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1e1216-x2-571">
   <w.rf>
    <LM>w#w-d1e1216-x2-571</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1219-18">
   <w.rf>
    <LM>w#w-d1t1219-18</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1219-19">
   <w.rf>
    <LM>w#w-d1t1219-19</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1219-22">
   <w.rf>
    <LM>w#w-d1t1219-22</LM>
   </w.rf>
   <form>Nepomuka</form>
   <lemma>Nepomuk-2_;G</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m040-d1e1216-x2-339">
   <w.rf>
    <LM>w#w-d1e1216-x2-339</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-340">
  <m id="m040-d1t1223-7">
   <w.rf>
    <LM>w#w-d1t1223-7</LM>
   </w.rf>
   <form>Museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t1223-3">
   <w.rf>
    <LM>w#w-d1t1223-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1223-5">
   <w.rf>
    <LM>w#w-d1t1223-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m040-d1t1223-6">
   <w.rf>
    <LM>w#w-d1t1223-6</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m040-d1t1223-8">
   <w.rf>
    <LM>w#w-d1t1223-8</LM>
   </w.rf>
   <form>brát</form>
   <lemma>brát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m040-340-581">
   <w.rf>
    <LM>w#w-340-581</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-582">
  <m id="m040-d1t1223-11">
   <w.rf>
    <LM>w#w-d1t1223-11</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1t1223-12">
   <w.rf>
    <LM>w#w-d1t1223-12</LM>
   </w.rf>
   <form>odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m040-d1t1223-13">
   <w.rf>
    <LM>w#w-d1t1223-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t1223-14">
   <w.rf>
    <LM>w#w-d1t1223-14</LM>
   </w.rf>
   <form>vojnu</form>
   <lemma>vojna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m040-340-341">
   <w.rf>
    <LM>w#w-340-341</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-342">
  <m id="m040-d1t1225-2">
   <w.rf>
    <LM>w#w-d1t1225-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m040-d1t1225-3">
   <w.rf>
    <LM>w#w-d1t1225-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1225-4">
   <w.rf>
    <LM>w#w-d1t1225-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1225-5">
   <w.rf>
    <LM>w#w-d1t1225-5</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m040-d1t1225-6">
   <w.rf>
    <LM>w#w-d1t1225-6</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m040-d-id95940-punct">
   <w.rf>
    <LM>w#w-d-id95940-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1225-8">
   <w.rf>
    <LM>w#w-d1t1225-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1225-9">
   <w.rf>
    <LM>w#w-d1t1225-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1225-10">
   <w.rf>
    <LM>w#w-d1t1225-10</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m040-d1t1225-12">
   <w.rf>
    <LM>w#w-d1t1225-12</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m040-d1t1227-1">
   <w.rf>
    <LM>w#w-d1t1227-1</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m040-d1t1227-2">
   <w.rf>
    <LM>w#w-d1t1227-2</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d-id96083-punct">
   <w.rf>
    <LM>w#w-d-id96083-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1227-5">
   <w.rf>
    <LM>w#w-d1t1227-5</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1t1227-7">
   <w.rf>
    <LM>w#w-d1t1227-7</LM>
   </w.rf>
   <form>Vašík</form>
   <lemma>Vašík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d-m-d1e1216-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1216-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1231-x2">
  <m id="m040-d1t1236-4">
   <w.rf>
    <LM>w#w-d1t1236-4</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t1236-5">
   <w.rf>
    <LM>w#w-d1t1236-5</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m040-d1t1236-6">
   <w.rf>
    <LM>w#w-d1t1236-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1236-7">
   <w.rf>
    <LM>w#w-d1t1236-7</LM>
   </w.rf>
   <form>vojny</form>
   <lemma>vojna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m040-d-id96312-punct">
   <w.rf>
    <LM>w#w-d-id96312-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1236-10">
   <w.rf>
    <LM>w#w-d1t1236-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1236-11">
   <w.rf>
    <LM>w#w-d1t1236-11</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m040-d1t1246-2">
   <w.rf>
    <LM>w#w-d1t1246-2</LM>
   </w.rf>
   <form>roční</form>
   <lemma>roční</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m040-d1t1246-3">
   <w.rf>
    <LM>w#w-d1t1246-3</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m040-d-m-d1e1241-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1241-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e1249-x2">
  <m id="m040-d1t1265-4">
   <w.rf>
    <LM>w#w-d1t1265-4</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1265-6">
   <w.rf>
    <LM>w#w-d1t1265-6</LM>
   </w.rf>
   <form>vojně</form>
   <lemma>vojna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d1t1265-7">
   <w.rf>
    <LM>w#w-d1t1265-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1265-8">
   <w.rf>
    <LM>w#w-d1t1265-8</LM>
   </w.rf>
   <form>přestěhovali</form>
   <lemma>přestěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m040-d1t1265-9">
   <w.rf>
    <LM>w#w-d1t1265-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1265-12">
   <w.rf>
    <LM>w#w-d1t1265-12</LM>
   </w.rf>
   <form>Klatov</form>
   <lemma>Klatovy_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m040-d1e1249-x2-361">
   <w.rf>
    <LM>w#w-d1e1249-x2-361</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-362">
  <m id="m040-d1t1265-15">
   <w.rf>
    <LM>w#w-d1t1265-15</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1265-16">
   <w.rf>
    <LM>w#w-d1t1265-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1265-17">
   <w.rf>
    <LM>w#w-d1t1265-17</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m040-d1t1265-18">
   <w.rf>
    <LM>w#w-d1t1265-18</LM>
   </w.rf>
   <form>narodila</form>
   <lemma>narodit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m040-d1t1265-21">
   <w.rf>
    <LM>w#w-d1t1265-21</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-362-363">
   <w.rf>
    <LM>w#w-362-363</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-364">
  <m id="m040-d1t1267-2">
   <w.rf>
    <LM>w#w-d1t1267-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1267-3">
   <w.rf>
    <LM>w#w-d1t1267-3</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1t1267-4">
   <w.rf>
    <LM>w#w-d1t1267-4</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1267-5">
   <w.rf>
    <LM>w#w-d1t1267-5</LM>
   </w.rf>
   <form>zástupkyni</form>
   <lemma>zástupkyně_^(*4ce)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m040-d1t1267-6">
   <w.rf>
    <LM>w#w-d1t1267-6</LM>
   </w.rf>
   <form>prodejny</form>
   <lemma>prodejna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m040-d-id97058-punct">
   <w.rf>
    <LM>w#w-d-id97058-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1267-8">
   <w.rf>
    <LM>w#w-d1t1267-8</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1t1269-1">
   <w.rf>
    <LM>w#w-d1t1269-1</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1269-2">
   <w.rf>
    <LM>w#w-d1t1269-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1269-3">
   <w.rf>
    <LM>w#w-d1t1269-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1269-5">
   <w.rf>
    <LM>w#w-d1t1269-5</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d1t1269-7">
   <w.rf>
    <LM>w#w-d1t1269-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1269-9">
   <w.rf>
    <LM>w#w-d1t1269-9</LM>
   </w.rf>
   <form>odboru</form>
   <lemma>odbor_^(na_úřadě)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m040-d1t1269-10">
   <w.rf>
    <LM>w#w-d1t1269-10</LM>
   </w.rf>
   <form>životního</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m040-d1t1269-11">
   <w.rf>
    <LM>w#w-d1t1269-11</LM>
   </w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m040-d1t1269-13">
   <w.rf>
    <LM>w#w-d1t1269-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t1269-14">
   <w.rf>
    <LM>w#w-d1t1269-14</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1t1271-1">
   <w.rf>
    <LM>w#w-d1t1271-1</LM>
   </w.rf>
   <form>studuje</form>
   <lemma>studovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-364-365">
   <w.rf>
    <LM>w#w-364-365</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-366">
  <m id="m040-d1t1271-3">
   <w.rf>
    <LM>w#w-d1t1271-3</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1271-4">
   <w.rf>
    <LM>w#w-d1t1271-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t1271-5">
   <w.rf>
    <LM>w#w-d1t1271-5</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t1271-6">
   <w.rf>
    <LM>w#w-d1t1271-6</LM>
   </w.rf>
   <form>vrátila</form>
   <lemma>vrátit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m040-d1t1271-8">
   <w.rf>
    <LM>w#w-d1t1271-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t1271-10">
   <w.rf>
    <LM>w#w-d1t1271-10</LM>
   </w.rf>
   <form>Francie</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m040-d-id97421-punct">
   <w.rf>
    <LM>w#w-d-id97421-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1271-13">
   <w.rf>
    <LM>w#w-d1t1271-13</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t1271-14">
   <w.rf>
    <LM>w#w-d1t1271-14</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m040-d1t1271-15">
   <w.rf>
    <LM>w#w-d1t1271-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1271-16">
   <w.rf>
    <LM>w#w-d1t1271-16</LM>
   </w.rf>
   <form>půlroční</form>
   <lemma>půlroční</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m040-d1t1271-18">
   <w.rf>
    <LM>w#w-d1t1271-18</LM>
   </w.rf>
   <form>stáži</form>
   <lemma>stáž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-366-367">
   <w.rf>
    <LM>w#w-366-367</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
