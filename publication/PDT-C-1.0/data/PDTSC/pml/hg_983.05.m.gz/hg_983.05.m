<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_983.05.w.gz" />
  </references>
 </head>
 <s id="m983-13808_03-1214">
  <m id="m983-d1t2105-3">
   <w.rf>
    <LM>w#w-d1t2105-3</LM>
   </w.rf>
   <form>Spousta</form>
   <lemma>spousta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d1t2105-5">
   <w.rf>
    <LM>w#w-d1t2105-5</LM>
   </w.rf>
   <form>děvčat</form>
   <lemma>děvče</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m983-d1t2105-2">
   <w.rf>
    <LM>w#w-d1t2105-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t2107-1">
   <w.rf>
    <LM>w#w-d1t2107-1</LM>
   </w.rf>
   <form>nemělo</form>
   <lemma>mít</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m983-d1t2107-3">
   <w.rf>
    <LM>w#w-d1t2107-3</LM>
   </w.rf>
   <form>nikoho</form>
   <lemma>nikdo</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m983-9220-9230">
   <w.rf>
    <LM>w#w-9220-9230</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t2107-4">
   <w.rf>
    <LM>w#w-d1t2107-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t2107-5">
   <w.rf>
    <LM>w#w-d1t2107-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t2107-6">
   <w.rf>
    <LM>w#w-d1t2107-6</LM>
   </w.rf>
   <form>ubytovaly</form>
   <lemma>ubytovat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m983-d1t2107-7">
   <w.rf>
    <LM>w#w-d1t2107-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t2107-9">
   <w.rf>
    <LM>w#w-d1t2107-9</LM>
   </w.rf>
   <form>Ivce</form>
   <lemma>Ivka_;m</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m983-d-id122109">
   <w.rf>
    <LM>w#w-d-id122109</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
