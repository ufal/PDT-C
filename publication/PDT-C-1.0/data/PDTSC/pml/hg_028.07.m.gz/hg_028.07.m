<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_028.07.w.gz" />
  </references>
 </head>
 <s id="m028-d1e2261-x2">
  <m id="m028-d1t2268-1">
   <w.rf>
    <LM>w#w-d1t2268-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2268-2">
   <w.rf>
    <LM>w#w-d1t2268-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2279-1">
   <w.rf>
    <LM>w#w-d1t2279-1</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m028-d1t2281-6">
   <w.rf>
    <LM>w#w-d1t2281-6</LM>
   </w.rf>
   <form>přetažený</form>
   <lemma>přetažený_^(*5áhnout)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m028-d-id134240-punct">
   <w.rf>
    <LM>w#w-d-id134240-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2281-11">
   <w.rf>
    <LM>w#w-d1t2281-11</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2281-12">
   <w.rf>
    <LM>w#w-d1t2281-12</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2281-13">
   <w.rf>
    <LM>w#w-d1t2281-13</LM>
   </w.rf>
   <form>málo</form>
   <lemma>málo-1_^(málo_peněz)</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m028-d1t2281-14">
   <w.rf>
    <LM>w#w-d1t2281-14</LM>
   </w.rf>
   <form>spánku</form>
   <lemma>spánek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m028-d-id134304-punct">
   <w.rf>
    <LM>w#w-d-id134304-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2281-16">
   <w.rf>
    <LM>w#w-d1t2281-16</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2281-17">
   <w.rf>
    <LM>w#w-d1t2281-17</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2281-19">
   <w.rf>
    <LM>w#w-d1t2281-19</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m028-d1t2281-20">
   <w.rf>
    <LM>w#w-d1t2281-20</LM>
   </w.rf>
   <form>nervní</form>
   <lemma>nervní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m028-d1e2261-x2-1872">
   <w.rf>
    <LM>w#w-d1e2261-x2-1872</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1873">
  <m id="m028-d1t2283-4">
   <w.rf>
    <LM>w#w-d1t2283-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2283-3">
   <w.rf>
    <LM>w#w-d1t2283-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m028-d1t2283-5">
   <w.rf>
    <LM>w#w-d1t2283-5</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m028-d1t2283-6">
   <w.rf>
    <LM>w#w-d1t2283-6</LM>
   </w.rf>
   <form>disciplína</form>
   <lemma>disciplína</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m028-d1e2261-x2-662">
   <w.rf>
    <LM>w#w-d1e2261-x2-662</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-664_2">
  <m id="m028-664_2-712">
   <w.rf>
    <LM>w#w-664_2-712</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m028-664_2-714">
   <w.rf>
    <LM>w#w-664_2-714</LM>
   </w.rf>
   <form>jedináček</form>
   <lemma>jedináček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m028-664_2-716">
   <w.rf>
    <LM>w#w-664_2-716</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2293-8">
   <w.rf>
    <LM>w#w-d1t2293-8</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2293-9">
   <w.rf>
    <LM>w#w-d1t2293-9</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m028-d1t2293-10">
   <w.rf>
    <LM>w#w-d1t2293-10</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS6-----A---9</tag>
  </m>
  <m id="m028-d1t2293-11">
   <w.rf>
    <LM>w#w-d1t2293-11</LM>
   </w.rf>
   <form>spal</form>
   <lemma>spát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d-id134774-punct">
   <w.rf>
    <LM>w#w-d-id134774-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2304-2">
   <w.rf>
    <LM>w#w-d1t2304-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2304-3">
   <w.rf>
    <LM>w#w-d1t2304-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2304-4">
   <w.rf>
    <LM>w#w-d1t2304-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m028-d1t2304-5">
   <w.rf>
    <LM>w#w-d1t2304-5</LM>
   </w.rf>
   <form>vyvedla</form>
   <lemma>vyvést</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m028-d-id134940-punct">
   <w.rf>
    <LM>w#w-d-id134940-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2304-8">
   <w.rf>
    <LM>w#w-d1t2304-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2304-9">
   <w.rf>
    <LM>w#w-d1t2304-9</LM>
   </w.rf>
   <form>ležel</form>
   <lemma>ležet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2304-10">
   <w.rf>
    <LM>w#w-d1t2304-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m028-d1t2304-11">
   <w.rf>
    <LM>w#w-d1t2304-11</LM>
   </w.rf>
   <form>posteli</form>
   <lemma>postel</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m028-d-id135019-punct">
   <w.rf>
    <LM>w#w-d-id135019-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2304-13">
   <w.rf>
    <LM>w#w-d1t2304-13</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2304-14">
   <w.rf>
    <LM>w#w-d1t2304-14</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m028-664_2-718">
   <w.rf>
    <LM>w#w-664_2-718</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-664_2-720">
   <w.rf>
    <LM>w#w-664_2-720</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2304-15">
   <w.rf>
    <LM>w#w-d1t2304-15</LM>
   </w.rf>
   <form>Pojď</form>
   <lemma>jít</lemma>
   <tag>Vi-S---2--A-I-1</tag>
  </m>
  <m id="m028-d1t2304-16">
   <w.rf>
    <LM>w#w-d1t2304-16</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m028-d1t2304-17">
   <w.rf>
    <LM>w#w-d1t2304-17</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m028-d1t2304-18">
   <w.rf>
    <LM>w#w-d1t2304-18</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m028-d1t2304-19">
   <w.rf>
    <LM>w#w-d1t2304-19</LM>
   </w.rf>
   <form>facek</form>
   <lemma>facka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m028-664_2-1881">
   <w.rf>
    <LM>w#w-664_2-1881</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-664_2-722">
   <w.rf>
    <LM>w#w-664_2-722</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1882">
  <m id="m028-d1t2304-21">
   <w.rf>
    <LM>w#w-d1t2304-21</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2304-22">
   <w.rf>
    <LM>w#w-d1t2304-22</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m028-d1t2304-23">
   <w.rf>
    <LM>w#w-d1t2304-23</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d-m-d1e2301-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2301-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2309-x2">
  <m id="m028-d1t2314-2">
   <w.rf>
    <LM>w#w-d1t2314-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m028-d1t2314-4">
   <w.rf>
    <LM>w#w-d1t2314-4</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m028-d1t2314-5">
   <w.rf>
    <LM>w#w-d1t2314-5</LM>
   </w.rf>
   <form>obdivovali</form>
   <lemma>obdivovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m028-d-m-d1e2309-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2309-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2319-x2">
  <m id="m028-d1t2322-1">
   <w.rf>
    <LM>w#w-d1t2322-1</LM>
   </w.rf>
   <form>Místo</form>
   <lemma>místo-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2322-2">
   <w.rf>
    <LM>w#w-d1t2322-2</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m028-d1t2322-3">
   <w.rf>
    <LM>w#w-d1t2322-3</LM>
   </w.rf>
   <form>utekla</form>
   <lemma>utéci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m028-d1e2319-x2-742">
   <w.rf>
    <LM>w#w-d1e2319-x2-742</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-744_2">
  <m id="m028-d1t2324-2">
   <w.rf>
    <LM>w#w-d1t2324-2</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d-id135505-punct">
   <w.rf>
    <LM>w#w-d-id135505-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2324-4">
   <w.rf>
    <LM>w#w-d1t2324-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2324-5">
   <w.rf>
    <LM>w#w-d1t2324-5</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m028-d1t2324-6">
   <w.rf>
    <LM>w#w-d1t2324-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2324-7">
   <w.rf>
    <LM>w#w-d1t2324-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2324-8">
   <w.rf>
    <LM>w#w-d1t2324-8</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m028-d1t2324-9">
   <w.rf>
    <LM>w#w-d1t2324-9</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m028-744_2-746">
   <w.rf>
    <LM>w#w-744_2-746</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-748">
  <m id="m028-d1t2326-2">
   <w.rf>
    <LM>w#w-d1t2326-2</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m028-d1t2326-4">
   <w.rf>
    <LM>w#w-d1t2326-4</LM>
   </w.rf>
   <form>otcem</form>
   <lemma>otec</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m028-d1t2326-5">
   <w.rf>
    <LM>w#w-d1t2326-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-748-752">
   <w.rf>
    <LM>w#w-748-752</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m028-d1t2326-6">
   <w.rf>
    <LM>w#w-d1t2326-6</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m028-d1t2326-7">
   <w.rf>
    <LM>w#w-d1t2326-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-748-750">
   <w.rf>
    <LM>w#w-748-750</LM>
   </w.rf>
   <form>blízká</form>
   <lemma>blízký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m028-748-754">
   <w.rf>
    <LM>w#w-748-754</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-756_2">
  <m id="m028-d1t2326-13">
   <w.rf>
    <LM>w#w-d1t2326-13</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m028-d1t2326-14">
   <w.rf>
    <LM>w#w-d1t2326-14</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m028-d-id135938-punct">
   <w.rf>
    <LM>w#w-d-id135938-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2328-4">
   <w.rf>
    <LM>w#w-d1t2328-4</LM>
   </w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4XP3----------</tag>
  </m>
  <m id="m028-d1t2328-6">
   <w.rf>
    <LM>w#w-d1t2328-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m028-d1t2328-7">
   <w.rf>
    <LM>w#w-d1t2328-7</LM>
   </w.rf>
   <form>svěřujete</form>
   <lemma>svěřovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m028-d1t2328-8">
   <w.rf>
    <LM>w#w-d1t2328-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2328-9">
   <w.rf>
    <LM>w#w-d1t2328-9</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m028-756_2-1912">
   <w.rf>
    <LM>w#w-756_2-1912</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1913">
  <m id="m028-d1t2328-12">
   <w.rf>
    <LM>w#w-d1t2328-12</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m028-d1t2328-13">
   <w.rf>
    <LM>w#w-d1t2328-13</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2328-14">
   <w.rf>
    <LM>w#w-d1t2328-14</LM>
   </w.rf>
   <form>matka</form>
   <lemma>matka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m028-d-id136126-punct">
   <w.rf>
    <LM>w#w-d-id136126-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2328-18">
   <w.rf>
    <LM>w#w-d1t2328-18</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m028-d1t2328-17">
   <w.rf>
    <LM>w#w-d1t2328-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m028-756_2-758">
   <w.rf>
    <LM>w#w-756_2-758</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m028-d1t2328-20">
   <w.rf>
    <LM>w#w-d1t2328-20</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m028-756_2-760">
   <w.rf>
    <LM>w#w-756_2-760</LM>
   </w.rf>
   <form>blízké</form>
   <lemma>blízký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m028-d-m-d1e2319-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2319-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2331-x2">
  <m id="m028-d1t2338-1">
   <w.rf>
    <LM>w#w-d1t2338-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m028-d1t2338-2">
   <w.rf>
    <LM>w#w-d1t2338-2</LM>
   </w.rf>
   <form>nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m028-d1t2338-3">
   <w.rf>
    <LM>w#w-d1t2338-3</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2338-4">
   <w.rf>
    <LM>w#w-d1t2338-4</LM>
   </w.rf>
   <form>vypovědět</form>
   <lemma>vypovědět</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m028-d1e2331-x2-774">
   <w.rf>
    <LM>w#w-d1e2331-x2-774</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2346-1">
   <w.rf>
    <LM>w#w-d1t2346-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2346-2">
   <w.rf>
    <LM>w#w-d1t2346-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2346-3">
   <w.rf>
    <LM>w#w-d1t2346-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m028-d1t2346-4">
   <w.rf>
    <LM>w#w-d1t2346-4</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS1----------</tag>
  </m>
  <m id="m028-d1t2346-5">
   <w.rf>
    <LM>w#w-d1t2346-5</LM>
   </w.rf>
   <form>tělo</form>
   <lemma>tělo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m028-d1t2346-6">
   <w.rf>
    <LM>w#w-d1t2346-6</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m028-d1t2346-7">
   <w.rf>
    <LM>w#w-d1t2346-7</LM>
   </w.rf>
   <form>duše</form>
   <lemma>duše</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m028-d1e2331-x2-776">
   <w.rf>
    <LM>w#w-d1e2331-x2-776</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-778">
  <m id="m028-d1t2348-1">
   <w.rf>
    <LM>w#w-d1t2348-1</LM>
   </w.rf>
   <form>Jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS1----------</tag>
  </m>
  <m id="m028-d1t2348-2">
   <w.rf>
    <LM>w#w-d1t2348-2</LM>
   </w.rf>
   <form>tělo</form>
   <lemma>tělo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m028-d1t2348-3">
   <w.rf>
    <LM>w#w-d1t2348-3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d-id136592-punct">
   <w.rf>
    <LM>w#w-d-id136592-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2350-2">
   <w.rf>
    <LM>w#w-d1t2350-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2352-1">
   <w.rf>
    <LM>w#w-d1t2352-1</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2352-2">
   <w.rf>
    <LM>w#w-d1t2352-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2352-3">
   <w.rf>
    <LM>w#w-d1t2352-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m028-d1t2352-4">
   <w.rf>
    <LM>w#w-d1t2352-4</LM>
   </w.rf>
   <form>náramně</form>
   <lemma>náramně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m028-d1t2352-6">
   <w.rf>
    <LM>w#w-d1t2352-6</LM>
   </w.rf>
   <form>rozuměly</form>
   <lemma>rozumět</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m028-d-m-d1e2343-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2343-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2355-x2">
  <m id="m028-d1t2358-1">
   <w.rf>
    <LM>w#w-d1t2358-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d-m-d1e2355-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2355-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2359-x2">
  <m id="m028-d1t2362-2">
   <w.rf>
    <LM>w#w-d1t2362-2</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m028-d1t2362-4">
   <w.rf>
    <LM>w#w-d1t2362-4</LM>
   </w.rf>
   <form>otcem</form>
   <lemma>otec</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m028-d1t2362-5">
   <w.rf>
    <LM>w#w-d1t2362-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d-id136936-punct">
   <w.rf>
    <LM>w#w-d-id136936-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2364-5">
   <w.rf>
    <LM>w#w-d1t2364-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2364-6">
   <w.rf>
    <LM>w#w-d1t2364-6</LM>
   </w.rf>
   <form>brzo</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A---1</tag>
  </m>
  <m id="m028-d1t2364-7">
   <w.rf>
    <LM>w#w-d1t2364-7</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m028-d1e2359-x2-1934">
   <w.rf>
    <LM>w#w-d1e2359-x2-1934</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1935">
  <m id="m028-d1t2366-1">
   <w.rf>
    <LM>w#w-d1t2366-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2366-2">
   <w.rf>
    <LM>w#w-d1t2366-2</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m028-d1t2366-3">
   <w.rf>
    <LM>w#w-d1t2366-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2366-5">
   <w.rf>
    <LM>w#w-d1t2366-5</LM>
   </w.rf>
   <form>66</form>
   <lemma>66</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m028-d-id137222-punct">
   <w.rf>
    <LM>w#w-d-id137222-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2366-7">
   <w.rf>
    <LM>w#w-d1t2366-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2366-8">
   <w.rf>
    <LM>w#w-d1t2366-8</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m028-d1t2366-9">
   <w.rf>
    <LM>w#w-d1t2366-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m028-d1t2366-10">
   <w.rf>
    <LM>w#w-d1t2366-10</LM>
   </w.rf>
   <form>krční</form>
   <lemma>krční</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m028-d1t2366-11">
   <w.rf>
    <LM>w#w-d1t2366-11</LM>
   </w.rf>
   <form>rakovinu</form>
   <lemma>rakovina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m028-d1e2359-x2-800">
   <w.rf>
    <LM>w#w-d1e2359-x2-800</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-802">
  <m id="m028-d1t2362-7">
   <w.rf>
    <LM>w#w-d1t2362-7</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2364-1">
   <w.rf>
    <LM>w#w-d1t2364-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m028-d1t2364-2">
   <w.rf>
    <LM>w#w-d1t2364-2</LM>
   </w.rf>
   <form>mnoha</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m028-d1t2364-3">
   <w.rf>
    <LM>w#w-d1t2364-3</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m028-d1t2368-2">
   <w.rf>
    <LM>w#w-d1t2368-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2368-4">
   <w.rf>
    <LM>w#w-d1t2368-4</LM>
   </w.rf>
   <form>ocenila</form>
   <lemma>ocenit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m028-d-id137388-punct">
   <w.rf>
    <LM>w#w-d-id137388-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2368-6">
   <w.rf>
    <LM>w#w-d1t2368-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2368-9">
   <w.rf>
    <LM>w#w-d1t2368-9</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m028-d1t2368-10">
   <w.rf>
    <LM>w#w-d1t2368-10</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m028-d1t2368-7">
   <w.rf>
    <LM>w#w-d1t2368-7</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m028-d1t2368-8">
   <w.rf>
    <LM>w#w-d1t2368-8</LM>
   </w.rf>
   <form>špatného</form>
   <lemma>špatný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m028-d1t2368-11">
   <w.rf>
    <LM>w#w-d1t2368-11</LM>
   </w.rf>
   <form>nechtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m028-d-id137476-punct">
   <w.rf>
    <LM>w#w-d-id137476-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2368-13">
   <w.rf>
    <LM>w#w-d1t2368-13</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2368-14">
   <w.rf>
    <LM>w#w-d1t2368-14</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2368-15">
   <w.rf>
    <LM>w#w-d1t2368-15</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2368-17">
   <w.rf>
    <LM>w#w-d1t2368-17</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSXP4-S1-------</tag>
  </m>
  <m id="m028-d1t2368-18">
   <w.rf>
    <LM>w#w-d1t2368-18</LM>
   </w.rf>
   <form>dobro</form>
   <lemma>dobro_^(prospěch;;hudební_nástroj)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m028-d1t2370-1">
   <w.rf>
    <LM>w#w-d1t2370-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2370-2">
   <w.rf>
    <LM>w#w-d1t2370-2</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2370-3">
   <w.rf>
    <LM>w#w-d1t2370-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m028-d1t2370-4">
   <w.rf>
    <LM>w#w-d1t2370-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2370-5">
   <w.rf>
    <LM>w#w-d1t2370-5</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2370-6">
   <w.rf>
    <LM>w#w-d1t2370-6</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m028-d-id137689-punct">
   <w.rf>
    <LM>w#w-d-id137689-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2370-8">
   <w.rf>
    <LM>w#w-d1t2370-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2370-9">
   <w.rf>
    <LM>w#w-d1t2370-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2370-10">
   <w.rf>
    <LM>w#w-d1t2370-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2370-11">
   <w.rf>
    <LM>w#w-d1t2370-11</LM>
   </w.rf>
   <form>přísný</form>
   <lemma>přísný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m028-802-804">
   <w.rf>
    <LM>w#w-802-804</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-806">
  <m id="m028-d1t2375-1">
   <w.rf>
    <LM>w#w-d1t2375-1</LM>
   </w.rf>
   <form>Nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m028-d1t2375-2">
   <w.rf>
    <LM>w#w-d1t2375-2</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m028-806-830">
   <w.rf>
    <LM>w#w-806-830</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m028-806-832">
   <w.rf>
    <LM>w#w-806-832</LM>
   </w.rf>
   <form>špatného</form>
   <lemma>špatný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m028-d-id137845-punct">
   <w.rf>
    <LM>w#w-d-id137845-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2377-2">
   <w.rf>
    <LM>w#w-d1t2377-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2377-3">
   <w.rf>
    <LM>w#w-d1t2377-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m028-d1t2377-5">
   <w.rf>
    <LM>w#w-d1t2377-5</LM>
   </w.rf>
   <form>mami</form>
   <lemma>mami_,h</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m028-d1t2377-6">
   <w.rf>
    <LM>w#w-d1t2377-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2377-10">
   <w.rf>
    <LM>w#w-d1t2377-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m028-d1t2377-11">
   <w.rf>
    <LM>w#w-d1t2377-11</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m028-d1t2377-7">
   <w.rf>
    <LM>w#w-d1t2377-7</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m028-d1t2377-8">
   <w.rf>
    <LM>w#w-d1t2377-8</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2377-9">
   <w.rf>
    <LM>w#w-d1t2377-9</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d-m-d1e2359-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2359-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2380-x3">
  <m id="m028-d1t2389-1">
   <w.rf>
    <LM>w#w-d1t2389-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d-m-d1e2380-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2380-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2390-x2">
  <m id="m028-d1t2393-1">
   <w.rf>
    <LM>w#w-d1t2393-1</LM>
   </w.rf>
   <form>Vzpomenete</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m028-d1t2393-2">
   <w.rf>
    <LM>w#w-d1t2393-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m028-d1t2393-3">
   <w.rf>
    <LM>w#w-d1t2393-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m028-d1t2393-4">
   <w.rf>
    <LM>w#w-d1t2393-4</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m028-d1t2393-5">
   <w.rf>
    <LM>w#w-d1t2393-5</LM>
   </w.rf>
   <form>společný</form>
   <lemma>společný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m028-d1t2393-6">
   <w.rf>
    <LM>w#w-d1t2393-6</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m028-d1t2393-7">
   <w.rf>
    <LM>w#w-d1t2393-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m028-d1t2393-8">
   <w.rf>
    <LM>w#w-d1t2393-8</LM>
   </w.rf>
   <form>otcem</form>
   <lemma>otec</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m028-d-id138374-punct">
   <w.rf>
    <LM>w#w-d-id138374-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2394-x2">
  <m id="m028-d1t2397-1">
   <w.rf>
    <LM>w#w-d1t2397-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1e2394-x2-1962">
   <w.rf>
    <LM>w#w-d1e2394-x2-1962</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1963">
  <m id="m028-d1t2397-3">
   <w.rf>
    <LM>w#w-d1t2397-3</LM>
   </w.rf>
   <form>Tatí</form>
   <lemma>tatí_,h_^(tatínek)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m028-d1t2397-4">
   <w.rf>
    <LM>w#w-d1t2397-4</LM>
   </w.rf>
   <form>pěstoval</form>
   <lemma>pěstovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2397-5">
   <w.rf>
    <LM>w#w-d1t2397-5</LM>
   </w.rf>
   <form>holuby</form>
   <lemma>holub</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m028-d-id138499-punct">
   <w.rf>
    <LM>w#w-d-id138499-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2397-7">
   <w.rf>
    <LM>w#w-d1t2397-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2397-8">
   <w.rf>
    <LM>w#w-d1t2397-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2397-9">
   <w.rf>
    <LM>w#w-d1t2397-9</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2397-10">
   <w.rf>
    <LM>w#w-d1t2397-10</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m028-d1t2397-11">
   <w.rf>
    <LM>w#w-d1t2397-11</LM>
   </w.rf>
   <form>vybírat</form>
   <lemma>vybírat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m028-d1t2397-12">
   <w.rf>
    <LM>w#w-d1t2397-12</LM>
   </w.rf>
   <form>holoubata</form>
   <lemma>holoubě</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m028-d-m-d1e2394-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2394-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2402-x2">
  <m id="m028-d1t2407-2">
   <w.rf>
    <LM>w#w-d1t2407-2</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m028-d1t2407-3">
   <w.rf>
    <LM>w#w-d1t2407-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2407-4">
   <w.rf>
    <LM>w#w-d1t2407-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m028-d1t2407-7">
   <w.rf>
    <LM>w#w-d1t2407-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m028-d1t2407-8">
   <w.rf>
    <LM>w#w-d1t2407-8</LM>
   </w.rf>
   <form>půdě</form>
   <lemma>půda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m028-d1t2421-1">
   <w.rf>
    <LM>w#w-d1t2421-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2421-2">
   <w.rf>
    <LM>w#w-d1t2421-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2421-3">
   <w.rf>
    <LM>w#w-d1t2421-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m028-d1t2421-4">
   <w.rf>
    <LM>w#w-d1t2421-4</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m028-d1t2421-5">
   <w.rf>
    <LM>w#w-d1t2421-5</LM>
   </w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m028-d1t2421-6">
   <w.rf>
    <LM>w#w-d1t2421-6</LM>
   </w.rf>
   <form>neprotáhl</form>
   <lemma>protáhnout</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m028-d1t2421-7">
   <w.rf>
    <LM>w#w-d1t2421-7</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2421-8">
   <w.rf>
    <LM>w#w-d1t2421-8</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m028-d1t2421-9">
   <w.rf>
    <LM>w#w-d1t2421-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2421-10">
   <w.rf>
    <LM>w#w-d1t2421-10</LM>
   </w.rf>
   <form>tatí</form>
   <lemma>tatí_,h_^(tatínek)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m028-d1e2402-x2-874">
   <w.rf>
    <LM>w#w-d1e2402-x2-874</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-876">
  <m id="m028-d1t2421-13">
   <w.rf>
    <LM>w#w-d1t2421-13</LM>
   </w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2421-14">
   <w.rf>
    <LM>w#w-d1t2421-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2421-15">
   <w.rf>
    <LM>w#w-d1t2421-15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m028-d1t2421-16">
   <w.rf>
    <LM>w#w-d1t2421-16</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m028-d1t2421-17">
   <w.rf>
    <LM>w#w-d1t2421-17</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2421-19">
   <w.rf>
    <LM>w#w-d1t2421-19</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m028-d1t2423-1">
   <w.rf>
    <LM>w#w-d1t2423-1</LM>
   </w.rf>
   <form>nahoru</form>
   <lemma>nahoru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d-id139181-punct">
   <w.rf>
    <LM>w#w-d-id139181-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2423-3">
   <w.rf>
    <LM>w#w-d1t2423-3</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2423-5">
   <w.rf>
    <LM>w#w-d1t2423-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2423-6">
   <w.rf>
    <LM>w#w-d1t2423-6</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m028-d1t2423-7">
   <w.rf>
    <LM>w#w-d1t2423-7</LM>
   </w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWYS1----------</tag>
  </m>
  <m id="m028-d1t2423-8">
   <w.rf>
    <LM>w#w-d1t2423-8</LM>
   </w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m028-d1t2423-9">
   <w.rf>
    <LM>w#w-d1t2423-9</LM>
   </w.rf>
   <form>přístup</form>
   <lemma>přístup</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m028-876-878">
   <w.rf>
    <LM>w#w-876-878</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-880">
  <m id="m028-d1t2427-4">
   <w.rf>
    <LM>w#w-d1t2427-4</LM>
   </w.rf>
   <form>Všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m028-d1t2427-2">
   <w.rf>
    <LM>w#w-d1t2427-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2427-3">
   <w.rf>
    <LM>w#w-d1t2427-3</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-880-882">
   <w.rf>
    <LM>w#w-880-882</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m028-880-1981">
   <w.rf>
    <LM>w#w-880-1981</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1982">
  <m id="m028-d1t2427-6">
   <w.rf>
    <LM>w#w-d1t2427-6</LM>
   </w.rf>
   <form>Zalévali</form>
   <lemma>zalévat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m028-d1t2427-7">
   <w.rf>
    <LM>w#w-d1t2427-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2427-8">
   <w.rf>
    <LM>w#w-d1t2427-8</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d-id139522-punct">
   <w.rf>
    <LM>w#w-d-id139522-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2427-10">
   <w.rf>
    <LM>w#w-d1t2427-10</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m028-1982-1991">
   <w.rf>
    <LM>w#w-1982-1991</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2427-11">
   <w.rf>
    <LM>w#w-d1t2427-11</LM>
   </w.rf>
   <form>pumpovala</form>
   <lemma>pumpovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-880-564">
   <w.rf>
    <LM>w#w-880-564</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2427-12">
   <w.rf>
    <LM>w#w-d1t2427-12</LM>
   </w.rf>
   <form>tatí</form>
   <lemma>tatí_,h_^(tatínek)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m028-d1t2427-13">
   <w.rf>
    <LM>w#w-d1t2427-13</LM>
   </w.rf>
   <form>zaléval</form>
   <lemma>zalévat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-880-884">
   <w.rf>
    <LM>w#w-880-884</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-886">
  <m id="m028-d1t2427-15">
   <w.rf>
    <LM>w#w-d1t2427-15</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m028-d1t2427-16">
   <w.rf>
    <LM>w#w-d1t2427-16</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2427-17">
   <w.rf>
    <LM>w#w-d1t2427-17</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m028-d1t2427-18">
   <w.rf>
    <LM>w#w-d1t2427-18</LM>
   </w.rf>
   <form>hadice</form>
   <lemma>hadice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m028-886-1997">
   <w.rf>
    <LM>w#w-886-1997</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1998">
  <m id="m028-d1t2427-20">
   <w.rf>
    <LM>w#w-d1t2427-20</LM>
   </w.rf>
   <form>Možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d-id139688-punct">
   <w.rf>
    <LM>w#w-d-id139688-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2427-22">
   <w.rf>
    <LM>w#w-d1t2427-22</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2427-23">
   <w.rf>
    <LM>w#w-d1t2427-23</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m028-d-id139728-punct">
   <w.rf>
    <LM>w#w-d-id139728-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2427-25">
   <w.rf>
    <LM>w#w-d1t2427-25</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2427-26">
   <w.rf>
    <LM>w#w-d1t2427-26</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m028-d1t2427-27">
   <w.rf>
    <LM>w#w-d1t2427-27</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2427-28">
   <w.rf>
    <LM>w#w-d1t2427-28</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m028-d1t2427-29">
   <w.rf>
    <LM>w#w-d1t2427-29</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2427-30">
   <w.rf>
    <LM>w#w-d1t2427-30</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m028-886-888">
   <w.rf>
    <LM>w#w-886-888</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-890">
  <m id="m028-d1t2432-1">
   <w.rf>
    <LM>w#w-d1t2432-1</LM>
   </w.rf>
   <form>Uměl</form>
   <lemma>umět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2432-2">
   <w.rf>
    <LM>w#w-d1t2432-2</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m028-d1t2432-3">
   <w.rf>
    <LM>w#w-d1t2432-3</LM>
   </w.rf>
   <form>pěstovat</form>
   <lemma>pěstovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m028-d1t2432-4">
   <w.rf>
    <LM>w#w-d1t2432-4</LM>
   </w.rf>
   <form>zeleninu</form>
   <lemma>zelenina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m028-890-936">
   <w.rf>
    <LM>w#w-890-936</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2418-x3">
  <m id="m028-d1t2434-1">
   <w.rf>
    <LM>w#w-d1t2434-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m028-d1t2434-2">
   <w.rf>
    <LM>w#w-d1t2434-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1e2418-x3-938">
   <w.rf>
    <LM>w#w-d1e2418-x3-938</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-940">
  <m id="m028-d1t2436-1">
   <w.rf>
    <LM>w#w-d1t2436-1</LM>
   </w.rf>
   <form>Vzpomenu</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m028-d1t2436-2">
   <w.rf>
    <LM>w#w-d1t2436-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m028-940-942">
   <w.rf>
    <LM>w#w-940-942</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-944">
  <m id="m028-d1t2436-5">
   <w.rf>
    <LM>w#w-d1t2436-5</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2436-6">
   <w.rf>
    <LM>w#w-d1t2436-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2436-7">
   <w.rf>
    <LM>w#w-d1t2436-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2436-8">
   <w.rf>
    <LM>w#w-d1t2436-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2436-9">
   <w.rf>
    <LM>w#w-d1t2436-9</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m028-d1t2436-10">
   <w.rf>
    <LM>w#w-d1t2436-10</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m028-d-id140141-punct">
   <w.rf>
    <LM>w#w-d-id140141-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2436-12">
   <w.rf>
    <LM>w#w-d1t2436-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2436-13">
   <w.rf>
    <LM>w#w-d1t2436-13</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m028-d1t2436-15">
   <w.rf>
    <LM>w#w-d1t2436-15</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m028-d1t2436-16">
   <w.rf>
    <LM>w#w-d1t2436-16</LM>
   </w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m028-d1t2438-1">
   <w.rf>
    <LM>w#w-d1t2438-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2438-2">
   <w.rf>
    <LM>w#w-d1t2438-2</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m028-944-1092">
   <w.rf>
    <LM>w#w-944-1092</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2438-4">
   <w.rf>
    <LM>w#w-d1t2438-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m028-d1t2438-5">
   <w.rf>
    <LM>w#w-d1t2438-5</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m028-d1t2438-6">
   <w.rf>
    <LM>w#w-d1t2438-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m028-d1t2438-7">
   <w.rf>
    <LM>w#w-d1t2438-7</LM>
   </w.rf>
   <form>vesnici</form>
   <lemma>vesnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m028-d1t2438-8">
   <w.rf>
    <LM>w#w-d1t2438-8</LM>
   </w.rf>
   <form>brzo</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A---1</tag>
  </m>
  <m id="m028-d1t2438-9">
   <w.rf>
    <LM>w#w-d1t2438-9</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2438-10">
   <w.rf>
    <LM>w#w-d1t2438-10</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m028-d1t2438-11">
   <w.rf>
    <LM>w#w-d1t2438-11</LM>
   </w.rf>
   <form>mléko</form>
   <lemma>mléko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m028-944-946">
   <w.rf>
    <LM>w#w-944-946</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-948">
  <m id="m028-d1t2438-14">
   <w.rf>
    <LM>w#w-d1t2438-14</LM>
   </w.rf>
   <form>Mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m028-d1t2438-15">
   <w.rf>
    <LM>w#w-d1t2438-15</LM>
   </w.rf>
   <form>nechali</form>
   <lemma>nechat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m028-d1t2438-16">
   <w.rf>
    <LM>w#w-d1t2438-16</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m028-948-2021">
   <w.rf>
    <LM>w#w-948-2021</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-2022">
  <m id="m028-d1t2438-22">
   <w.rf>
    <LM>w#w-d1t2438-22</LM>
   </w.rf>
   <form>Jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2438-20">
   <w.rf>
    <LM>w#w-d1t2438-20</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2438-21">
   <w.rf>
    <LM>w#w-d1t2438-21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m028-d1t2438-23">
   <w.rf>
    <LM>w#w-d1t2438-23</LM>
   </w.rf>
   <form>probudila</form>
   <lemma>probudit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m028-d1t2440-1">
   <w.rf>
    <LM>w#w-d1t2440-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2440-2">
   <w.rf>
    <LM>w#w-d1t2440-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2440-3">
   <w.rf>
    <LM>w#w-d1t2440-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2440-4">
   <w.rf>
    <LM>w#w-d1t2440-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d-id140640-punct">
   <w.rf>
    <LM>w#w-d-id140640-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2440-6">
   <w.rf>
    <LM>w#w-d1t2440-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2440-7">
   <w.rf>
    <LM>w#w-d1t2440-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2440-8">
   <w.rf>
    <LM>w#w-d1t2440-8</LM>
   </w.rf>
   <form>vyběhla</form>
   <lemma>vyběhnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m028-d1t2440-9">
   <w.rf>
    <LM>w#w-d1t2440-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2440-10">
   <w.rf>
    <LM>w#w-d1t2440-10</LM>
   </w.rf>
   <form>běžela</form>
   <lemma>běžet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2440-11">
   <w.rf>
    <LM>w#w-d1t2440-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2440-12">
   <w.rf>
    <LM>w#w-d1t2440-12</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m028-d1t2440-14">
   <w.rf>
    <LM>w#w-d1t2440-14</LM>
   </w.rf>
   <form>vsi</form>
   <lemma>ves</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m028-2022-2023">
   <w.rf>
    <LM>w#w-2022-2023</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-2024">
  <m id="m028-d1t2440-18">
   <w.rf>
    <LM>w#w-d1t2440-18</LM>
   </w.rf>
   <form>Věděla</form>
   <lemma>vědět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2440-17">
   <w.rf>
    <LM>w#w-d1t2440-17</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d-id140824-punct">
   <w.rf>
    <LM>w#w-d-id140824-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2440-20">
   <w.rf>
    <LM>w#w-d1t2440-20</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2440-21">
   <w.rf>
    <LM>w#w-d1t2440-21</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m028-d1t2442-3">
   <w.rf>
    <LM>w#w-d1t2442-3</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2442-1">
   <w.rf>
    <LM>w#w-d1t2442-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m028-d1t2442-2">
   <w.rf>
    <LM>w#w-d1t2442-2</LM>
   </w.rf>
   <form>vsi</form>
   <lemma>ves</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m028-d-m-d1e2418-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2418-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2443-x2">
  <m id="m028-d1t2448-4">
   <w.rf>
    <LM>w#w-d1t2448-4</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d-id141036-punct">
   <w.rf>
    <LM>w#w-d-id141036-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2458-1">
   <w.rf>
    <LM>w#w-d1t2458-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2458-2">
   <w.rf>
    <LM>w#w-d1t2458-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m028-d1t2458-3">
   <w.rf>
    <LM>w#w-d1t2458-3</LM>
   </w.rf>
   <form>chytli</form>
   <lemma>chytnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m028-d1t2458-4">
   <w.rf>
    <LM>w#w-d1t2458-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2458-5">
   <w.rf>
    <LM>w#w-d1t2458-5</LM>
   </w.rf>
   <form>tatí</form>
   <lemma>tatí_,h_^(tatínek)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m028-d1t2458-6">
   <w.rf>
    <LM>w#w-d1t2458-6</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m028-d1t2458-7">
   <w.rf>
    <LM>w#w-d1t2458-7</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m028-d1t2458-8">
   <w.rf>
    <LM>w#w-d1t2458-8</LM>
   </w.rf>
   <form>kabát</form>
   <lemma>kabát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m028-d1e2443-x2-2030">
   <w.rf>
    <LM>w#w-d1e2443-x2-2030</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-2031">
  <m id="m028-d1t2458-12">
   <w.rf>
    <LM>w#w-d1t2458-12</LM>
   </w.rf>
   <form>Běžela</form>
   <lemma>běžet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2458-11">
   <w.rf>
    <LM>w#w-d1t2458-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2458-15">
   <w.rf>
    <LM>w#w-d1t2458-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m028-d1t2458-19">
   <w.rf>
    <LM>w#w-d1t2458-19</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m028-d1t2458-18">
   <w.rf>
    <LM>w#w-d1t2458-18</LM>
   </w.rf>
   <form>košilce</form>
   <lemma>košilka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m028-d1t2460-1">
   <w.rf>
    <LM>w#w-d1t2460-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2460-5">
   <w.rf>
    <LM>w#w-d1t2460-5</LM>
   </w.rf>
   <form>brzo</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A---1</tag>
  </m>
  <m id="m028-d1t2460-6">
   <w.rf>
    <LM>w#w-d1t2460-6</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2460-2">
   <w.rf>
    <LM>w#w-d1t2460-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2460-3">
   <w.rf>
    <LM>w#w-d1t2460-3</LM>
   </w.rf>
   <form>přeci</form>
   <lemma>přeci-2_,h_^(^GC**přece-2)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2460-4">
   <w.rf>
    <LM>w#w-d1t2460-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2460-7">
   <w.rf>
    <LM>w#w-d1t2460-7</LM>
   </w.rf>
   <form>chladno</form>
   <lemma>chladno-2_^(být_chladno)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m028-d1e2443-x2-966">
   <w.rf>
    <LM>w#w-d1e2443-x2-966</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-968_2">
  <m id="m028-d1t2460-13">
   <w.rf>
    <LM>w#w-d1t2460-13</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2460-14">
   <w.rf>
    <LM>w#w-d1t2460-14</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2460-15">
   <w.rf>
    <LM>w#w-d1t2460-15</LM>
   </w.rf>
   <form>tma</form>
   <lemma>tma</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m028-d-id141616-punct">
   <w.rf>
    <LM>w#w-d-id141616-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2460-17">
   <w.rf>
    <LM>w#w-d1t2460-17</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2460-18">
   <w.rf>
    <LM>w#w-d1t2460-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2460-19">
   <w.rf>
    <LM>w#w-d1t2460-19</LM>
   </w.rf>
   <form>běžela</form>
   <lemma>běžet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-968_2-2037">
   <w.rf>
    <LM>w#w-968_2-2037</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-2038">
  <m id="m028-d1t2462-4">
   <w.rf>
    <LM>w#w-d1t2462-4</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d-id141743-punct">
   <w.rf>
    <LM>w#w-d-id141743-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2462-6">
   <w.rf>
    <LM>w#w-d1t2462-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2462-7">
   <w.rf>
    <LM>w#w-d1t2462-7</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m028-d1t2462-8">
   <w.rf>
    <LM>w#w-d1t2462-8</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m028-d1t2462-10">
   <w.rf>
    <LM>w#w-d1t2462-10</LM>
   </w.rf>
   <form>kabát</form>
   <lemma>kabát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m028-d-m-d1e2455-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2455-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2469-x2">
  <m id="m028-d1t2474-11">
   <w.rf>
    <LM>w#w-d1t2474-11</LM>
   </w.rf>
   <form>Posadili</form>
   <lemma>posadit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m028-d1t2474-12">
   <w.rf>
    <LM>w#w-d1t2474-12</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m028-d1t2474-13">
   <w.rf>
    <LM>w#w-d1t2474-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m028-d1t2474-14">
   <w.rf>
    <LM>w#w-d1t2474-14</LM>
   </w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m028-d1t2474-16">
   <w.rf>
    <LM>w#w-d1t2474-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2474-17">
   <w.rf>
    <LM>w#w-d1t2474-17</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2474-18">
   <w.rf>
    <LM>w#w-d1t2474-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2474-19">
   <w.rf>
    <LM>w#w-d1t2474-19</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2474-20">
   <w.rf>
    <LM>w#w-d1t2474-20</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m028-d1t2474-21">
   <w.rf>
    <LM>w#w-d1t2474-21</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m028-d1t2474-22">
   <w.rf>
    <LM>w#w-d1t2474-22</LM>
   </w.rf>
   <form>vydržela</form>
   <lemma>vydržet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m028-d1t2474-23">
   <w.rf>
    <LM>w#w-d1t2474-23</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m028-d1t2474-24">
   <w.rf>
    <LM>w#w-d1t2474-24</LM>
   </w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m028-d-id142264-punct">
   <w.rf>
    <LM>w#w-d-id142264-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2476-1">
   <w.rf>
    <LM>w#w-d1t2476-1</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2476-2">
   <w.rf>
    <LM>w#w-d1t2476-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m028-d1t2476-3">
   <w.rf>
    <LM>w#w-d1t2476-3</LM>
   </w.rf>
   <form>mléko</form>
   <lemma>mléko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m028-d1t2476-7">
   <w.rf>
    <LM>w#w-d1t2476-7</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m028-d1t2476-8">
   <w.rf>
    <LM>w#w-d1t2476-8</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m028-d1t2476-9">
   <w.rf>
    <LM>w#w-d1t2476-9</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m028-d1t2476-4">
   <w.rf>
    <LM>w#w-d1t2476-4</LM>
   </w.rf>
   <form>sebrali</form>
   <lemma>sebrat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m028-d-m-d1e2469-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2469-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2477-x2">
  <m id="m028-d1t2480-1">
   <w.rf>
    <LM>w#w-d1t2480-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m028-d1t2480-2">
   <w.rf>
    <LM>w#w-d1t2480-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m028-d1t2480-3">
   <w.rf>
    <LM>w#w-d1t2480-3</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m028-d1t2480-4">
   <w.rf>
    <LM>w#w-d1t2480-4</LM>
   </w.rf>
   <form>vzpomínka</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m028-d-m-d1e2477-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2477-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2481-x2">
  <m id="m028-d1t2484-1">
   <w.rf>
    <LM>w#w-d1t2484-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m028-d1t2484-2">
   <w.rf>
    <LM>w#w-d1t2484-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m028-d1t2484-3">
   <w.rf>
    <LM>w#w-d1t2484-3</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m028-d1t2484-4">
   <w.rf>
    <LM>w#w-d1t2484-4</LM>
   </w.rf>
   <form>vzpomínka</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m028-d1e2481-x2-1116">
   <w.rf>
    <LM>w#w-d1e2481-x2-1116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1118">
  <m id="m028-d1t2486-2">
   <w.rf>
    <LM>w#w-d1t2486-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2486-8">
   <w.rf>
    <LM>w#w-d1t2486-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2486-9">
   <w.rf>
    <LM>w#w-d1t2486-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m028-d1t2486-10">
   <w.rf>
    <LM>w#w-d1t2486-10</LM>
   </w.rf>
   <form>mléko</form>
   <lemma>mléko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m028-d1t2486-11">
   <w.rf>
    <LM>w#w-d1t2486-11</LM>
   </w.rf>
   <form>vezl</form>
   <lemma>vézt_^(něco/někoho_autem,_vlakem,...)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2486-12">
   <w.rf>
    <LM>w#w-d1t2486-12</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m028-d1t2486-14">
   <w.rf>
    <LM>w#w-d1t2486-14</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m028-d-id142862-punct">
   <w.rf>
    <LM>w#w-d-id142862-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2486-17">
   <w.rf>
    <LM>w#w-d1t2486-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2486-20">
   <w.rf>
    <LM>w#w-d1t2486-20</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m028-d1t2486-18">
   <w.rf>
    <LM>w#w-d1t2486-18</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m028-d1t2486-19">
   <w.rf>
    <LM>w#w-d1t2486-19</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m028-d1t2486-21">
   <w.rf>
    <LM>w#w-d1t2486-21</LM>
   </w.rf>
   <form>vozil</form>
   <lemma>vozit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2486-22">
   <w.rf>
    <LM>w#w-d1t2486-22</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2486-23">
   <w.rf>
    <LM>w#w-d1t2486-23</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m028-d1t2486-24">
   <w.rf>
    <LM>w#w-d1t2486-24</LM>
   </w.rf>
   <form>banán</form>
   <lemma>banán</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m028-1118-1120">
   <w.rf>
    <LM>w#w-1118-1120</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1122">
  <m id="m028-d1t2486-28">
   <w.rf>
    <LM>w#w-d1t2486-28</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-1122-2060">
   <w.rf>
    <LM>w#w-1122-2060</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2486-29">
   <w.rf>
    <LM>w#w-d1t2486-29</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m028-d1t2486-30">
   <w.rf>
    <LM>w#w-d1t2486-30</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m028-d1t2494-1">
   <w.rf>
    <LM>w#w-d1t2494-1</LM>
   </w.rf>
   <form>dopoledne</form>
   <lemma>dopoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2494-2">
   <w.rf>
    <LM>w#w-d1t2494-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2502-1">
   <w.rf>
    <LM>w#w-d1t2502-1</LM>
   </w.rf>
   <form>kdykoli</form>
   <lemma>kdykoli</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2502-3">
   <w.rf>
    <LM>w#w-d1t2502-3</LM>
   </w.rf>
   <form>přijel</form>
   <lemma>přijet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m028-d1t2502-8">
   <w.rf>
    <LM>w#w-d1t2502-8</LM>
   </w.rf>
   <form>banán</form>
   <lemma>banán</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m028-1122-1178">
   <w.rf>
    <LM>w#w-1122-1178</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1180">
  <m id="m028-d1t2504-2">
   <w.rf>
    <LM>w#w-d1t2504-2</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2504-3">
   <w.rf>
    <LM>w#w-d1t2504-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m028-d1t2504-4">
   <w.rf>
    <LM>w#w-d1t2504-4</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d-id143407-punct">
   <w.rf>
    <LM>w#w-d-id143407-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-1180-2067">
   <w.rf>
    <LM>w#w-1180-2067</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2506-1">
   <w.rf>
    <LM>w#w-d1t2506-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2506-2">
   <w.rf>
    <LM>w#w-d1t2506-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2506-3">
   <w.rf>
    <LM>w#w-d1t2506-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2506-5">
   <w.rf>
    <LM>w#w-d1t2506-5</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2506-6">
   <w.rf>
    <LM>w#w-d1t2506-6</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2506-7">
   <w.rf>
    <LM>w#w-d1t2506-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m028-d1t2506-9">
   <w.rf>
    <LM>w#w-d1t2506-9</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m028-d1t2506-11">
   <w.rf>
    <LM>w#w-d1t2506-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m028-d1t2506-12">
   <w.rf>
    <LM>w#w-d1t2506-12</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m028-d-id143591-punct">
   <w.rf>
    <LM>w#w-d-id143591-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2508-1">
   <w.rf>
    <LM>w#w-d1t2508-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2508-3">
   <w.rf>
    <LM>w#w-d1t2508-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2508-4">
   <w.rf>
    <LM>w#w-d1t2508-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2508-5">
   <w.rf>
    <LM>w#w-d1t2508-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2508-6">
   <w.rf>
    <LM>w#w-d1t2508-6</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m028-d1t2508-7">
   <w.rf>
    <LM>w#w-d1t2508-7</LM>
   </w.rf>
   <form>hospodyně</form>
   <lemma>hospodyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m028-1180-1182">
   <w.rf>
    <LM>w#w-1180-1182</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1184">
  <m id="m028-d1t2508-10">
   <w.rf>
    <LM>w#w-d1t2508-10</LM>
   </w.rf>
   <form>Chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m028-d1t2508-11">
   <w.rf>
    <LM>w#w-d1t2508-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2508-12">
   <w.rf>
    <LM>w#w-d1t2508-12</LM>
   </w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m028-d1t2508-13">
   <w.rf>
    <LM>w#w-d1t2508-13</LM>
   </w.rf>
   <form>výlohy</form>
   <lemma>výloha_^(v_obchodě,_reklamní,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m028-d-id143797-punct">
   <w.rf>
    <LM>w#w-d-id143797-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2508-15">
   <w.rf>
    <LM>w#w-d1t2508-15</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2508-16">
   <w.rf>
    <LM>w#w-d1t2508-16</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2510-1">
   <w.rf>
    <LM>w#w-d1t2510-1</LM>
   </w.rf>
   <form>chodský</form>
   <lemma>chodský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m028-d1t2510-2">
   <w.rf>
    <LM>w#w-d1t2510-2</LM>
   </w.rf>
   <form>malovaný</form>
   <lemma>malovaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m028-d1t2510-3">
   <w.rf>
    <LM>w#w-d1t2510-3</LM>
   </w.rf>
   <form>kávový</form>
   <lemma>kávový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m028-d1t2510-4">
   <w.rf>
    <LM>w#w-d1t2510-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2510-5">
   <w.rf>
    <LM>w#w-d1t2510-5</LM>
   </w.rf>
   <form>čajový</form>
   <lemma>čajový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m028-d1t2510-6">
   <w.rf>
    <LM>w#w-d1t2510-6</LM>
   </w.rf>
   <form>servis</form>
   <lemma>servis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m028-1184-1186">
   <w.rf>
    <LM>w#w-1184-1186</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1200">
  <m id="m028-d1t2510-9">
   <w.rf>
    <LM>w#w-d1t2510-9</LM>
   </w.rf>
   <form>Stál</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2510-8">
   <w.rf>
    <LM>w#w-d1t2510-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2510-10">
   <w.rf>
    <LM>w#w-d1t2510-10</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2510-11">
   <w.rf>
    <LM>w#w-d1t2510-11</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m028-d1t2510-12">
   <w.rf>
    <LM>w#w-d1t2510-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2510-13">
   <w.rf>
    <LM>w#w-d1t2510-13</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m028-d1t2510-14">
   <w.rf>
    <LM>w#w-d1t2510-14</LM>
   </w.rf>
   <form>tisíce</form>
   <lemma>tisíc`1000</lemma>
   <tag>CzIP4----------</tag>
  </m>
  <m id="m028-1200-2085">
   <w.rf>
    <LM>w#w-1200-2085</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-2086">
  <m id="m028-d1t2517-4">
   <w.rf>
    <LM>w#w-d1t2517-4</LM>
   </w.rf>
   <form>Přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m028-d1t2517-3">
   <w.rf>
    <LM>w#w-d1t2517-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2517-5">
   <w.rf>
    <LM>w#w-d1t2517-5</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2517-6">
   <w.rf>
    <LM>w#w-d1t2517-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2517-7">
   <w.rf>
    <LM>w#w-d1t2517-7</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m028-d1t2517-8">
   <w.rf>
    <LM>w#w-d1t2517-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-1200-1224">
   <w.rf>
    <LM>w#w-1200-1224</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-1200-1226">
   <w.rf>
    <LM>w#w-1200-1226</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2517-10">
   <w.rf>
    <LM>w#w-d1t2517-10</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2517-11">
   <w.rf>
    <LM>w#w-d1t2517-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m028-d1t2517-12">
   <w.rf>
    <LM>w#w-d1t2517-12</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m028-d1t2517-13">
   <w.rf>
    <LM>w#w-d1t2517-13</LM>
   </w.rf>
   <form>hezký</form>
   <lemma>hezký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m028-d1t2517-14">
   <w.rf>
    <LM>w#w-d1t2517-14</LM>
   </w.rf>
   <form>servis</form>
   <lemma>servis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m028-d-id144311-punct">
   <w.rf>
    <LM>w#w-d-id144311-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2517-16">
   <w.rf>
    <LM>w#w-d1t2517-16</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2517-18">
   <w.rf>
    <LM>w#w-d1t2517-18</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m028-d1t2517-19">
   <w.rf>
    <LM>w#w-d1t2517-19</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2517-20">
   <w.rf>
    <LM>w#w-d1t2517-20</LM>
   </w.rf>
   <form>drahý</form>
   <lemma>drahý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m028-2086-2087">
   <w.rf>
    <LM>w#w-2086-2087</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-1200-1228">
   <w.rf>
    <LM>w#w-1200-1228</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-2088">
  <m id="m028-d1t2517-29">
   <w.rf>
    <LM>w#w-d1t2517-29</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m028-d1t2517-30">
   <w.rf>
    <LM>w#w-d1t2517-30</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m028-d1t2517-31">
   <w.rf>
    <LM>w#w-d1t2517-31</LM>
   </w.rf>
   <form>ví</form>
   <lemma>vědět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m028-d-id144512-punct">
   <w.rf>
    <LM>w#w-d-id144512-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2517-33">
   <w.rf>
    <LM>w#w-d1t2517-33</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2517-34">
   <w.rf>
    <LM>w#w-d1t2517-34</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m028-d1t2517-35">
   <w.rf>
    <LM>w#w-d1t2517-35</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m028-d1t2517-36">
   <w.rf>
    <LM>w#w-d1t2517-36</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m028-d1t2517-37">
   <w.rf>
    <LM>w#w-d1t2517-37</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m028-d1t2517-39">
   <w.rf>
    <LM>w#w-d1t2517-39</LM>
   </w.rf>
   <form>Vánocům</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m028-d-m-d1e2499-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2499-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-d1e2520-x2">
  <m id="m028-d1t2525-1">
   <w.rf>
    <LM>w#w-d1t2525-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2525-3">
   <w.rf>
    <LM>w#w-d1t2525-3</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m028-d1t2525-2">
   <w.rf>
    <LM>w#w-d1t2525-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m028-d1t2525-4">
   <w.rf>
    <LM>w#w-d1t2525-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d1t2525-5">
   <w.rf>
    <LM>w#w-d1t2525-5</LM>
   </w.rf>
   <form>toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m028-d-m-d1e2520-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2520-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m028-1254">
  <m id="m028-d1t2535-1">
   <w.rf>
    <LM>w#w-d1t2535-1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m028-d-id144856-punct">
   <w.rf>
    <LM>w#w-d-id144856-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2535-3">
   <w.rf>
    <LM>w#w-d1t2535-3</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m028-d1t2535-4">
   <w.rf>
    <LM>w#w-d1t2535-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m028-d1t2535-5">
   <w.rf>
    <LM>w#w-d1t2535-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m028-d1t2535-6">
   <w.rf>
    <LM>w#w-d1t2535-6</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m028-d-id144927-punct">
   <w.rf>
    <LM>w#w-d-id144927-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2535-14">
   <w.rf>
    <LM>w#w-d1t2535-14</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m028-d1t2535-15">
   <w.rf>
    <LM>w#w-d1t2535-15</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m028-d1t2535-16">
   <w.rf>
    <LM>w#w-d1t2535-16</LM>
   </w.rf>
   <form>dostání</form>
   <lemma>dostání_^(*2t)_(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m028-d1t2535-17">
   <w.rf>
    <LM>w#w-d1t2535-17</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m028-d1t2535-18">
   <w.rf>
    <LM>w#w-d1t2535-18</LM>
   </w.rf>
   <form>čokoláda</form>
   <lemma>čokoláda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m028-d-id145086-punct">
   <w.rf>
    <LM>w#w-d-id145086-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m028-d1t2535-24">
   <w.rf>
    <LM>w#w-d1t2535-24</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m028-d1t2535-26">
   <w.rf>
    <LM>w#w-d1t2535-26</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m028-d1t2535-25">
   <w.rf>
    <LM>w#w-d1t2535-25</LM>
   </w.rf>
   <form>tatí</form>
   <lemma>tatí_,h_^(tatínek)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m028-d1t2535-27">
   <w.rf>
    <LM>w#w-d1t2535-27</LM>
   </w.rf>
   <form>přinesl</form>
   <lemma>přinést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m028-d1t2535-28">
   <w.rf>
    <LM>w#w-d1t2535-28</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m028-d1t2535-29">
   <w.rf>
    <LM>w#w-d1t2535-29</LM>
   </w.rf>
   <form>čokolád</form>
   <lemma>čokoláda</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m028-d1t2535-30">
   <w.rf>
    <LM>w#w-d1t2535-30</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m028-d1t2535-31">
   <w.rf>
    <LM>w#w-d1t2535-31</LM>
   </w.rf>
   <form>Tuzexu</form>
   <lemma>Tuzex-1_;m</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m028-1254-1256">
   <w.rf>
    <LM>w#w-1254-1256</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
