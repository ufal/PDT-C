<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ps_101.10.w.gz" />
  </references>
 </head>
 <s id="m101-d1e1661-x2">
  <m id="m101-d1t1664-1">
   <w.rf>
    <LM>w#w-d1t1664-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1664-2">
   <w.rf>
    <LM>w#w-d1t1664-2</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m101-d-m-d1e1661-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1661-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
